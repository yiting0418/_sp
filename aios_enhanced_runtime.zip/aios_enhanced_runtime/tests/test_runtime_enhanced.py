"""tests/test_runtime_enhanced.py — Enhanced AIOS runtime tests"""
from __future__ import annotations
import os, threading, time
import pytest
import numpy as np

from aios.observability import (MetricRegistry, Tracer, EventBus,
    SystemEvent, EventSeverity, render_dashboard, record_syscall,
    get_registry, get_tracer, get_bus, CTX_SWITCHES, MIGRATIONS, SANDBOX_VIOLATIONS)
from aios.cluster.gpu_scheduler import GPUScheduler, DeviceClass, PlacementDecision
from aios.cluster.migration import MigrationManager, MigrationReason, MigrationStatus
from aios.sandbox import Sandbox, SandboxPolicy, SandboxRegistry, ViolationType, ExecutionResult
from aios.memory.vector_store import PersistentVectorStore, VectorEntry, DistanceMetric, SearchResult
from aios.kernel.os_kernel import AIKernel, ContextFrame, ContextSwitchReason
from aios.core.models import AgentSpec, Capability, MemoryScope, MemStoreRequest, MemRecallRequest
from aios.core.models_p2 import InferencePhase, InferenceTask, TaskPriority
from aios.kernel.aios import AIOS
from aios.kernel.aios_p2 import AIOS_P2

# ── fixtures ────────────────────────────────────────────────────────
@pytest.fixture
def kernel_aios(): return AIOS()

@pytest.fixture
def ai_kernel(kernel_aios): return AIKernel(kernel_aios)

@pytest.fixture
def aios_p2():
    p2=AIOS_P2.build(total_kv_blocks=32,vram_capacity_mb=4_000.0)
    p2.register_model("test-model",size_mb=100.0); return p2

@pytest.fixture
def agent_spec():
    return AgentSpec(goal="test enhanced runtime",owner="user:test",
        capabilities=[Capability.MEM_READ_PERSONAL,Capability.MEM_WRITE_PERSONAL,
                      Capability.TOOL_CODE_EXEC,Capability.TOOL_FILE_WRITE,Capability.TOOL_FILE_READ],
        max_scope=MemoryScope.PERSONAL,
        declared_actions=["mem_recall","mem_store","tool_call","tool:code_exec",
                          "tool:file_write","tool:file_read","sys_stats"],
        forbidden_actions=["agent_spawn"],model="test-model")

@pytest.fixture
def gpu_sched():
    s=GPUScheduler()
    s.register_device("gpu-0",DeviceClass.A100,"node-1",vram_total_gb=40.0)
    s.register_device("gpu-1",DeviceClass.A10G,"node-1",vram_total_gb=24.0)
    s.register_device("gpu-2",DeviceClass.H100,"node-2",vram_total_gb=80.0)
    return s

@pytest.fixture
def vec_store(): return PersistentVectorStore(dim=32,metric=DistanceMetric.COSINE,ef_search=20)

@pytest.fixture
def sandbox(tmp_path):
    import aios.sandbox.isolate as iso
    for pol in [SandboxPolicy.STANDARD,SandboxPolicy.STRICT,SandboxPolicy.PARANOID]:
        iso._PL[pol].fs_jail=str(tmp_path)
    sb=Sandbox("test-inst",SandboxPolicy.STANDARD)
    sb._jail=str(tmp_path/"test-inst"); os.makedirs(sb._jail,exist_ok=True)
    yield sb

def _rv(dim=32):
    v=np.random.randn(dim).astype(np.float32); return (v/np.linalg.norm(v)).tolist()

# ── Metrics ─────────────────────────────────────────────────────────
class TestMetrics:
    def test_counter_inc(self):
        r=MetricRegistry(); c=r.counter("t"); c.inc(); c.inc(5); assert c.get()==6.0
    def test_gauge(self):
        r=MetricRegistry(); g=r.gauge("g"); g.set(100); g.dec(30); assert g.get()==70.0
    def test_histogram(self):
        r=MetricRegistry(); h=r.histogram("h")
        for v in [1,2,3,4,5]: h.observe(v)
        s=h.summary(); assert s["count"]==5; assert abs(s["avg"]-3.0)<0.01
    def test_same_key_same_object(self):
        r=MetricRegistry(); c1=r.counter("x"); c2=r.counter("x"); c1.inc(10); assert c2.get()==10.0
    def test_thread_safe(self):
        r=MetricRegistry(); c=r.counter("thr")
        ts=[threading.Thread(target=lambda:c.inc()) for _ in range(100)]
        for t in ts: t.start()
        for t in ts: t.join()
        assert c.get()==100.0
    def test_snapshot(self):
        r=MetricRegistry(); r.counter("a"); r.gauge("b"); r.histogram("c")
        assert len(r.snapshot())>=3

# ── Tracer ───────────────────────────────────────────────────────────
class TestTracer:
    def test_duration(self):
        tr=Tracer()
        with tr.start("op") as s: time.sleep(0.01)
        assert s.elapsed_ms>=10.0
    def test_error_captured(self):
        tr=Tracer()
        try:
            with tr.start("e") as s: raise ValueError("boom")
        except ValueError: pass
        assert s.status=="error"; assert "boom" in s.error
    def test_parent_child_trace_id(self):
        tr=Tracer(); p=tr.span("p"); c=tr.span("c",parent=p)
        assert c.ctx.trace_id==p.ctx.trace_id; assert c.ctx.parent_id==p.ctx.span_id
    def test_recent(self):
        tr=Tracer()
        for i in range(5):
            with tr.start(f"op{i}"): pass
        assert len(tr.recent(3))==3
    def test_stats(self):
        tr=Tracer()
        for _ in range(10):
            with tr.start("rep"): time.sleep(0.001)
        assert tr.stats()["rep"]["count"]==10
    def test_attributes(self):
        tr=Tracer()
        with tr.start("a") as s: s.set("k","v").set("n",42)
        assert s.attributes["k"]=="v"; assert s.attributes["n"]==42

# ── EventBus ─────────────────────────────────────────────────────────
class TestEventBus:
    def test_emit_receive(self):
        b=EventBus(); b.emit(SystemEvent("t","s",payload={"x":1}))
        assert b.recent(10)[-1].event_type=="t"
    def test_severity_filter(self):
        b=EventBus()
        b.emit(SystemEvent("a","s",EventSeverity.INFO)); b.emit(SystemEvent("b","s",EventSeverity.ERROR))
        assert all(e.severity==EventSeverity.ERROR for e in b.recent(10,EventSeverity.ERROR))
    def test_handler(self):
        b=EventBus(); got=[]
        b.on("x",lambda e:got.append(e)); b.emit(SystemEvent("x","s",payload={"k":"v"}))
        assert len(got)==1; assert got[0].payload["k"]=="v"
    def test_wildcard(self):
        b=EventBus(); all_e=[]
        b.on("*",lambda e:all_e.append(e))
        b.emit(SystemEvent("a","s")); b.emit(SystemEvent("b","s"))
        assert len(all_e)==2
    def test_count_by_type(self):
        b=EventBus()
        for _ in range(3): b.emit(SystemEvent("tx","s"))
        assert b.count_by_type().get("tx",0)>=3
    def test_capacity(self):
        b=EventBus(max_events=5)
        for i in range(10): b.emit(SystemEvent(f"e{i}","s"))
        assert len(b.recent(100))<=5

# ── Dashboard ────────────────────────────────────────────────────────
class TestDashboard:
    def test_renders(self):
        s={"agents":{"running":2,"done":5},"memory":{"episodic_count":10,"semantic_count":3,"working_tokens_used":400,"working_token_budget":8000}}
        o=render_dashboard(s); assert "AIOS" in o
    def test_agent_counts(self):
        o=render_dashboard({"agents":{"running":3},"memory":{}})
        assert "running" in o; assert "3" in o

# ── GPU Scheduler ────────────────────────────────────────────────────
class TestGPUScheduler:
    def _task(self,phase=InferencePhase.PREFILL):
        return InferenceTask(model_id="m",phase=phase,prompt_tokens=64,max_tokens=128,priority=TaskPriority.NORMAL)
    def test_device_count(self,gpu_sched): assert gpu_sched.device_count==3
    def test_place_prefill(self,gpu_sched):
        d=gpu_sched.place(self._task(),vram_needed=2.0); assert d.placed
    def test_place_decode(self,gpu_sched):
        d=gpu_sched.place(self._task(InferencePhase.DECODE),vram_needed=1.0); assert d.placed
    def test_locality_bonus(self,gpu_sched):
        ph="abc123"
        with gpu_sched._lk: gpu_sched._devs["gpu-0"].resident_prefixes.add(ph)
        d=gpu_sched.place(self._task(InferencePhase.DECODE),vram_needed=0.5,prefix_hash=ph)
        assert d.placed; assert d.device_id=="gpu-0"
    def test_oom_rejected(self):
        s=GPUScheduler(); s.register_device("tiny",DeviceClass.A10G,"n1",vram_total_gb=1.0)
        t=self._task(); s.place(t,vram_needed=0.5); d=s.place(t,vram_needed=0.6)
        assert not d.placed
    def test_release_frees(self,gpu_sched):
        d=gpu_sched.place(self._task(),vram_needed=4.0); assert d.placed
        b=gpu_sched._devs[d.device_id].vram_used_gb
        gpu_sched.release(d.device_id,4.0)
        assert gpu_sched._devs[d.device_id].vram_used_gb<b
    def test_report_structure(self,gpu_sched):
        r=gpu_sched.device_report(); assert len(r)==3
        for d in r: assert "device_id" in d; assert "vram_total" in d
    def test_tick_decays(self,gpu_sched):
        with gpu_sched._lk: gpu_sched._devs["gpu-0"].compute_util=1.0
        gpu_sched.tick()
        with gpu_sched._lk: assert gpu_sched._devs["gpu-0"].compute_util<1.0

# ── Migration ────────────────────────────────────────────────────────
class TestMigration:
    def _state(self,k,spec):
        s=k.agent_spawn(spec); s.messages=[{"role":"user","content":"hi"}]; s.steps=3; return s
    def test_done(self,kernel_aios,agent_spec):
        mm=MigrationManager(); s=self._state(kernel_aios,agent_spec)
        r=mm.migrate(s,None,"n1","n2"); assert r.status==MigrationStatus.DONE
    def test_preserves_messages(self,kernel_aios,agent_spec):
        mm=MigrationManager(); s=self._state(kernel_aios,agent_spec); orig=list(s.messages)
        mm.migrate(s,None,"n1","n2"); assert s.messages==orig
    def test_checkpoint_size(self,kernel_aios,agent_spec):
        mm=MigrationManager(); s=self._state(kernel_aios,agent_spec)
        r=mm.migrate(s,None,"n1","n2"); assert r.checkpoint.size_bytes>0
    def test_increments_counter(self,kernel_aios,agent_spec):
        mm=MigrationManager(); s=self._state(kernel_aios,agent_spec)
        before=MIGRATIONS.get(); mm.migrate(s,None,"n1","n2"); assert MIGRATIONS.get()>before
    def test_stats(self,kernel_aios,agent_spec):
        mm=MigrationManager()
        for _ in range(3): mm.migrate(self._state(kernel_aios,agent_spec),None,"a","b")
        st=mm.stats(); assert st["total"]==3; assert st["done"]==3
    def test_list_by_instance(self,kernel_aios,agent_spec):
        mm=MigrationManager()
        s1=self._state(kernel_aios,agent_spec); s2=self._state(kernel_aios,agent_spec)
        mm.migrate(s1,None,"n1","n2"); mm.migrate(s2,None,"n1","n2")
        assert len(mm.list_records(s1.instance_id))==1
    def test_all_reasons(self,kernel_aios,agent_spec):
        mm=MigrationManager()
        for r in MigrationReason:
            s=self._state(kernel_aios,agent_spec)
            assert mm.migrate(s,None,"n1","n2",reason=r).status==MigrationStatus.DONE

# ── Sandbox ──────────────────────────────────────────────────────────
class TestSandbox:
    def test_exec_basic(self,sandbox):
        r=sandbox.execute_code("x=1+1\nprint(x)"); assert r.success; assert "2" in r.stdout
    def test_captures_locals(self,sandbox):
        r=sandbox.execute_code("answer=42"); assert "answer" in r.output.get("locals",{})
    def test_import_blocked_strict(self,tmp_path):
        import aios.sandbox.isolate as iso; iso._PL[SandboxPolicy.STRICT].fs_jail=str(tmp_path)
        sb=Sandbox("s",SandboxPolicy.STRICT); sb._jail=str(tmp_path/"s"); os.makedirs(sb._jail,exist_ok=True)
        r=sb.execute_code("import os"); assert not r.success; assert r.violation.violation_type==ViolationType.IMPORT_DENIED
    def test_dunder_blocked(self,sandbox):
        r=sandbox.execute_code("x=().__class__.__name__")
        assert not r.success; assert r.violation.violation_type==ViolationType.DUNDER_ACCESS
    def test_fs_jail(self,sandbox):
        r=sandbox.safe_read("/etc/passwd"); assert "error" in r
    def test_write_read(self,sandbox):
        p=os.path.join(sandbox._jail,"t.txt")
        assert "written" in sandbox.safe_write(p,"hello")
        assert sandbox.safe_read(p)["content"]=="hello"
    def test_tool_handler(self,sandbox):
        def add(x,y): return {"sum":x+y}
        r=sandbox.execute(add,{"x":3,"y":4}); assert r.success; assert r.output=={"sum":7}
    def test_network_blocked(self,tmp_path):
        import aios.sandbox.isolate as iso; iso._PL[SandboxPolicy.STRICT].fs_jail=str(tmp_path)
        sb=Sandbox("net",SandboxPolicy.STRICT); sb._jail=str(tmp_path/"net"); os.makedirs(sb._jail,exist_ok=True)
        r=sb.execute(lambda url:{"ok":url},{"url":"http://evil.com"})
        assert not r.success; assert r.violation.violation_type==ViolationType.NETWORK_DENIED
    def test_registry(self,tmp_path):
        import aios.sandbox.isolate as iso; iso._PL[SandboxPolicy.STANDARD].fs_jail=str(tmp_path)
        reg=SandboxRegistry(); a=reg.get("A"); assert reg.get("A") is a; assert reg.get("B") is not a

# ── Vector Store ─────────────────────────────────────────────────────
class TestVectorStore:
    def test_upsert_count(self,vec_store):
        vec_store.upsert("d1","hello",_rv(),"ns"); vec_store.upsert("d2","world",_rv(),"ns")
        assert vec_store.count("ns")==2
    def test_search(self,vec_store):
        for i in range(5): vec_store.upsert(f"d{i}",f"c{i}",_rv(),"t")
        r=vec_store.search(_rv(),namespace="t",top_k=3); assert len(r)<=3
    def test_namespace_isolation(self,vec_store):
        v=_rv(); vec_store.upsert("a","a",v,"ns-a"); vec_store.upsert("b","b",v,"ns-b")
        r=vec_store.search(v,namespace="ns-a",top_k=5)
        assert all(x.entry.namespace=="ns-a" for x in r)
    def test_upsert_updates(self,vec_store):
        vec_store.upsert("id","orig",_rv(),"ns"); vec_store.upsert("id","upd",_rv(),"ns")
        assert vec_store.count("ns")==1; assert vec_store.get("id","ns").content=="upd"
    def test_delete(self,vec_store):
        vec_store.upsert("del","x",_rv(),"ns"); assert vec_store.delete("del","ns")
        assert vec_store.count("ns")==0
    def test_delete_missing(self,vec_store): assert not vec_store.delete("ghost","ns")
    def test_score_ordering(self,vec_store):
        base=np.ones(32,dtype=np.float32); base/=np.linalg.norm(base)
        vec_store.upsert("close","c",base.tolist(),"o")
        anti=-base; anti/=np.linalg.norm(anti); vec_store.upsert("far","f",anti.tolist(),"o")
        r=vec_store.search(base.tolist(),namespace="o",top_k=2)
        if len(r)>=2: assert r[0].score>=r[1].score
    def test_persistence(self,tmp_path):
        s1=PersistentVectorStore(dim=16,persist_dir=str(tmp_path),ef_search=10)
        v=_rv(16); s1.upsert("p","content",v,"pns")
        s2=PersistentVectorStore(dim=16,persist_dir=str(tmp_path),ef_search=10)
        e=s2.get("p","pns"); assert e is not None; assert e.content=="content"
    def test_namespaces(self,vec_store):
        vec_store.upsert("a","x",_rv(),"alpha"); vec_store.upsert("b","y",_rv(),"beta")
        ns=vec_store.list_namespaces(); assert "alpha" in ns; assert "beta" in ns
    def test_empty_search(self,vec_store):
        assert vec_store.search(_rv(),namespace="empty",top_k=5)==[]

# ── AI OS Kernel ─────────────────────────────────────────────────────
class TestAIKernel:
    def test_spawn_frame(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec); assert ai_kernel.get_frame(s.instance_id) is not None
    def test_kill_removes_frame(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec); ai_kernel.kill(s.instance_id)
        assert ai_kernel.get_frame(s.instance_id) is None
    def test_ctx_switch_updates_current(self,ai_kernel,agent_spec):
        s2spec=agent_spec.model_copy(update={"goal":"s2"})
        s1=ai_kernel.spawn(agent_spec); s2=ai_kernel.spawn(s2spec)
        ai_kernel.context_switch(None,s1.instance_id)
        assert ai_kernel.current_agent()==s1.instance_id
        ai_kernel.context_switch(s1.instance_id,s2.instance_id)
        assert ai_kernel.current_agent()==s2.instance_id
    def test_ctx_switch_saves_messages(self,ai_kernel,agent_spec):
        s2=ai_kernel.spawn(agent_spec.model_copy(update={"goal":"s2"}))
        s1=ai_kernel.spawn(agent_spec)
        st=ai_kernel._aios.agent_get(s1.instance_id)
        st.messages=[{"role":"user","content":"test"}]
        ai_kernel.context_switch(s1.instance_id,s2.instance_id)
        assert ai_kernel.get_frame(s1.instance_id).messages==[{"role":"user","content":"test"}]
    def test_syscall_mem_store(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        r=ai_kernel.syscall("mem_store",s.token,content="hi",intent="test")
        assert r.syscall=="mem_store"; assert isinstance(r.success,bool)
    def test_syscall_tool_call(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        r=ai_kernel.syscall("tool_call",s.token,**{"name":"code_exec","args":{"code":"x=1"},"intent":"test"})
        assert r.syscall=="tool_call"
    def test_syscall_sys_stats(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        r=ai_kernel.syscall("sys_stats",s.token); assert r.success
    def test_syscall_unknown(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        r=ai_kernel.syscall("totally_unknown",s.token); assert not r.success
    def test_health_snapshot(self,ai_kernel,agent_spec):
        ai_kernel.spawn(agent_spec); snap=ai_kernel.health_snapshot()
        for k in ["kernel","agents","memory","tools","syscalls"]: assert k in snap
        assert "uptime_sec" in snap["kernel"]
    def test_dashboard(self,ai_kernel,agent_spec):
        ai_kernel.spawn(agent_spec); d=ai_kernel.dashboard()
        assert "AIOS" in d; assert "AGENTS" in d
    def test_update_frame(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        ai_kernel.update_frame(s.instance_id,step=5,last_syscall="mem_recall")
        f=ai_kernel.get_frame(s.instance_id); assert f.step==5; assert f.last_syscall=="mem_recall"
    def test_ctx_switch_counter(self,ai_kernel,agent_spec):
        s2=ai_kernel.spawn(agent_spec.model_copy(update={"goal":"s2"}))
        s1=ai_kernel.spawn(agent_spec)
        b=CTX_SWITCHES.get(); ai_kernel.context_switch(s1.instance_id,s2.instance_id)
        assert CTX_SWITCHES.get()>b
    def test_switch_nonexistent(self,ai_kernel,agent_spec):
        s=ai_kernel.spawn(agent_spec)
        assert not ai_kernel.context_switch(s.instance_id,"nonexistent-xyz")

# ── Regression ───────────────────────────────────────────────────────
class TestRegression:
    def test_phase1_abac(self):
        from aios.core.models import PolicyDecision
        k=AIOS()
        s=k.agent_spawn(AgentSpec(goal="t",owner="u",capabilities=[Capability.MEM_READ_PERSONAL],
            max_scope=MemoryScope.PERSONAL,declared_actions=["mem_store"],forbidden_actions=[]))
        r=k.mem_store(s.token,MemStoreRequest(content="x",intent="t"))
        assert isinstance(r,PolicyDecision) and not r.permitted
    def test_phase2_kvcache(self):
        from aios.l1.kvcache import KVCacheManager
        kv=KVCacheManager(total_blocks=16,block_size=4)
        bt=kv.append_tokens("s1",token_count=8); assert bt.token_count==8
        kv.release_sequence("s1")
    def test_phase3_ring(self):
        from aios.fs.aiofs import ConsistentHashRing
        ring=ConsistentHashRing(virtual_nodes=50)
        ring.add_node("n1"); ring.add_node("n2")
        p=ring.place("hash"); assert p.primary_node in("n1","n2")
