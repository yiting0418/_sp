"""
tests/test_phase1.py
─────────────────────
AIOS Phase 1 核心邏輯測試。
涵蓋：安全層（三道防線）、三層記憶體、AIOFS、工具路由、IAC、L5 Syscall。
"""

import pytest
from aios.core.models import (
    AgentSpec, Capability, ContextHandoff, KBBroadcastRequest,
    KBIndexRequest, KBSearchRequest, MemoryScope, MemoryTier,
    MemRecallRequest, MemStoreRequest, ToolCallRequest, CtxHandoffRequest,
    PolicyDecision, ToolResult,
)
from aios.kernel.aios import AIOS
from aios.security.policy import PolicyEngine
from aios.security.token import TokenIssuer
from aios.memory import MemorySubsystem
from aios.fs.aiofs import AIOFS as AIFSImpl
from aios.iac.handoff import IACBus


# ════════════════════════════════════════════════════════════════════
# Fixtures
# ════════════════════════════════════════════════════════════════════

@pytest.fixture
def kernel():
    return AIOS()


@pytest.fixture
def personal_spec():
    return AgentSpec(
        goal="分析 KV-Cache 論文",
        owner="user:alice",
        capabilities=[
            Capability.MEM_READ_PERSONAL,
            Capability.MEM_WRITE_PERSONAL,
            Capability.TOOL_CODE_EXEC,
        ],
        max_scope=MemoryScope.PERSONAL,
        declared_actions=["mem_recall", "mem_store", "tool_call", "tool:code_exec"],
        forbidden_actions=["tool:web_fetch", "agent_spawn"],
    )


@pytest.fixture
def workspace_spec():
    return AgentSpec(
        goal="整合研究成果並廣播至工作區",
        owner="user:alice",
        workspace_id="ws-research",
        capabilities=[
            Capability.MEM_READ_PERSONAL,
            Capability.MEM_WRITE_PERSONAL,
            Capability.MEM_READ_WORKSPACE,
            Capability.MEM_WRITE_WORKSPACE,
            Capability.KB_SEARCH,
            Capability.KB_INDEX,
            Capability.KB_BROADCAST,
            Capability.TOOL_WEB_FETCH,
            Capability.TOOL_CODE_EXEC,
            Capability.TOOL_FILE_READ,
            Capability.TOOL_FILE_WRITE,
            Capability.CTX_HANDOFF,
        ],
        max_scope=MemoryScope.WORKSPACE,
        declared_actions=[
            "mem_recall", "mem_store", "kb_search", "kb_index",
            "kb_broadcast", "tool_call", "tool:web_fetch",
            "tool:code_exec", "tool:file_write", "tool:file_read",
            "ctx_handoff",
        ],
        forbidden_actions=["agent_spawn"],
    )


@pytest.fixture
def personal_agent(kernel, personal_spec):
    return kernel.agent_spawn(personal_spec)


@pytest.fixture
def workspace_agent(kernel, workspace_spec):
    return kernel.agent_spawn(workspace_spec)


# ════════════════════════════════════════════════════════════════════
# TrustToken 結構驗證
# ════════════════════════════════════════════════════════════════════

class TestTrustToken:

    def test_capabilities_correctly_assigned(self, personal_agent):
        token = personal_agent.token
        assert Capability.MEM_READ_PERSONAL in token.capabilities
        assert Capability.TOOL_WEB_FETCH not in token.capabilities

    def test_declared_actions_locked_at_spawn(self, personal_agent):
        token = personal_agent.token
        ok, _ = token.action_permitted("mem_recall")
        assert ok
        ok, _ = token.action_permitted("agent_spawn")
        assert not ok

    def test_forbidden_actions_blocked(self, personal_agent):
        token = personal_agent.token
        ok, reason = token.action_permitted("tool:web_fetch")
        assert not ok
        assert "forbidden" in reason.lower()

    def test_scope_ceiling_personal(self, personal_agent):
        token = personal_agent.token
        assert token.allows_scope(MemoryScope.PERSONAL)
        assert not token.allows_scope(MemoryScope.WORKSPACE)
        assert not token.allows_scope(MemoryScope.GLOBAL)

    def test_scope_ceiling_workspace(self, workspace_agent):
        token = workspace_agent.token
        assert token.allows_scope(MemoryScope.PERSONAL)
        assert token.allows_scope(MemoryScope.WORKSPACE)
        assert not token.allows_scope(MemoryScope.GLOBAL)

    def test_intent_hash_matches_goal(self, personal_agent, personal_spec):
        import hashlib
        expected = hashlib.sha256(personal_spec.goal.encode()).hexdigest()
        assert personal_agent.token.intent_hash == expected

    def test_token_is_immutable(self, personal_agent):
        token = personal_agent.token
        with pytest.raises(Exception):
            token.owner = "attacker"  # type: ignore[misc]


# ════════════════════════════════════════════════════════════════════
# L4 安全層：三道防線
# ════════════════════════════════════════════════════════════════════

class TestABACFirstLayer:
    """第一道防線：能力令牌比對"""

    def test_personal_memory_write_permitted(self, kernel, personal_agent):
        token = personal_agent.token
        d = kernel._policy.check_memory_write(token, token.instance_id, MemoryScope.PERSONAL)
        assert d.permitted
        assert d.layer == "abac"

    def test_workspace_write_denied_no_capability(self, kernel, personal_agent):
        token = personal_agent.token
        d = kernel._policy.check_memory_write(token, "ws-research", MemoryScope.WORKSPACE)
        assert not d.permitted

    def test_workspace_write_permitted_with_capability(self, kernel, workspace_agent):
        token = workspace_agent.token
        d = kernel._policy.check_memory_write(token, token.workspace_id, MemoryScope.WORKSPACE)
        assert d.permitted

    def test_scope_escalation_denied(self, kernel, personal_agent):
        token = personal_agent.token
        d = kernel._policy.check_memory_read(token, "global", MemoryScope.GLOBAL)
        assert not d.permitted

    def test_tool_denied_without_capability(self, kernel, personal_agent):
        token = personal_agent.token
        d = kernel._policy.check_tool_call(token, "web_fetch", Capability.TOOL_WEB_FETCH)
        assert not d.permitted

    def test_tool_permitted_with_capability(self, kernel, workspace_agent):
        token = workspace_agent.token
        d = kernel._policy.check_tool_call(token, "web_fetch", Capability.TOOL_WEB_FETCH)
        assert d.permitted

    def test_revoked_token_always_denied(self, kernel, personal_agent):
        token = personal_agent.token
        kernel.issuer.revoke(token.instance_id)
        d = kernel._policy.check_memory_write(token, token.instance_id, MemoryScope.PERSONAL)
        assert not d.permitted

    def test_cache_invalidated_after_revoke(self, kernel, personal_agent):
        token = personal_agent.token
        # 先產生快取
        kernel._policy.check_memory_write(token, token.instance_id, MemoryScope.PERSONAL)
        # 撤銷並清除快取
        kernel.issuer.revoke(token.instance_id)
        kernel._policy.invalidate_cache(token.instance_id)
        d = kernel._policy.check_memory_write(token, token.instance_id, MemoryScope.PERSONAL)
        assert not d.permitted


class TestIntentWhitelistSecondLayer:
    """第二道防線：結構化意圖白名單"""

    def test_declared_syscall_permitted(self, kernel, personal_agent):
        token = personal_agent.token
        d = kernel._policy.check_memory_read(token, token.instance_id, MemoryScope.PERSONAL)
        assert d.permitted

    def test_undeclared_syscall_denied_at_intent_layer(self, kernel):
        # 建立一個沒有宣告 kb_search 的代理
        spec = AgentSpec(
            goal="只做記憶體操作",
            owner="user:test",
            capabilities=[Capability.KB_SEARCH],
            max_scope=MemoryScope.PERSONAL,
            declared_actions=["mem_recall"],   # 沒有宣告 kb_search
            forbidden_actions=[],
        )
        state = kernel.agent_spawn(spec)
        token = state.token
        d = kernel._policy.check_kb_operation(token, "search")
        assert not d.permitted
        assert d.layer == "intent_whitelist"

    def test_forbidden_action_triggers_anomaly_record(self, kernel, personal_agent):
        token = personal_agent.token
        # tool:web_fetch 在 forbidden_actions 中
        result = kernel.tool_call(
            token,
            ToolCallRequest(name="web_fetch", args={"url": "http://x.com"}, intent="test"),
        )
        # tool_call 永遠回傳 ToolResult（即使是策略拒絕也包在 ToolResult 裡）
        assert isinstance(result, ToolResult)
        assert not result.success
        assert result.error is not None
        # forbidden_attempt 應被記錄進異常計數器
        counts = kernel.sys_anomaly_counts(token.instance_id)
        assert counts.get("forbidden_attempt", 0) >= 1


class TestAnomalyThirdLayer:
    """第三道防線：行為異常計數規則"""

    def test_forbidden_attempt_recorded(self, kernel, personal_agent):
        token = personal_agent.token
        before = kernel.sys_anomaly_counts(token.instance_id)
        kernel._policy.record_forbidden_attempt(token)
        after = kernel.sys_anomaly_counts(token.instance_id)
        assert after.get("forbidden_attempt", 0) > before.get("forbidden_attempt", 0)

    def test_scope_escalation_recorded(self, kernel, personal_agent):
        token = personal_agent.token
        before = kernel.sys_anomaly_counts(token.instance_id)["scope_escalation"]
        # 嘗試存取超出 max_scope 的範圍（觸發 scope escalation 記錄）
        kernel._policy.check_memory_read(token, "global", MemoryScope.GLOBAL)
        after = kernel.sys_anomaly_counts(token.instance_id)["scope_escalation"]
        assert after >= before  # 至少不減少


# ════════════════════════════════════════════════════════════════════
# 三層記憶體子系統
# ════════════════════════════════════════════════════════════════════

class TestWorkingMemory:

    def test_push_and_dump(self):
        mem = MemorySubsystem()
        mem.store("hello world", "agent-1", MemoryScope.PERSONAL, MemoryTier.WORKING)
        entries = mem.working.dump()
        assert len(entries) == 1
        assert entries[0].content == "hello world"

    def test_token_budget_eviction(self):
        mem = MemorySubsystem()
        mem.working.token_budget = 20
        for i in range(10):
            mem.store("x" * 40, "agent-1", MemoryScope.PERSONAL, MemoryTier.WORKING)
        used, budget = mem.working.usage
        assert used <= budget

    def test_clear_empties_working_memory(self):
        mem = MemorySubsystem()
        mem.store("data", "agent-1", MemoryScope.PERSONAL, MemoryTier.WORKING)
        mem.working.clear()
        assert mem.working.dump() == []


class TestEpisodicMemory:

    def test_store_and_recall_order(self):
        mem = MemorySubsystem()
        for i in range(5):
            mem.store(f"事件 {i}", "agent-1", MemoryScope.PERSONAL, MemoryTier.EPISODIC)
        results = mem.episodic.recall_recent("agent-1", n=3)
        assert len(results) == 3
        assert "4" in results[0].content   # 最新的在最前面

    def test_namespace_isolation(self):
        mem = MemorySubsystem()
        mem.store("代理A的秘密", "agent-A", MemoryScope.PERSONAL, MemoryTier.EPISODIC)
        mem.store("代理B的秘密", "agent-B", MemoryScope.PERSONAL, MemoryTier.EPISODIC)
        results_a = mem.episodic.recall_all("agent-A")
        assert all("代理A" in e.content for e in results_a)
        assert not any("代理B" in e.content for e in results_a)

    def test_access_count_increases_on_recall(self):
        mem = MemorySubsystem()
        mem.store("測試內容", "agent-1", MemoryScope.PERSONAL, MemoryTier.EPISODIC)
        results = mem.episodic.recall_recent("agent-1", n=5)
        assert results[0].access_count >= 1


class TestSemanticMemory:

    def test_store_and_recall_by_similarity(self):
        mem = MemorySubsystem()
        mem.store("PagedAttention 管理 KV-Cache 分頁", "ns1", MemoryScope.PERSONAL, MemoryTier.SEMANTIC)
        mem.store("信任令牌在 spawn 時簽發", "ns1", MemoryScope.PERSONAL, MemoryTier.SEMANTIC)
        hits = mem.semantic.recall("GPU 記憶體管理", "ns1", top_k=1)
        assert len(hits) == 1
        assert hits[0][1] > 0  # score > 0

    def test_embedding_assigned_at_store(self):
        mem = MemorySubsystem()
        mem.store("有嵌入向量的內容", "ns1", MemoryScope.PERSONAL, MemoryTier.SEMANTIC)
        assert mem.semantic._store[0].embedding is not None
        assert len(mem.semantic._store[0].embedding) == 128

    def test_namespace_isolation_in_semantic(self):
        mem = MemorySubsystem()
        mem.store("代理A的知識", "agent-A", MemoryScope.PERSONAL, MemoryTier.SEMANTIC)
        hits = mem.semantic.recall("知識", "agent-B", top_k=5)
        # agent-B 無法查詢 agent-A 的個人語意記憶
        assert all(e.namespace != "agent-A" for e, _ in hits)

    def test_dedup_in_composite_recall(self):
        mem = MemorySubsystem()
        # 同一內容同時存在 episodic 和 semantic
        mem.store("共享內容", "ns1", MemoryScope.PERSONAL, MemoryTier.EPISODIC)
        mem.store("共享內容", "ns1", MemoryScope.PERSONAL, MemoryTier.SEMANTIC)
        results = mem.recall("共享內容", "ns1", top_k=10, tiers=[MemoryTier.EPISODIC, MemoryTier.SEMANTIC])
        ids = [e.id for e in results]
        assert len(ids) == len(set(ids))  # 無重複 id


# ════════════════════════════════════════════════════════════════════
# AIOFS
# ════════════════════════════════════════════════════════════════════

class TestAIOFS:

    def test_index_returns_entry(self):
        fs = AIFSImpl()
        entry = fs.index("AIOS 使用語意索引管理知識庫")
        assert entry.content_hash != ""
        assert entry.embedding is not None

    def test_dedup_same_content(self):
        fs = AIFSImpl()
        e1 = fs.index("相同的內容")
        e2 = fs.index("相同的內容")
        assert e1.ref == e2.ref
        assert fs.count() == 1

    def test_different_content_creates_different_entries(self):
        fs = AIFSImpl()
        fs.index("第一個不同的內容")
        fs.index("第二個完全不同的內容")
        assert fs.count() == 2

    def test_semantic_search_returns_results(self):
        fs = AIFSImpl()
        fs.index("KV-Cache 分頁記憶體管理")
        fs.index("意圖白名單安全策略")
        hits = fs.search("記憶體管理方法", top_k=1)
        assert len(hits) == 1
        assert hits[0][1] > 0

    def test_get_by_ref(self):
        fs = AIFSImpl()
        entry = fs.index("可用 ref 查詢的內容")
        found = fs.get_by_ref(entry.ref)
        assert found is not None
        assert found.content == entry.content

    def test_tiering_pass(self):
        fs = AIFSImpl()
        fs.index("很少存取的內容")
        counts = fs.run_tiering_pass()
        assert isinstance(counts, dict)
        assert sum(counts.values()) == fs.count()


# ════════════════════════════════════════════════════════════════════
# 工具路由器
# ════════════════════════════════════════════════════════════════════

class TestToolSystem:

    def test_code_exec_success(self, kernel, workspace_agent):
        token = workspace_agent.token
        result = kernel.tool_call(
            token,
            ToolCallRequest(
                name="code_exec",
                args={"code": "result = 1 + 1\nprint(result)"},
                intent="計算基本加法",
            ),
        )
        assert isinstance(result, ToolResult)
        assert result.success
        assert "2" in result.output.get("output", "")

    def test_code_exec_import_blocked(self, kernel, workspace_agent):
        token = workspace_agent.token
        result = kernel.tool_call(
            token,
            ToolCallRequest(
                name="code_exec",
                args={"code": "import os; os.system('rm -rf /')"},
                intent="惡意嘗試",
            ),
        )
        assert isinstance(result, ToolResult)
        assert not result.success

    def test_tool_call_denied_for_wrong_cap(self, kernel, personal_agent):
        token = personal_agent.token
        result = kernel.tool_call(
            token,
            ToolCallRequest(name="web_fetch", args={"url": "http://x.com"}, intent="test"),
        )
        assert isinstance(result, ToolResult)
        assert not result.success
        assert "拒絕" in (result.error or "")

    def test_unknown_tool_returns_error(self, kernel, workspace_agent):
        token = workspace_agent.token
        result = kernel.tool_call(
            token,
            ToolCallRequest(name="nonexistent_tool", args={}, intent="test"),
        )
        assert isinstance(result, ToolResult)
        assert not result.success

    def test_tool_list_filters_by_capability(self, kernel, personal_agent, workspace_agent):
        personal_tools  = kernel.tool_list(personal_agent.token)
        workspace_tools = kernel.tool_list(workspace_agent.token)
        assert "web_fetch" not in personal_tools
        assert "web_fetch" in workspace_tools
        assert len(workspace_tools) >= len(personal_tools)

    def test_file_write_and_read(self, kernel, workspace_agent):
        token = workspace_agent.token
        write_result = kernel.tool_call(
            token,
            ToolCallRequest(
                name="file_write",
                args={"path": "/tmp/aios_workspace/test_output.txt", "content": "AIOS Phase 1"},
                intent="儲存測試結果",
            ),
        )
        assert isinstance(write_result, ToolResult)
        assert write_result.success

        read_result = kernel.tool_call(
            token,
            ToolCallRequest(
                name="file_read",
                args={"path": "/tmp/aios_workspace/test_output.txt"},
                intent="讀取測試結果",
            ),
        )
        assert isinstance(read_result, ToolResult)
        assert read_result.success
        assert "AIOS Phase 1" in read_result.output.get("content", "")


# ════════════════════════════════════════════════════════════════════
# IAC：代理間通訊
# ════════════════════════════════════════════════════════════════════

class TestIAC:

    def test_ctx_handoff_delivered(self, kernel, workspace_agent):
        token = workspace_agent.token
        target_spec = AgentSpec(
            goal="接收並整合摘要",
            owner="user:bob",
            workspace_id="ws-research",
            capabilities=[Capability.MEM_WRITE_PERSONAL, Capability.MEM_READ_PERSONAL],
            max_scope=MemoryScope.PERSONAL,
            declared_actions=["mem_store", "mem_recall"],
            forbidden_actions=[],
        )
        target = kernel.agent_spawn(target_spec)

        result = kernel.ctx_handoff(
            token,
            CtxHandoffRequest(
                target_agent=target.instance_id,
                completed_goal="分析 PagedAttention 論文",
                key_findings=["KV-Cache 分頁可降低碎片化", "Prefill 與 Decode 應分離"],
                confidence=0.92,
                next_steps=["整合至 L1 設計"],
                intent="交接研究成果",
            ),
        )
        assert isinstance(result, ContextHandoff)

        received = kernel.receive_handoffs(target.instance_id)
        assert len(received) == 1
        assert received[0].completed_goal == "分析 PagedAttention 論文"
        assert received[0].confidence == 0.92

    def test_ctx_handoff_denied_without_capability(self, kernel, personal_agent):
        token = personal_agent.token  # 沒有 CTX_HANDOFF 能力
        result = kernel.ctx_handoff(
            token,
            CtxHandoffRequest(
                target_agent="some-agent",
                completed_goal="test",
                key_findings=[],
                intent="test",
            ),
        )
        assert isinstance(result, PolicyDecision)
        assert not result.permitted

    def test_kb_broadcast_to_workspace(self, kernel, workspace_agent):
        token = workspace_agent.token

        # 先索引一個 KB 條目
        kb_entry = kernel.kb_index(
            token,
            KBIndexRequest(content="廣播的新知識", intent="測試廣播"),
        )

        result = kernel.kb_broadcast(
            token,
            KBBroadcastRequest(
                entry=kb_entry,
                workspace_id="ws-research",
                intent="分享新發現",
            ),
        )
        # 回傳收件者列表（此工作區只有此代理，廣播給自己以外的成員）
        assert isinstance(result, list)

    def test_handoff_to_memory_conversion(self):
        bus = IACBus()
        handoff = ContextHandoff(
            source_agent="agent-src",
            target_agent="agent-tgt",
            completed_goal="完成分析",
            key_findings=["發現一", "發現二"],
            relevant_mem_refs=[],
            confidence=0.85,
            next_steps=["下一步"],
        )
        entries = bus.handoff_to_memory_entries(handoff, receiver_id="agent-tgt")
        assert len(entries) >= 3  # 摘要 + 2 個發現 + 下一步
        assert all(e.namespace == "agent-tgt" for e in entries)


# ════════════════════════════════════════════════════════════════════
# L5 Syscall 整合測試
# ════════════════════════════════════════════════════════════════════

class TestL5SyscallIntegration:

    def test_mem_store_and_recall_roundtrip(self, kernel, workspace_agent):
        token = workspace_agent.token
        kernel.mem_store(
            token,
            MemStoreRequest(content="AIOS 使用結構化意圖白名單", intent="記錄設計決策"),
        )
        result = kernel.mem_recall(
            token,
            MemRecallRequest(query="意圖白名單設計", intent="查詢設計決策"),
        )
        from aios.core.models import MemRecallResult
        assert isinstance(result, MemRecallResult)
        assert any("意圖" in e.content for e in result.entries)

    def test_mem_store_denied_wrong_scope(self, kernel, personal_agent):
        token = personal_agent.token
        result = kernel.mem_store(
            token,
            MemStoreRequest(
                content="嘗試寫入工作區",
                scope=MemoryScope.WORKSPACE,
                intent="測試越權寫入",
            ),
        )
        assert isinstance(result, PolicyDecision)
        assert not result.permitted

    def test_kb_search_returns_result(self, kernel, workspace_agent):
        token = workspace_agent.token
        kernel.kb_index(token, KBIndexRequest(content="三層記憶體架構說明", intent="建立知識庫"))
        result = kernel.kb_search(token, KBSearchRequest(query="記憶體架構", intent="查詢知識庫"))
        from aios.core.models import KBSearchResult
        assert isinstance(result, KBSearchResult)

    def test_kb_index_dedup(self, kernel, workspace_agent):
        token = workspace_agent.token
        kernel.kb_index(token, KBIndexRequest(content="唯一內容 XYZ", intent="索引"))
        kernel.kb_index(token, KBIndexRequest(content="唯一內容 XYZ", intent="重複索引"))
        assert kernel.aiofs.count() == 1

    def test_agent_kill_revokes_access(self, kernel, personal_spec):
        state = kernel.agent_spawn(personal_spec)
        token = state.token
        kernel.agent_kill(state.instance_id)
        result = kernel.mem_store(
            token,
            MemStoreRequest(content="已終止代理嘗試寫入", intent="test"),
        )
        assert isinstance(result, PolicyDecision)
        assert not result.permitted

    def test_sys_stats_structure(self, kernel, workspace_agent):
        snap = kernel.sys_stats()
        assert "agents" in snap.model_dump()
        assert "memory" in snap.model_dump()
        assert snap.tools > 0

    def test_child_agent_capabilities_bounded_by_parent(self, kernel, workspace_spec):
        parent = kernel.agent_spawn(workspace_spec)
        parent.token  # ensure token exists

        child_spec = AgentSpec(
            goal="子任務",
            owner="user:alice",
            capabilities=[
                Capability.MEM_READ_PERSONAL,
                Capability.MEM_WRITE_PERSONAL,
                Capability.TOOL_WEB_FETCH,
                Capability.KB_INDEX,  # 父代理有這個
            ],
            max_scope=MemoryScope.WORKSPACE,
            declared_actions=["mem_recall"],
            forbidden_actions=[],
        )

        # 父代理沒有 AGENT_SPAWN_CHILD → 應該失敗
        child = kernel.agent_spawn(child_spec, parent_token=parent.token)
        assert child.status.value == "failed"
