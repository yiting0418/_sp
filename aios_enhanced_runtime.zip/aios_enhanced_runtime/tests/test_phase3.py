"""
tests/test_phase3.py
─────────────────────
Phase 3 分散式與規模化測試。

測試範圍：
  1. 一致性雜湊路由（KV Router + AIOFS）
  2. Local RDMA 傳輸
  3. KV 遷移管理器
  4. 節點註冊與健康檢查
  5. 分離式 Prefill/Decode 協調
  6. Global Scheduler（Filter → Score → Bind）
  7. L3a Syscall Speculator（n-gram 預測 + 快取）
  8. 分散式 AIOFS（一致性雜湊）
  9. AIOS_P2 整合報告
"""

import asyncio
import json
import pytest

from aios.core.models_p3 import (
    KVTransferResult,
    NodeInfo,
    NodeType,
    PrefillNodeAllocation,
    ReplicaPlacement,
    ScheduleType,
    SpeculationMode,
    SpeculationPrediction,
    SyscallTrace,
    TransferUrgency,
)
from aios.l1.kv_router import (
    ConsistentHashRouter,
    KVRouter,
    PrefixCacheMap,
)
from aios.l1.rdma import LocalRDMATransport, KVTransferManager
from aios.l1.disaggregated import DisaggregatedOrchestrator, NodeRegistry
from aios.l1.global_scheduler import (
    GlobalScheduler,
    KVAwareScheduler,
    SchedulerPlugin,
    FilterResult,
    ScoreResult,
)
from aios.l3a.speculator import (
    NGramPredictor,
    SpeculativeCache,
    SyscallSpeculator,
)
from aios.fs.aiofs import DistributedAIOFS, ConsistentHashRing as AIOFSRing, AIOFS
from aios.kernel.aios_p2 import AIOS_P2
from aios.core.models_p2 import InferenceTask, TaskPriority


# ════════════════════════════════════════════════════════════════════
# 一致性雜湊路由（ConsistentHashRouter）
# ════════════════════════════════════════════════════════════════════

class TestConsistentHashRouter:

    def test_route_to_same_node_for_same_key(self):
        router = ConsistentHashRouter()
        router.add_node("node-a", weight=1.0)
        router.add_node("node-b", weight=1.0)
        router.add_node("node-c", weight=1.0)

        node1 = router.route("prefix:abc123")
        node2 = router.route("prefix:abc123")
        assert node1 == node2  # 相同 key 應路由到相同節點

    def test_route_different_keys_may_differ(self):
        router = ConsistentHashRouter()
        router.add_node("node-a")
        router.add_node("node-b")

        keys = [f"key:{i}" for i in range(100)]
        nodes = {router.route(k) for k in keys}
        assert len(nodes) <= 2  # 只路由到兩個節點

    def test_route_multi_returns_unique(self):
        router = ConsistentHashRouter(virtual_nodes=50)
        for i in range(4):
            router.add_node(f"node-{i}")

        result = router.route_multi("test-key", n=3)
        assert len(result) == 3
        assert len(set(result)) == 3  # 不重複

    def test_route_empty_ring(self):
        router = ConsistentHashRouter()
        assert router.route("key") is None

    def test_remove_node(self):
        router = ConsistentHashRouter()
        router.add_node("node-a")
        router.add_node("node-b")
        router.remove_node("node-a")

        for _ in range(50):
            nid = router.route(f"key:{_}")
            assert nid != "node-a"

    def test_add_node_increases_ring(self):
        router = ConsistentHashRouter(virtual_nodes=10)
        router.add_node("node-a")
        size_before = router.ring_size
        router.add_node("node-b")
        assert router.ring_size > size_before


# ════════════════════════════════════════════════════════════════════
# PrefixCacheMap
# ════════════════════════════════════════════════════════════════════

class TestPrefixCacheMap:

    def test_record_and_query(self):
        pcm = PrefixCacheMap()
        pcm.record_hit("hash1", "node-a")
        pcm.record_hit("hash1", "node-b")
        assert pcm.nodes_for_prefix("hash1") == {"node-a", "node-b"}

    def test_eviction_removes_entry(self):
        pcm = PrefixCacheMap()
        pcm.record_hit("hash1", "node-a")
        pcm.record_eviction("hash1", "node-a")
        assert pcm.nodes_for_prefix("hash1") == set()

    def test_remove_node_cleans_all(self):
        pcm = PrefixCacheMap()
        pcm.record_hit("h1", "node-a")
        pcm.record_hit("h2", "node-a")
        pcm.record_hit("h1", "node-b")
        pcm.remove_node("node-a")
        assert pcm.nodes_for_prefix("h1") == {"node-b"}
        assert pcm.nodes_for_prefix("h2") == set()

    def test_prefixes_on_node(self):
        pcm = PrefixCacheMap()
        pcm.record_hit("h1", "node-a")
        pcm.record_hit("h2", "node-a")
        assert pcm.prefixes_on_node("node-a") == {"h1", "h2"}


# ════════════════════════════════════════════════════════════════════
# KVRouter
# ════════════════════════════════════════════════════════════════════

class TestKVRouter:

    def test_route_returns_healthy_node(self):
        registry = NodeRegistry()
        registry.register("node-a", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)
        registry.register("node-b", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)

        router = KVRouter(registry)
        router.add_node("node-a")
        router.add_node("node-b")

        node = router.route_request(prefix_tokens=[1, 2, 3])
        assert node in ("node-a", "node-b")

    def test_route_empty_registry(self):
        registry = NodeRegistry()
        router = KVRouter(registry)
        assert router.route_request([]) is None

    def test_prefix_cache_locality(self):
        registry = NodeRegistry()
        registry.register("node-a", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)
        registry.register("node-b", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)

        router = KVRouter(registry)
        router.add_node("node-a")
        router.add_node("node-b")

        # 模擬 node-b 有 prefix cache
        router._prefix_cache.record_hit(
            router._compute_prefix_hash([1, 2, 3]),
            "node-b",
        )

        node = router.route_request(prefix_tokens=[1, 2, 3])
        assert node == "node-b"  # 應路由到有 cache 的節點

    def test_route_prefill_and_decode(self):
        registry = NodeRegistry()
        registry.register("prefill-1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("decode-1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        router = KVRouter(registry)
        router.add_node("prefill-1")
        router.add_node("decode-1")

        p = router.route_prefill([1, 2])
        d = router.route_decode([1, 2])
        assert p == "prefill-1"
        assert d == "decode-1"


# ════════════════════════════════════════════════════════════════════
# Local RDMA Transport
# ════════════════════════════════════════════════════════════════════

class TestLocalRDMATransport:

    @pytest.mark.asyncio
    async def test_send_and_receive(self):
        transport = LocalRDMATransport()
        transport.register_node("node-a")
        transport.register_node("node-b")

        result = await transport.send(
            source_node="node-a",
            target_node="node-b",
            block_ids=[1, 2],
            payload=["data1", "data2"],
        )
        assert result.success
        assert result.bytes_transferred > 0

        # 驗證目標節點已收到
        remote = transport.get_remote_blocks("node-b")
        assert 1 in remote
        assert 2 in remote
        assert remote[1] == "data1"

    @pytest.mark.asyncio
    async def test_request_remote_blocks(self):
        transport = LocalRDMATransport()
        transport.register_node("node-a")
        transport.register_node("node-b")

        # 先發送
        await transport.send("node-a", "node-b", [42], ["secret"])

        # 再請求
        result = await transport.request("node-c", "node-b", [42])
        assert result.success

        remote = transport.get_remote_blocks("node-c")
        assert remote[42] == "secret"

    @pytest.mark.asyncio
    async def test_request_missing_block_fails(self):
        transport = LocalRDMATransport()
        transport.register_node("node-a")
        transport.register_node("node-b")

        result = await transport.request("node-a", "node-b", [999])
        assert not result.success
        assert "not found" in (result.error or "")

    def test_register_unregister(self):
        transport = LocalRDMATransport()
        transport.register_node("temp")
        transport.unregister_node("temp")


# ════════════════════════════════════════════════════════════════════
# KV Transfer Manager
# ════════════════════════════════════════════════════════════════════

class TestKVTransferManager:

    @pytest.mark.asyncio
    async def test_transfer_blocks(self):
        from aios.l1.kvcache import KVCacheManager

        transport = LocalRDMATransport()
        transport.register_node("src")
        transport.register_node("dst")

        kvcache_nodes = {
            "src": KVCacheManager(total_blocks=64),
            "dst": KVCacheManager(total_blocks=64),
        }

        mgr = KVTransferManager(transport, kvcache_nodes)

        result = await mgr.transfer_blocks(
            source_node="src",
            target_node="dst",
            block_ids=[0, 1, 2],
            sequence_id="seq-1",
            instance_id="inst-1",
            urgency=TransferUrgency.CRITICAL,
        )
        assert result.success

    @pytest.mark.asyncio
    async def test_retry_on_failure(self):
        transport = LocalRDMATransport()
        transport.register_node("src")
        # 故意不註冊 dst — transport.send 仍會回傳 success（只是寫入不存在的節點）
        # 測試 max_retries 機制不會掛掉

        mgr = KVTransferManager(transport, {}, max_retries=2)

        result = await mgr.transfer_blocks(
            source_node="src",
            target_node="missing-node",
            block_ids=[0],
        )
        # 即使目標不存在，LocalRDMATransport 不驗證目標存在
        # 此測試確保 retry loop 不會拋出例外
        assert isinstance(result, KVTransferResult)

    def test_stats_tracking(self):
        from aios.l1.kvcache import KVCacheManager

        transport = LocalRDMATransport()
        transport.register_node("a")
        transport.register_node("b")

        kvcache_nodes = {"a": KVCacheManager(32), "b": KVCacheManager(32)}
        mgr = KVTransferManager(transport, kvcache_nodes)

        async def run():
            for _ in range(3):
                await mgr.transfer_blocks("a", "b", [0])

        asyncio.run(run())
        assert mgr.stats.total_transfers == 3
        assert mgr.stats.success_rate == 1.0


# ════════════════════════════════════════════════════════════════════
# NodeRegistry
# ════════════════════════════════════════════════════════════════════

class TestNodeRegistry:

    def test_register_and_get(self):
        registry = NodeRegistry()
        info = registry.register(
            "node-1", NodeType.HYBRID,
            address="10.0.0.1:9000", vram_mb=80_000, kv_blocks=256,
        )
        assert info.node_id == "node-1"
        assert registry.get_node("node-1") is info

    def test_unregister(self):
        registry = NodeRegistry()
        registry.register("node-1", NodeType.PREFILL_ONLY)
        registry.unregister("node-1")
        assert registry.get_node("node-1") is None

    def test_heartbeat(self):
        registry = NodeRegistry(heartbeat_timeout_s=5.0)
        registry.register("node-1", NodeType.HYBRID)
        assert registry.heartbeat("node-1") is True
        assert registry.heartbeat("missing") is False

    def test_healthy_nodes(self):
        registry = NodeRegistry(heartbeat_timeout_s=0.0)  # 立即超時
        registry.register("node-1", NodeType.HYBRID)
        assert len(registry.healthy_nodes()) == 0

    def test_list_by_type(self):
        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY)
        registry.register("d1", NodeType.DECODE_ONLY)
        registry.register("h1", NodeType.HYBRID)

        # list_by_type 也包含 HYBRID（hybrid 節點可服務兩者）
        assert len(registry.list_by_type(NodeType.PREFILL_ONLY)) == 2  # p1 + h1
        assert len(registry.list_by_type(NodeType.DECODE_ONLY)) == 2   # d1 + h1
        assert len(registry.list_by_type(NodeType.HYBRID)) == 1

    def test_best_nodes(self):
        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("d1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        prefill = registry.best_prefill_node()
        decode  = registry.best_decode_node()
        assert prefill is not None
        assert decode is not None

    def test_load_score(self):
        registry = NodeRegistry()
        registry.register("node-1", NodeType.HYBRID)
        registry.update_load("node-1", vram_used=40_000, kv_used=128, active_tasks=5)
        node = registry.get_node("node-1")
        assert node is not None
        assert 0.0 < node.load_score <= 1.0

    def test_stats(self):
        registry = NodeRegistry()
        registry.register("n1", NodeType.PREFILL_ONLY, vram_mb=80_000)
        registry.register("n2", NodeType.DECODE_ONLY, vram_mb=40_000)
        stats = registry.stats
        assert stats["total_nodes"] == 2
        assert stats["total_vram_mb"] == 120_000


# ════════════════════════════════════════════════════════════════════
# 分離式 Prefill/Decode
# ════════════════════════════════════════════════════════════════════

class TestDisaggregatedOrchestrator:

    @pytest.mark.asyncio
    async def test_orchestrate_allocates_nodes(self):
        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("d1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        transport = LocalRDMATransport()
        transport.register_node("p1")
        transport.register_node("d1")

        mgr = KVTransferManager(transport, {})

        orch = DisaggregatedOrchestrator(registry, mgr, {})

        alloc = await orch.orchestrate(
            task_id="task-1",
            instance_id="inst-1",
            prompt_tokens=512,
        )
        assert alloc.task_id == "task-1"
        assert alloc.prefill_node == "p1"
        assert alloc.decode_node == "d1"

    @pytest.mark.asyncio
    async def test_orchestrate_no_prefill_node(self):
        registry = NodeRegistry()
        transport = LocalRDMATransport()
        mgr = KVTransferManager(transport, {})
        orch = DisaggregatedOrchestrator(registry, mgr, {})

        with pytest.raises(RuntimeError, match="no available prefill node"):
            await orch.orchestrate("task-1", "inst-1", 512)

    @pytest.mark.asyncio
    async def test_transfer_to_decode(self):
        from aios.l1.kvcache import KVCacheManager

        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("d1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        transport = LocalRDMATransport()
        transport.register_node("p1")
        transport.register_node("d1")

        kvc_nodes = {"p1": KVCacheManager(64), "d1": KVCacheManager(64)}
        mgr = KVTransferManager(transport, kvc_nodes)
        orch = DisaggregatedOrchestrator(registry, mgr, kvc_nodes)

        alloc = await orch.orchestrate("task-1", "inst-1", 512)
        result = await orch.transfer_to_decode(
            "task-1", block_ids=[0, 1], sequence_id="seq-1", instance_id="inst-1",
        )
        assert result.success

    def test_release(self):
        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("d1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        transport = LocalRDMATransport()
        transport.register_node("p1")
        transport.register_node("d1")

        mgr = KVTransferManager(transport, {})
        orch = DisaggregatedOrchestrator(registry, mgr, {})

        async def run():
            await orch.orchestrate("task-1", "inst-1", 512)
            orch.release("task-1")
            assert orch.allocation_for("task-1") is None

        asyncio.run(run())


# ════════════════════════════════════════════════════════════════════
# Global Scheduler
# ════════════════════════════════════════════════════════════════════

class TestGlobalScheduler:

    def test_schedule_assigns_node(self):
        registry = NodeRegistry()
        registry.register("node-a", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)

        scheduler = GlobalScheduler(registry)
        task = InferenceTask(task_id="t1", instance_id="i1", prompt_tokens=100, priority=TaskPriority.NORMAL)

        decision = scheduler.schedule(task)
        assert decision.node_id == "node-a"
        assert decision.score > 0

    def test_schedule_no_healthy_nodes(self):
        registry = NodeRegistry(heartbeat_timeout_s=0.0)
        registry.register("node-a", NodeType.HYBRID)

        scheduler = GlobalScheduler(registry)
        task = InferenceTask(task_id="t1", prompt_tokens=100)

        decision = scheduler.schedule(task)
        assert decision.node_id == ""
        assert "healthy" in decision.reason

    def test_kv_aware_filter(self):
        registry = NodeRegistry()
        registry.register("p1", NodeType.PREFILL_ONLY, vram_mb=80_000, kv_blocks=256)
        registry.register("d1", NodeType.DECODE_ONLY, vram_mb=80_000, kv_blocks=256)

        plugin = KVAwareScheduler(registry)
        nodes = registry.list_nodes()
        task = InferenceTask(task_id="t1", prompt_tokens=100)

        from aios.core.models_p3 import ScheduleType

        # Prefill 任務應通過 p1，過濾 d1
        result = plugin.filter(nodes, task, ScheduleType.PREFILL)
        assert any(n.node_id == "p1" for n in result.passed)
        assert any(
            n.node_id == "d1" for n in nodes if n.node_id not in {x.node_id for x in result.passed}
        )

    def test_kv_aware_score(self):
        registry = NodeRegistry()
        registry.register("n1", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)
        registry.register("n2", NodeType.HYBRID, vram_mb=80_000, kv_blocks=256)

        # 讓 n1 負載較高，n2 負載較低
        registry.update_load("n1", vram_used=60_000, kv_used=192, active_tasks=8)
        registry.update_load("n2", vram_used=10_000, kv_used=32, active_tasks=1)

        plugin = KVAwareScheduler(registry)
        task = InferenceTask(task_id="t1", prompt_tokens=100)
        result = plugin.score(registry.list_nodes(), task, None)

        # n2 負載較輕應有較高分數
        assert result.scores["n2"] > result.scores["n1"]

    def test_bind_records_decision(self):
        registry = NodeRegistry()
        registry.register("n1", NodeType.HYBRID)

        scheduler = GlobalScheduler(registry)
        task = InferenceTask(task_id="t1", prompt_tokens=100)

        decision = scheduler.schedule(task)
        assert decision.node_id != ""


# ════════════════════════════════════════════════════════════════════
# n-gram 預測模型
# ════════════════════════════════════════════════════════════════════

class TestNGramPredictor:

    def test_observe_and_predict(self):
        predictor = NGramPredictor(n=3, min_samples=1)
        inst = "test-agent"

        # 反覆觀察固定序列：mem_recall → mem_recall → tool_call
        # 讓序列最後停在 mem_recall → mem_recall
        traces = [
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
            SyscallTrace(instance_id=inst, syscall_name="tool_call"),
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
            SyscallTrace(instance_id=inst, syscall_name="tool_call"),
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
            SyscallTrace(instance_id=inst, syscall_name="mem_recall"),
        ]
        for t in traces:
            predictor.observe(t)

        # 最後 2 個 syscall 是 mem_recall → mem_recall
        # ngram 中此 context 後應預測 tool_call（出現 2 次）
        pred = predictor.predict(inst)
        assert pred.predicted_syscall == "tool_call"
        assert pred.probability > 0

    def test_predict_insufficient_data(self):
        predictor = NGramPredictor(n=3)
        pred = predictor.predict("unknown-instance")
        assert pred.predicted_syscall == ""
        assert pred.probability == 0.0

    def test_stats(self):
        predictor = NGramPredictor()
        stats = predictor.stats
        assert "ngram_size" in stats
        assert "active_instances" in stats
        assert "total_traces" in stats


# ════════════════════════════════════════════════════════════════════
# Speculative Cache
# ════════════════════════════════════════════════════════════════════

class TestSpeculativeCache:

    def test_put_and_get(self):
        cache = SpeculativeCache(default_ttl_s=60.0)
        cache.put("mem_recall", {"query": "test"}, ["result1"])
        cached = cache.get("mem_recall", {"query": "test"})
        assert cached is not None
        assert cached.result == ["result1"]

    def test_miss(self):
        cache = SpeculativeCache()
        assert cache.get("mem_recall", {"query": "x"}) is None

    def test_hit_rate(self):
        cache = SpeculativeCache(default_ttl_s=60.0)
        cache.put("mem_recall", {"query": "test"}, "result")
        cache.get("mem_recall", {"query": "test"})
        cache.get("mem_recall", {"query": "missing"})
        assert cache.hit_rate == 0.5

    def test_invalidate(self):
        cache = SpeculativeCache(default_ttl_s=60.0)
        cache.put("mem_recall", {"q": "1"}, "r1")
        cache.put("kb_search", {"q": "2"}, "r2")
        removed = cache.invalidate("mem_recall")
        assert removed >= 1
        assert cache.get("mem_recall", {"q": "1"}) is None


# ════════════════════════════════════════════════════════════════════
# Syscall Speculator
# ════════════════════════════════════════════════════════════════════

class TestSyscallSpeculator:

    def test_default_mode_is_observe(self):
        spec = SyscallSpeculator()
        assert spec.mode == SpeculationMode.OBSERVE

    def test_set_mode(self):
        spec = SyscallSpeculator()
        spec.set_mode(SpeculationMode.PREDICT)
        assert spec.mode == SpeculationMode.PREDICT

    def test_observe_and_predict(self):
        spec = SyscallSpeculator(mode=SpeculationMode.PREDICT)
        inst = "test-agent"

        for _ in range(5):
            spec.observe(SyscallTrace(instance_id=inst, syscall_name="mem_recall"))
            spec.observe(SyscallTrace(instance_id=inst, syscall_name="tool_call"))

        pred = spec.predict(inst)
        # 應有預測結果（序列已建立）
        assert isinstance(pred, SpeculationPrediction)

    def test_cache_result_and_check(self):
        spec = SyscallSpeculator()
        spec.cache_result("mem_recall", {"query": "hello"}, {"entries": []})
        result = spec.check_cache("mem_recall", {"query": "hello"})
        assert result is not None
        assert result["entries"] == []

    def test_cache_miss_returns_none(self):
        spec = SyscallSpeculator()
        assert spec.check_cache("mem_recall", {"query": "missing"}) is None

    def test_stats(self):
        spec = SyscallSpeculator(mode=SpeculationMode.PREDICT)
        stats = spec.stats
        assert stats["mode"] == "predict"
        assert "predictor" in stats
        assert "cache_hit_rate" in stats

    def test_prefetch_validates_read_only(self):
        spec = SyscallSpeculator(mode=SpeculationMode.PREDICT)

        async def run():
            pred = SpeculationPrediction(
                predicted_syscall="mem_store",
                is_read_only=False,
            )
            result = await spec.prefetch(None, pred)
            assert result is None  # 不預取有副作用的 syscall

        asyncio.run(run())

    def test_off_mode_does_not_predict(self):
        spec = SyscallSpeculator(mode=SpeculationMode.OFF)
        spec.observe(SyscallTrace(instance_id="a1", syscall_name="mem_recall"))
        pred = spec.predict("a1")
        assert pred.predicted_syscall == ""


# ════════════════════════════════════════════════════════════════════
# 分散式 AIOFS（一致性雜湊）
# ════════════════════════════════════════════════════════════════════

class TestAIOFSHashRing:

    def test_place_assigns_primary(self):
        ring = AIOFSRing(virtual_nodes=50)
        ring.add_node("node-a")
        ring.add_node("node-b")
        ring.add_node("node-c")

        placement = ring.place("some-content-hash")
        assert placement.primary_node != ""
        assert len(placement.replica_nodes) >= 1

    def test_place_replicas_differ_from_primary(self):
        ring = AIOFSRing(virtual_nodes=50, replication_factor=2)
        ring.add_node("n1")
        ring.add_node("n2")
        ring.add_node("n3")

        placement = ring.place("hash-123")
        assert placement.primary_node not in placement.replica_nodes

    def test_is_responsible(self):
        ring = AIOFSRing(virtual_nodes=50)
        ring.add_node("node-a")
        ring.add_node("node-b")
        placement = ring.place("test-content")
        assert ring.is_responsible(placement.primary_node, "test-content")
        for replica in placement.replica_nodes:
            assert ring.is_responsible(replica, "test-content")

    def test_remove_node_reroutes(self):
        ring = AIOFSRing(virtual_nodes=50)
        ring.add_node("n1")
        ring.add_node("n2")
        placement_before = ring.place("fixed-hash")
        ring.remove_node("n1")
        placement_after = ring.place("fixed-hash")
        # 至少 primary 應該不同（因為 n1 可能原本是 primary）
        assert isinstance(placement_after, ReplicaPlacement)


class TestDistributedAIOFS:

    def test_index_routes_to_node(self):
        ddfs = DistributedAIOFS()
        ddfs.add_node("node-a")
        ddfs.add_node("node-b")
        ddfs.set_local_node("node-a")

        entry = ddfs.index("hello world")
        assert entry is not None
        assert "storage_node" in entry.metadata

    def test_search_merges_results(self):
        ddfs = DistributedAIOFS()
        ddfs.add_node("n1")
        ddfs.add_node("n2")
        ddfs.set_local_node("n1")

        ddfs.index("機器學習基礎")
        ddfs.index("深度學習進階")
        ddfs.index("Python 程式設計")

        results = ddfs.search("學習", top_k=5)
        assert len(results) >= 2  # 應找到至少 2 個相關結果

    def test_get_by_hash(self):
        ddfs = DistributedAIOFS()
        ddfs.add_node("n1")
        ddfs.add_node("n2")
        ddfs.set_local_node("n1")

        entry = ddfs.index("unique content 42")
        fetched = ddfs.get_by_hash(entry.content_hash)
        assert fetched is not None
        assert fetched.content == "unique content 42"

    def test_tiering_pass(self):
        ddfs = DistributedAIOFS()
        ddfs.add_node("n1")
        ddfs.add_node("n2")

        ddfs.index("data1")
        ddfs.index("data2")

        counts = ddfs.run_tiering_pass()
        assert sum(counts.values()) >= 2

    def test_stats(self):
        ddfs = DistributedAIOFS()
        ddfs.add_node("n1")
        ddfs.add_node("n2")

        stats = ddfs.stats()
        assert stats["nodes"] == 2
        assert stats["ring_size"] > 0


# ════════════════════════════════════════════════════════════════════
# AIOS_P2 整合測試
# ════════════════════════════════════════════════════════════════════

class TestAIOS_P2_Phase3:

    def test_build_with_distributed(self):
        p2 = AIOS_P2.build(
            total_kv_blocks=64,
            enable_distributed=True,
            num_nodes=3,
        )
        assert p2.node_registry is not None
        assert p2.rdma_transport is not None
        assert p2.kv_transfer_mgr is not None
        assert p2.disaggregated is not None
        assert p2.global_scheduler is not None
        assert p2.kv_router is not None
        assert p2.syscall_speculator is not None
        assert p2.distributed_aiofs is not None

    def test_full_report_includes_phase3(self):
        p2 = AIOS_P2.build(total_kv_blocks=64, enable_distributed=True, num_nodes=3)
        report = p2.full_report()

        assert "p3_node_registry" in report
        assert "p3_rdma_transfers" in report
        assert "p3_global_scheduler" in report
        assert "p3_kv_router" in report
        assert "p3_speculator" in report
        assert "p3_distributed_aiofs" in report

    def test_phase2_compatibility(self):
        """Phase 3 不破壞 Phase 2 功能。"""
        p2 = AIOS_P2.build(total_kv_blocks=64, enable_distributed=True)
        report = p2.full_report()
        assert "l1_kvcache" in report
        assert "l1_scheduler" in report
        assert "l2_model_manager" in report
        assert "l2_snapshots" in report
        assert "l5_kernel" in report

    def test_global_scheduler_integration(self):
        p2 = AIOS_P2.build(enable_distributed=True, num_nodes=3)
        task = InferenceTask(
            task_id="integ-test",
            instance_id="inst-1",
            model_id="test-model",
            prompt_tokens=512,
            priority=TaskPriority.HIGH,
        )

        from aios.core.models_p3 import ScheduleType
        decision = p2.global_scheduler.schedule(task, ScheduleType.PREFILL)
        assert decision.node_id != ""
        assert decision.score > 0

    def test_speculator_observe_cycle(self):
        p2 = AIOS_P2.build(enable_distributed=True)
        spec = p2.syscall_speculator

        for i in range(10):
            spec.observe(SyscallTrace(
                instance_id="test-agent",
                syscall_name="mem_recall" if i % 2 == 0 else "tool_call",
            ))

        spec.set_mode(SpeculationMode.PREDICT)
        pred = spec.predict("test-agent")
        assert isinstance(pred, SpeculationPrediction)
