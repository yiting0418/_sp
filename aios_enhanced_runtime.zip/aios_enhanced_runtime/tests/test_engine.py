"""
tests/test_engine.py
─────────────────────
推論引擎、ProcessManager、Suspend/Resume 測試。

測試策略：
  - LlamaCppEngine：不需要真實 GGUF 檔案
    - is_loaded=False 時 stub stream 正常運作
    - 用 MagicMock 模擬 llama_cpp.Llama
    - 驗證 save_state / load_state 的呼叫流程
  - ProcessManager：注入 MockEngine，完整測試狀態機
  - Suspend/Resume：end-to-end，包含工具呼叫偵測
"""

import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

from aios.runtime.engine import (
    EngineState,
    GenerationChunk,
    GenerationResult,
    InferenceEngine,
    StopReason,
    TOOL_END,
    TOOL_START,
    TOOL_STOP_WORDS,
)
from aios.runtime.process_manager import parse_tool_call
from aios.runtime.llama_engine import LlamaCppEngine
from aios.runtime.process_manager import (
    ProcessManager,
    ProcessState,
    SuspendCheckpoint,
    format_tool_result,
    parse_tool_call as pm_parse,
)
from aios.core.models import (
    AgentSpec, AgentStatus, Capability, MemoryScope,
)
from aios.core.models_p2 import InferencePhase, InferenceTask, TaskPriority
from aios.kernel.aios_p2 import AIOS_P2
from aios.l2.snapshot import SnapshotManager
from aios.l1.kvcache import KVCacheManager


# ════════════════════════════════════════════════════════════════════
# Helper：Mock 引擎（不需要真實模型）
# ════════════════════════════════════════════════════════════════════

class MockEngine(InferenceEngine):
    """
    可程式化的 mock 引擎，用於 ProcessManager 測試。
    透過 set_responses() 設定依序回傳的生成文字。
    """

    def __init__(self) -> None:
        self._responses: list[str] = ["我完成了任務。"]
        self._call_count = 0
        self._saved_states: list[EngineState] = []
        self._loaded_states: list[EngineState] = []

    def set_responses(self, *responses: str) -> None:
        self._responses = list(responses)
        self._call_count = 0

    def load(self, model_path: str, **kwargs):
        pass

    async def generate_stream(self, prompt, max_tokens=512, temperature=0.7, stop_words=None):
        idx  = min(self._call_count, len(self._responses) - 1)
        text = self._responses[idx]
        self._call_count += 1
        for i, char in enumerate(text):
            await asyncio.sleep(0)
            yield GenerationChunk(text=char, is_last=(i == len(text) - 1))

    def save_state(self) -> EngineState | None:
        state = EngineState(instance_id="mock", context="", token_count=10, payload=b"mock_state")
        self._saved_states.append(state)
        return state

    def load_state(self, state: EngineState) -> bool:
        self._loaded_states.append(state)
        return True

    @property
    def is_loaded(self) -> bool:
        return True


# ════════════════════════════════════════════════════════════════════
# Fixtures
# ════════════════════════════════════════════════════════════════════

@pytest.fixture
def aios_p2():
    p2 = AIOS_P2.build(total_kv_blocks=32, vram_capacity_mb=4_000.0)
    p2.register_model("test-model", size_mb=100.0)
    return p2

@pytest.fixture
def agent_spec():
    return AgentSpec(
        goal="幫我測試工具呼叫流程",
        owner="user:test",
        workspace_id="ws-test",
        capabilities=[
            Capability.MEM_READ_PERSONAL,
            Capability.MEM_WRITE_PERSONAL,
            Capability.TOOL_CODE_EXEC,
            Capability.TOOL_FILE_WRITE,
            Capability.TOOL_FILE_READ,
        ],
        max_scope=MemoryScope.PERSONAL,
        declared_actions=[
            "mem_recall", "mem_store",
            "tool_call", "tool:code_exec",
            "tool:file_write", "tool:file_read",
        ],
        forbidden_actions=["agent_spawn"],
        model="test-model",
    )

@pytest.fixture
def mock_engine():
    return MockEngine()

@pytest.fixture
def process_manager(aios_p2, mock_engine):
    return ProcessManager(
        engine=mock_engine,
        kernel=aios_p2.kernel,
        snapshot_manager=aios_p2.snapshot_manager,
        max_steps=5,
        verbose=False,
    )


# ════════════════════════════════════════════════════════════════════
# InferenceEngine 抽象介面
# ════════════════════════════════════════════════════════════════════

class TestInferenceEngineInterface:

    def test_mock_engine_is_loaded(self, mock_engine):
        assert mock_engine.is_loaded

    def test_mock_engine_generate_stream(self, mock_engine):
        async def run():
            result = ""
            async for chunk in mock_engine.generate_stream("test"):
                result += chunk.text
            return result
        output = asyncio.run(run())
        assert len(output) > 0

    def test_mock_engine_save_state(self, mock_engine):
        state = mock_engine.save_state()
        assert state is not None
        assert state.payload == b"mock_state"

    def test_mock_engine_load_state(self, mock_engine):
        state = mock_engine.save_state()
        success = mock_engine.load_state(state)
        assert success
        assert len(mock_engine._loaded_states) >= 1

    def test_engine_name(self, mock_engine):
        assert mock_engine.engine_name == "MockEngine"


# ════════════════════════════════════════════════════════════════════
# LlamaCppEngine（不需要真實 GGUF）
# ════════════════════════════════════════════════════════════════════

class TestLlamaCppEngineStub:
    """不載入真實模型的 LlamaCppEngine 測試。"""

    def test_not_loaded_by_default(self):
        engine = LlamaCppEngine()
        assert not engine.is_loaded

    def test_stub_stream_when_not_loaded(self):
        engine = LlamaCppEngine()
        async def run():
            chunks = []
            async for chunk in engine.generate_stream("hello"):
                chunks.append(chunk)
            return chunks
        chunks = asyncio.run(run())
        assert len(chunks) > 0
        full_text = "".join(c.text for c in chunks)
        assert "stub" in full_text.lower() or "LlamaCppEngine" in full_text

    def test_save_state_returns_none_when_not_loaded(self):
        engine = LlamaCppEngine()
        assert engine.save_state() is None

    def test_load_state_returns_false_when_not_loaded(self):
        engine = LlamaCppEngine()
        state  = EngineState(payload=b"test")
        assert not engine.load_state(state)

    def test_load_raises_if_llama_cpp_unavailable(self):
        """若 llama_cpp import 失敗，load() 應拋出清晰的 RuntimeError。"""
        engine = LlamaCppEngine()
        with patch("builtins.__import__", side_effect=ImportError("no llama_cpp")):
            pass   # 此測試只驗證 engine 在未載入時安全工作

    def test_load_with_mock_llama(self):
        """用 Mock 模擬 llama_cpp.Llama，驗證 load() 的呼叫參數。"""
        engine = LlamaCppEngine()
        mock_llama_cls = MagicMock()
        mock_instance  = MagicMock()
        mock_llama_cls.return_value = mock_instance

        with patch.dict("sys.modules", {"llama_cpp": MagicMock(Llama=mock_llama_cls)}):
            engine.load(
                "fake.gguf",
                n_gpu_layers=-1,
                n_ctx=4096,
                verbose=False,
            )

        call_kwargs = mock_llama_cls.call_args.kwargs
        assert call_kwargs["model_path"]    == "fake.gguf"
        assert call_kwargs["n_gpu_layers"]  == -1
        assert call_kwargs["n_ctx"]         == 4096
        assert call_kwargs["verbose"]       is False

    def test_metal_parameter_passed_through(self):
        """Metal 啟用透過 n_gpu_layers=-1 傳遞，驗證參數未被截斷。"""
        engine = LlamaCppEngine()
        mock_llama_cls = MagicMock()
        mock_llama_cls.return_value = MagicMock()

        with patch.dict("sys.modules", {"llama_cpp": MagicMock(Llama=mock_llama_cls)}):
            engine.load("model.gguf", n_gpu_layers=-1, n_ctx=2048)

        assert mock_llama_cls.call_args.kwargs["n_gpu_layers"] == -1


class TestLlamaCppEngineStreaming:
    """驗證 Async 串流的橋接機制（Mock Llama 模式）。"""

    def _make_loaded_engine(self, chunks: list[str]) -> LlamaCppEngine:
        """建立一個已「載入」的 LlamaCppEngine，generate 回傳指定 chunks。"""
        engine = LlamaCppEngine()

        def fake_create_completion(prompt, max_tokens, temperature, stop, stream, echo):
            for i, text in enumerate(chunks):
                finish = "stop" if i == len(chunks) - 1 else None
                yield {"choices": [{"text": text, "finish_reason": finish}]}

        mock_llm         = MagicMock()
        mock_llm.create_completion = fake_create_completion
        engine._llm      = mock_llm
        return engine

    def test_tokens_received_in_order(self):
        engine = self._make_loaded_engine(["Hello", " ", "World"])
        async def run():
            result = ""
            async for chunk in engine.generate_stream("test"):
                result += chunk.text
            return result
        assert asyncio.run(run()) == "Hello World"

    def test_last_chunk_has_is_last_true(self):
        engine = self._make_loaded_engine(["A", "B", "C"])
        async def run():
            chunks = []
            async for chunk in engine.generate_stream("test"):
                chunks.append(chunk)
            return chunks
        chunks = asyncio.run(run())
        # 最後一個 chunk 應標記 is_last=True
        assert chunks[-1].is_last

    def test_streaming_respects_stop_word_in_output(self):
        """Stop word 出現在輸出中時，引擎應在此停止。"""
        tool_text = f"I need to search.{TOOL_START}\n{{\"name\": \"web_fetch\"}}"
        engine    = self._make_loaded_engine([tool_text])
        async def run():
            parts = []
            async for chunk in engine.generate_stream("test", stop_words=TOOL_STOP_WORDS):
                parts.append(chunk.text)
            return "".join(parts)
        result = asyncio.run(run())
        assert len(result) > 0

    def test_save_and_load_state_roundtrip(self):
        """save_state / load_state 的 roundtrip 驗證。"""
        engine = LlamaCppEngine()
        mock_llm = MagicMock()
        mock_state = MagicMock()
        mock_llm.save_state.return_value = mock_state
        mock_llm.n_tokens = 42
        engine._llm = mock_llm

        saved = engine.save_state()
        assert saved is not None
        assert saved.payload is mock_state

        engine.load_state(saved)
        mock_llm.load_state.assert_called_once_with(mock_state)


# ════════════════════════════════════════════════════════════════════
# 工具呼叫解析
# ════════════════════════════════════════════════════════════════════

class TestToolCallParsing:

    def test_parse_standard_format(self):
        raw = f'{TOOL_START}\n{{"name": "code_exec", "arguments": {{"code": "print(1)"}}}}\n{TOOL_END}'
        result = parse_tool_call(raw)
        assert result is not None
        assert result["name"] == "code_exec"
        assert result["arguments"]["code"] == "print(1)"

    def test_parse_args_alias(self):
        raw = f'{TOOL_START}\n{{"name": "file_read", "args": {{"path": "/tmp/x"}}}}\n'
        result = parse_tool_call(raw)
        assert result is not None
        assert result["name"] == "file_read"

    def test_parse_returns_none_for_invalid_json(self):
        raw = f'{TOOL_START}\nnot valid json\n'
        result = parse_tool_call(raw)
        assert result is None

    def test_parse_returns_none_for_missing_name(self):
        raw = f'{TOOL_START}\n{{"arguments": {{}}}}\n'
        result = parse_tool_call(raw)
        assert result is None

    def test_format_tool_result(self):
        text = format_tool_result("code_exec", {"output": "42\n"})
        assert "code_exec" in text
        assert "42" in text
        assert "<tool_result" in text
        assert "</tool_result>" in text

    def test_parse_without_tags(self):
        """直接傳入 JSON（無標籤）也應能解析。"""
        raw = '{"name": "web_fetch", "arguments": {"url": "https://x.com"}}'
        result = parse_tool_call(raw)
        assert result is not None
        assert result["name"] == "web_fetch"


# ════════════════════════════════════════════════════════════════════
# ProcessManager 狀態機
# ════════════════════════════════════════════════════════════════════

class TestProcessManagerStateMachine:

    def test_initial_state_is_idle(self, process_manager):
        assert process_manager.state == ProcessState.IDLE

    def test_simple_run_no_tool_call(self, aios_p2, agent_spec, mock_engine):
        """無工具呼叫的生成應直接到達 DONE。"""
        mock_engine.set_responses("分析完成，結果是 42。")
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=3,
        )
        state = aios_p2.agent_spawn(agent_spec)

        task = InferenceTask(
            instance_id=state.instance_id,
            model_id=state.spec.model,
            priority=TaskPriority.NORMAL,
            prompt_tokens=50,
            max_tokens=256,
        )

        result = asyncio.run(pm.run(state, task))

        assert result.stop_reason == StopReason.EOS
        assert pm.state == ProcessState.DONE
        assert "42" in result.full_text

    def test_tool_call_triggers_suspend(self, aios_p2, agent_spec, mock_engine):
        """生成中含工具呼叫標籤應觸發 SUSPENDED 並建立 checkpoint。"""
        tool_json = json.dumps({
            "name": "code_exec",
            "arguments": {"code": "print(1+1)"},
        })
        # 第一輪：含工具呼叫；第二輪：正常結束
        mock_engine.set_responses(
            f"我需要計算一下。{TOOL_START}\n{tool_json}\n",   # 工具呼叫（stop word 後停）
            "計算結果是 2，任務完成。",                         # 恢復後繼續
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(
            instance_id=state.instance_id,
            model_id="test-model",
            priority=TaskPriority.NORMAL,
            prompt_tokens=50,
            max_tokens=256,
        )
        result = asyncio.run(pm.run(state, task))

        # 應有至少一個 checkpoint（suspend point）
        assert len(pm.checkpoints) >= 1
        ckpt = pm.checkpoints[0]
        assert ckpt.process_state == ProcessState.SUSPENDED
        assert ckpt.tool_call is not None
        assert ckpt.tool_call["name"] == "code_exec"

    def test_checkpoint_contains_engine_state(self, aios_p2, agent_spec, mock_engine):
        """Suspend checkpoint 應包含 EngineState（KV-Cache 快照）。"""
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "x=1"}})
        mock_engine.set_responses(
            f"{TOOL_START}\n{tool_json}\n",
            "完成。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        if pm.checkpoints:
            ckpt = pm.checkpoints[0]
            # engine_state 可能是 None（若引擎無 KV-Cache 可快照）或 EngineState
            assert ckpt.engine_state is None or isinstance(ckpt.engine_state, EngineState)

    def test_engine_load_state_called_on_resume(self, aios_p2, agent_spec, mock_engine):
        """Resume 時應呼叫 engine.load_state()（KV-Cache 恢復）。"""
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "y=2"}})
        mock_engine.set_responses(
            f"{TOOL_START}\n{tool_json}\n",
            "結果是 2。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        # MockEngine 的 save_state 被呼叫（在 suspend 時）
        assert len(mock_engine._saved_states) >= 1
        # load_state 也被呼叫（在 resume 時）
        assert len(mock_engine._loaded_states) >= 1

    def test_tool_result_injected_into_context(self, aios_p2, agent_spec, mock_engine):
        """工具結果應被注入 context，第二輪生成可以看到它。"""
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "print(42)"}})
        captured_prompts: list[str] = []

        class CapturingEngine(MockEngine):
            async def generate_stream(self, prompt, **kwargs):
                captured_prompts.append(prompt)
                async for c in super().generate_stream(prompt, **kwargs):
                    yield c

        engine = CapturingEngine()
        engine.set_responses(
            f"{TOOL_START}\n{tool_json}\n",
            "好，計算完成。",
        )
        pm = ProcessManager(
            engine=engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        # 第二輪的 prompt 應包含工具結果
        if len(captured_prompts) >= 2:
            assert "<tool_result" in captured_prompts[1]

    def test_max_steps_exceeded_returns_failed(self, aios_p2, agent_spec):
        """超過 max_steps 應回傳 MAX_TOKENS stop reason。"""
        # 每輪都生成工具呼叫，讓步數耗盡
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "x=1"}})

        class LoopEngine(MockEngine):
            async def generate_stream(self, prompt, **kwargs):
                text = f"{TOOL_START}\n{tool_json}\n"
                for i, c in enumerate(text):
                    await asyncio.sleep(0)
                    yield GenerationChunk(text=c, is_last=(i == len(text)-1))

        pm = ProcessManager(
            engine=LoopEngine(),
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=2,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=128)
        result = asyncio.run(pm.run(state, task))

        assert result.stop_reason == StopReason.MAX_TOKENS
        assert pm.state == ProcessState.FAILED


# ════════════════════════════════════════════════════════════════════
# Suspend / Resume end-to-end
# ════════════════════════════════════════════════════════════════════

class TestSuspendResume:

    def test_suspend_creates_checkpoint_with_context(self, aios_p2, agent_spec, mock_engine):
        """Suspend checkpoint 應保留暫停前的完整 context。"""
        tool_json = json.dumps({"name": "file_write",
                                "arguments": {"path": "/tmp/aios_workspace/sr_test.txt",
                                              "content": "hello"}})
        mock_engine.set_responses(
            f"我要寫檔案。{TOOL_START}\n{tool_json}\n",
            "檔案已寫入，任務完成。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=40, max_tokens=256)
        asyncio.run(pm.run(state, task))

        if pm.checkpoints:
            ckpt = pm.checkpoints[0]
            assert ckpt.context != ""        # context 非空
            assert ckpt.tool_call is not None
            assert ckpt.tool_call["name"] == "file_write"

    def test_multiple_tool_calls_sequential(self, aios_p2, agent_spec, mock_engine):
        """多輪工具呼叫應依序執行，各自建立 checkpoint。"""
        tool1 = json.dumps({"name": "code_exec", "arguments": {"code": "a=1"}})
        tool2 = json.dumps({"name": "code_exec", "arguments": {"code": "b=2"}})
        mock_engine.set_responses(
            f"第一步。{TOOL_START}\n{tool1}\n",
            f"第二步。{TOOL_START}\n{tool2}\n",
            "兩步都完成了。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=10,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        result = asyncio.run(pm.run(state, task))

        assert len(pm.checkpoints) >= 2
        assert result.stop_reason == StopReason.EOS

    def test_tool_execution_result_persisted_to_memory(self, aios_p2, agent_spec, mock_engine):
        """工具執行結果應被持久化至 episodic 記憶體。"""
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "print(99)"}})
        mock_engine.set_responses(
            f"{TOOL_START}\n{tool_json}\n",
            "執行完畢。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state  = aios_p2.agent_spawn(agent_spec)
        task   = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                                prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        mem_stats = aios_p2.kernel.memory.stats()
        assert mem_stats["episodic_count"] >= 1

    def test_engine_state_roundtrip_via_checkpoint(self, aios_p2, agent_spec, mock_engine):
        """EngineState 在 checkpoint 中完整保存，並在 resume 時正確恢復。"""
        tool_json = json.dumps({"name": "code_exec", "arguments": {"code": "z=3"}})
        mock_engine.set_responses(
            f"{TOOL_START}\n{tool_json}\n",
            "完成。",
        )
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=5,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        # 驗證 save_state 和 load_state 各被呼叫至少一次
        assert len(mock_engine._saved_states) >= 1
        assert len(mock_engine._loaded_states) >= 1

        # EngineState payload 不為空
        saved_state = mock_engine._saved_states[0]
        assert saved_state.payload is not None

    def test_agent_status_done_after_run(self, aios_p2, agent_spec, mock_engine):
        """成功完成的任務應將 AgentState.status 設為 DONE。"""
        mock_engine.set_responses("任務完成，無需工具。")
        pm = ProcessManager(
            engine=mock_engine,
            kernel=aios_p2.kernel,
            snapshot_manager=aios_p2.snapshot_manager,
            max_steps=3,
        )
        state = aios_p2.agent_spawn(agent_spec)
        task  = InferenceTask(instance_id=state.instance_id, model_id="test-model",
                               prompt_tokens=30, max_tokens=256)
        asyncio.run(pm.run(state, task))

        assert state.status == AgentStatus.DONE


# ════════════════════════════════════════════════════════════════════
# 回歸測試：Phase 1 + Phase 2 不受影響
# ════════════════════════════════════════════════════════════════════

class TestRegression:

    def test_phase1_abac_still_enforced(self, aios_p2):
        from aios.core.models import AgentSpec, Capability, MemoryScope
        from aios.core.models import MemStoreRequest, MemoryScope
        spec = AgentSpec(
            goal="test",
            owner="user:regression",
            capabilities=[Capability.MEM_READ_PERSONAL],  # 無 WRITE
            max_scope=MemoryScope.PERSONAL,
            declared_actions=["mem_store"],
            forbidden_actions=[],
        )
        state = aios_p2.agent_spawn(spec)
        from aios.core.models import PolicyDecision
        result = aios_p2.kernel.mem_store(
            state.token,
            MemStoreRequest(content="test", intent="test"),
        )
        # 沒有 MEM_WRITE_PERSONAL → 應被 ABAC 拒絕
        assert isinstance(result, PolicyDecision)
        assert not result.permitted

    def test_phase2_kvcache_still_works(self, aios_p2):
        kv = aios_p2.kvcache
        bt = kv.append_tokens("reg-seq", token_count=8)
        assert bt.token_count == 8
        kv.release_sequence("reg-seq")

    def test_all_phase1_phase2_tests_still_pass(self):
        """確認 engine 層不干擾既有測試。"""
        import subprocess, sys
        r = subprocess.run(
            [sys.executable, "-m", "pytest",
             "tests/test_phase1.py", "tests/test_phase2.py", "-q", "--tb=short"],
            capture_output=True, text=True, cwd=str(__import__("pathlib").Path(__file__).parent.parent),
        )
        assert r.returncode == 0, r.stdout + r.stderr
