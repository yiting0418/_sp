# AIOS — AI-Native Operating System

AIOS 是一個 AI-Native 作業系統核心框架，提供 AI 模型專用的系統呼叫介面（L5 Syscall）、多層安全防護、三層記憶體架構、KV-Cache 管理、內建工具（程式碼執行、網頁搜尋、網頁抓取）、以及分散式推論基礎設施。

## 安裝

```bash
pip install -e .
pip install -e ".[dev]"       # 含測試依賴
pip install -e ".[dashboard]"  # 含桌面 GUI 依賴
```

---

## 🖥️ 桌面 GUI（圖形化操作）

不需打任何指令，像 Ubuntu 桌面一樣用滑鼠操作。

### 啟動

```bash
aios dashboard
```

瀏覽器自動開啟 `http://127.0.0.1:8765`。關掉終端機時桌面也會關閉。

### 桌面環境

| 元件 | 說明 |
|------|------|
| **桌面圖示** | 雙擊開啟應用（🚀 Agent Launcher / 📊 Agent Monitor / 📈 System Monitor） |
| **底部工具列** | ◆ 開始選單、釘選應用快速啟動、Agent 數量、🕐 時鐘 |
| **開始選單** | 點 ◆ 按鈕開啟，列出所有可用應用 |
| **右鍵選單** | 桌面任意處按右鍵，快速開啟應用或重新整理 |
| **視窗系統** | 拖曳移動、🟡最小化/🟢最大化/🔴關閉 |

### 應用程式

#### 🚀 Agent Launcher
一鍵建立並執行 AI Agent：

1. 填寫 **Goal**（目標描述，例如"搜尋 2025 AI 論文"）
2. 選擇 **Capabilities**（權限標籤，按一下切換選取）
3. 設定 **Model**、**Owner**、**Max Steps**
4. 按「Launch Agent」啟動（背景執行）

#### 📊 Agent Monitor
即時查看所有 Agent 狀態：

- 顯示 Status（running / pending / done / failed / suspended）
- 可點 **⏸ 暫停**、**▶ 恢復**、**⏹ 終止** Agent
- 每 3 秒自動重新整理

#### 📈 System Monitor
即時系統資源監控：

- Agent 數量、記憶體用量、KV Cache 使用率（含進度條）
- Model 總數、累計 Syscall 次數、快照統計
- KV Cache Block Map（綠 = 前綴快取、藍 = 使用中、灰 = 空閒）
- 三層記憶體（Working / Episodic / Semantic）用量圖

### 自訂啟動

```bash
aios dashboard --host 0.0.0.0 --port 8080 --no-browser
```

---

## CLI

安裝後可直接使用 `aios` 命令：

```bash
aios --help
```

### `aios run` — 執行單次任務

自動辨識目標型別並選擇對應工具：

```bash
# Python 計算
aios run "計算 2**100"

# 網頁搜尋
aios run "搜尋 AI 相關論文"

# 抓取特定網頁
aios run "抓取 https://example.com"

# 指定能力與動作
aios run "搜尋 AI 論文" \
  --caps "memory:read:personal,memory:write:personal,tool:web_fetch" \
  --actions "mem_recall,mem_store,tool_call,tool:web_fetch"
```

### 網頁抓取 (`web_fetch`)

`web_fetch` 有兩種模式：

**① 抓取指定 URL** — 目標中包含 `http://` 或 `https://` 開頭的網址：

```bash
aios run "抓取 https://example.com"
aios run "讀取 https://httpbin.org/get 的內容"
```

輸出包含 `url`、`content`（HTML 自動轉純文字）、`status`（HTTP 狀態碼）、`encoding`。

**② 搜尋代理** — 目標中無 URL 時，自動轉為 DuckDuckGo 搜尋並回傳結構化結果：

```bash
aios run "搜尋 AI 相關論文"
```

輸出包含 `query`、`results`（每筆含 `title` / `snppet` / `url`）、`total`。

若同時宣告 `tool:web_search` 與 `tool:web_fetch`，優先使用 `web_search`（Wikipedia → DuckDuckGo 雙引擎）。

### `aios shell` — 多輪互動對話

維持同一 agent 跨輪對話，歷史自動存入 episodic memory：

```
(0) goal> 計算 3*4+5
(1) goal> 搜尋 AI 論文       ← 自動 recall 上一輪結果
(2) goal> /clear              ← 清除對話歷史
```

支援指令：`/exit` `/status` `/clear` `/help`

### `aios status` — 系統儀表板

顯示 KV-Cache 使用率、Agent 數量、記憶體用量。

### `aios report` — 完整系統報告

輸出 L1–L5 + Phase 3 各子系統的 JSON 報告。

### `aios distributed` — 分散式模式

```bash
aios distributed "搜尋測試" --nodes 3
```

### 真實推論模式

設定 `ANTHROPIC_API_KEY` 後自動啟用 Anthropic Claude tool-use 迴圈：

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
aios run "搜尋 AI 新聞並整理摘要"
```

## 內建工具

| 工具 | 觸發條件 | 行為 | 輸出 |
|------|----------|------|------|
| `code_exec` | 目標含數學運算式（`1+1` `2**10`）或 Python 程式碼 | 沙箱 `exec()` 執行，安全內建函數白名單 | `output`（stdout）、`locals`（變數值） |
| `web_search` | 目標為一般查詢文字，且 `tool:web_search` 在 declared_actions 中 | 先查 Wikipedia API，無結果則 fallback DuckDuckGo | `query`、`results[]`（`title`/`snippet`/`url`）、`source` |
| `web_fetch` | 目標含 `https?://` URL → 抓取該網頁；不含 URL → 自動轉 DuckDuckGo 搜尋 | 真實 HTTP GET（urllib），HTML 自動剝標籤轉純文字，DuckDuckGo URL 自動解析結構化結果 | `url`、`content`、`status` / `query`、`results[]` |

## Python API

### 快速入門

```python
from aios.kernel.aios_p2 import AIOS_P2
from aios.core.models import AgentSpec, Capability, MemoryScope

aios = AIOS_P2.build(verbose=True)
aios.register_model("demo", size_mb=100.0)

spec = AgentSpec(
    goal="分析 PagedAttention 並更新知識庫",
    owner="user:alice",
    capabilities=[
        Capability.MEM_READ_PERSONAL,
        Capability.MEM_WRITE_PERSONAL,
        Capability.TOOL_CODE_EXEC,
    ],
    max_scope=MemoryScope.PERSONAL,
    declared_actions=["mem_recall", "mem_store", "tool_call", "tool:code_exec"],
    forbidden_actions=["agent_spawn"],
    model="demo",
)

state = aios.agent_spawn(spec)
result = aios.run_agent(state)
print(result.result)
```

### 直接使用核心 API

```python
from aios.kernel.aios import AIOS
from aios.core.models import AgentSpec, Capability, MemoryScope, MemStoreRequest, MemRecallRequest

kernel = AIOS()

spec = AgentSpec(
    goal="儲存與查詢研究筆記",
    owner="user:alice",
    capabilities=[Capability.MEM_READ_PERSONAL, Capability.MEM_WRITE_PERSONAL],
    max_scope=MemoryScope.PERSONAL,
    declared_actions=["mem_recall", "mem_store"],
    forbidden_actions=[],
)

state = kernel.agent_spawn(spec)
kernel.mem_store(state.token, MemStoreRequest(
    content="PagedAttention 透過分頁管理 KV-Cache",
    intent="儲存研究筆記",
))
result = kernel.mem_recall(state.token, MemRecallRequest(
    query="KV-Cache 最佳化",
    intent="查詢相關記憶",
))
for entry in result.entries:
    print(f"- {entry.content}")
```

### AIKernel（含可觀測性）

```python
from aios.kernel.aios import AIOS
from aios.kernel.os_kernel import AIKernel

kernel = AIOS()
os_kernel = AIKernel(kernel)

state = os_kernel.spawn(spec)
result = os_kernel.syscall("tool_call", state.token,
    name="code_exec", args={"code": "print('hello')"}, intent="demo")
print(os_kernel.dashboard())
```

### 分散式模式（Phase 3）

```python
aios = AIOS_P2.build(verbose=True, enable_distributed=True, num_nodes=3)
report = aios.full_report()
print(report)
```

## 系統架構

```
┌─────────────────────────────────────────────────────┐
│  L5  AI Syscall Interface (aios.kernel.aios)        │
│  agent_spawn / mem_store / mem_recall / tool_call   │
│  ctx_handoff / kb_search / kb_index / sys_stats     │
├─────────────────────────────────────────────────────┤
│  L4  Security (aios.security)                        │
│  ABAC → Intent Whitelist → Anomaly Detection        │
│  + BehaviorGuard (動態行為防護)                      │
├─────────────────────────────────────────────────────┤
│  L3  Memory & Knowledge (aios.memory, aios.fs)      │
│  Working / Episodic / Semantic 三層記憶體             │
│  AIOFS 向量知識庫 + 一致性雜湊分散式儲存              │
├─────────────────────────────────────────────────────┤
│  L2  Model Runtime (aios.l2)                         │
│  ModelManager (分層熱/溫/冷) + SnapshotManager      │
├─────────────────────────────────────────────────────┤
│  L1  Compute Infrastructure (aios.l1)                │
│  PagedAttention KV-Cache / TensorScheduler          │
│  分散式: GlobalScheduler / KVRouter / RDMA          │
├─────────────────────────────────────────────────────┤
│  L0  Inference Engines (aios.runtime)                │
│  InferenceEngine 抽象 / LlamaCppEngine / ProcessMgr │
└─────────────────────────────────────────────────────┘
```

## 專案結構

```
aios/
├── cli.py              # CLI 進入點
├── core/               # Pydantic 資料模型
├── kernel/             # L5 Syscall 介面
├── runtime/            # 推論引擎, AgentRunner
├── l1/                 # KV-Cache, 排程器, RDMA, 路由
├── l2/                 # ModelManager, SnapshotManager
├── l3a/                # Syscall 預測器
├── security/           # ABAC, 意圖白名單, 異常偵測
├── memory/             # Working/Episodic/Semantic
├── fs/                 # AIOFS 知識庫
├── tools/              # ToolRegistry, 沙箱執行
├── sandbox/            # 程式碼沙箱
├── iac/                # 代理間通訊
├── cluster/            # GPU 排程
├── observability/      # 指標/追蹤/事件
├── dashboard/          # 🖥️ 桌面 GUI
│   ├── server.py       #   FastAPI 後端
│   └── static/         #   前端 (桌面環境)
│       ├── index.html
│       ├── desktop.css
│       ├── desktop.js
│       ├── lib/        #   視窗管理, API 層
│       └── apps/       #   應用程式
└── examples/
tests/
├── test_phase1.py
├── test_phase2.py
├── test_phase3.py
├── test_engine.py
└── test_runtime_enhanced.py
```

## 測試

```bash
pytest tests/ -v
# 277 個測試全部通過
```

## 授權

MIT
