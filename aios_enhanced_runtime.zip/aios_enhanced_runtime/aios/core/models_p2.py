"""
aios.core.models_p2
────────────────────
Phase 2 資料型別。
不修改 Phase 1 的 models.py，以獨立模組擴充。
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


# ════════════════════════════════════════════════════════════════════
# L1 — 推論任務階段
# ════════════════════════════════════════════════════════════════════

class InferencePhase(str, Enum):
    """
    推論任務的兩個截然不同的計算階段。

    PREFILL : 計算密集（Compute-bound），平行處理所有 prompt token。
              延遲敏感（Time-to-first-token）。

    DECODE  : 記憶體頻寬密集（Memory-bound），逐 token 自回歸生成。
              吞吐量敏感（tokens/sec）。

    排程器依據當前階段選擇不同策略，並在切換時重新計算優先序。
    """
    PREFILL   = "prefill"
    DECODE    = "decode"
    IDLE      = "idle"
    SUSPENDED = "suspended"   # 快照已建立，等待恢復


class TaskPriority(int, Enum):
    CRITICAL = 0
    HIGH     = 1
    NORMAL   = 2
    LOW      = 3
    BATCH    = 4


# ════════════════════════════════════════════════════════════════════
# L1 — KV-Cache 分頁
# ════════════════════════════════════════════════════════════════════

@dataclass
class KVBlock:
    """
    PagedAttention 的一個 KV-Cache 頁面。

    對應 GPU 上的一段連續 HBM 區域；Phase 2 以 numpy 模擬。
    block_size 個 token 共用一個 block；
    prefix_hash 非空表示此 block 屬於可跨序列共享的 prefix cache。
    """
    block_id:    int
    block_size:  int   = 16          # tokens per block（標準值）
    ref_count:   int   = 0           # 多少序列正在引用此 block
    prefix_hash: str | None = None   # sha256(prefix tokens) → 可共享
    is_free:     bool  = True
    # 模擬 KV 資料：shape [2, block_size, num_heads, head_dim]
    # Phase 3 替換為真實 GPU tensor pointer
    data:        np.ndarray | None = None
    created_at:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_used:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def touch(self) -> None:
        self.last_used = datetime.now(timezone.utc)


@dataclass
class BlockTable:
    """
    一個推論序列的邏輯→物理 block 映射表。
    邏輯 block idx 0..N 對應 KVCacheManager 中的物理 block_id。
    """
    sequence_id:    str
    logical_blocks: list[int] = field(default_factory=list)   # logical idx → physical block_id
    token_count:    int = 0

    @property
    def num_blocks(self) -> int:
        return len(self.logical_blocks)

    @property
    def last_block_usage(self) -> int:
        """最後一個 block 中已用的 token 數（0 = 整個 block 空）。"""
        if self.token_count == 0:
            return 0
        # block_size 取決於 KVCacheManager；這裡用預設 16
        return self.token_count % 16 or 16


# ════════════════════════════════════════════════════════════════════
# L1 — 推論任務
# ════════════════════════════════════════════════════════════════════

@dataclass
class InferenceTask:
    """
    L1 排程器的基本排程單位。
    取代傳統行程，以「推論任務」為第一等公民。
    """
    task_id:       str           = field(default_factory=lambda: uuid.uuid4().hex[:12])
    instance_id:   str           = ""          # 對應 AgentState.instance_id
    model_id:      str           = ""
    phase:         InferencePhase = InferencePhase.PREFILL
    priority:      TaskPriority   = TaskPriority.NORMAL
    prompt_tokens: int            = 0          # PREFILL 階段的 input token 數
    generated_tokens: int         = 0          # DECODE 階段已生成的 token 數
    max_tokens:    int            = 2048
    block_table:   BlockTable | None = None
    # 批次 Syscall 緩衝（等待此任務在自然邊界停下後統一回傳）
    pending_syscalls: list[dict[str, Any]] = field(default_factory=list)
    created_at:    datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    started_at:    datetime | None = None
    completed_at:  datetime | None = None

    @property
    def is_prefill_complete(self) -> bool:
        return self.phase in (InferencePhase.DECODE, InferencePhase.SUSPENDED,
                               InferencePhase.IDLE)

    @property
    def prefill_compute_cost(self) -> float:
        """PREFILL 計算代價估算：O(n²) attention。"""
        return float(self.prompt_tokens ** 2)

    @property
    def decode_memory_cost(self) -> float:
        """DECODE 記憶體頻寬代價估算：線性於 KV-Cache 大小。"""
        return float(self.prompt_tokens + self.generated_tokens)


# ════════════════════════════════════════════════════════════════════
# L2 — 模型常駐
# ════════════════════════════════════════════════════════════════════

class ModelTier(str, Enum):
    VRAM  = "vram"    # 熱，on-device，立即可用
    DRAM  = "dram"    # 暖，需要數秒載入
    NVME  = "nvme"    # 冷，需要數十秒載入


@dataclass
class LoRAEntry:
    """
    LoRA 適配器的差量儲存。
    基礎模型只存一份；切換適配器只需載入此差量（通常 < 1% 體積）。
    """
    adapter_id:    str
    base_model_id: str
    task_type:     str              # "code" | "translation" | "reasoning" | ...
    delta_size_mb: float            = 0.0
    # Phase 2 模擬：delta 以 dict 表示，Phase 3 替換為真實 tensor
    delta:         dict[str, Any]   = field(default_factory=dict)
    loaded:        bool             = False
    access_count:  int              = 0
    created_at:    datetime         = field(default_factory=lambda: datetime.now(timezone.utc))
    last_used:     datetime         = field(default_factory=lambda: datetime.now(timezone.utc))

    def touch(self) -> None:
        self.last_used   = datetime.now(timezone.utc)
        self.access_count += 1


@dataclass
class ModelEntry:
    """
    L2 Model Manager 中的一個模型記錄。
    管理基礎模型的常駐狀態與所有掛載的 LoRA 適配器。
    """
    model_id:    str
    size_mb:     float
    tier:        ModelTier = ModelTier.NVME
    # Phase 2 模擬：weights 以 dict stub 表示
    weights:     dict[str, Any] = field(default_factory=dict)
    adapters:    dict[str, LoRAEntry] = field(default_factory=dict)  # adapter_id → LoRAEntry
    active_adapter: str | None = None
    access_count: int = 0
    created_at:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_used:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def touch(self) -> None:
        self.last_used    = datetime.now(timezone.utc)
        self.access_count += 1

    @property
    def is_hot(self) -> bool:
        return self.tier == ModelTier.VRAM

    @property
    def load_latency_ms(self) -> float:
        """預估載入延遲（ms），依 tier 估算。"""
        return {
            ModelTier.VRAM:  0.0,
            ModelTier.DRAM:  self.size_mb * 0.5,    # ~2 GB/s PCIe
            ModelTier.NVME:  self.size_mb * 5.0,    # ~200 MB/s NVMe
        }[self.tier]


# ════════════════════════════════════════════════════════════════════
# L2 — KV-Cache 快照（自然邊界序列化）
# ════════════════════════════════════════════════════════════════════

@dataclass
class KVSnapshot:
    """
    在自然邊界（工具呼叫宣告完成後）建立的 KV-Cache 快照。

    設計原則：
      只在模型完成一個完整的生成單元後才建立快照。
      此時 KV-Cache 狀態完整且一致，可安全序列化。
      不在 decode 迴圈中途強制打斷。
    """
    snapshot_id:   str           = field(default_factory=lambda: "snap:" + uuid.uuid4().hex[:8])
    instance_id:   str           = ""
    task_id:       str           = ""
    token_count:   int           = 0          # 快照時的總 token 數
    block_table:   list[int]     = field(default_factory=list)   # logical→physical block_ids
    # 序列化的 KV 資料（DRAM 中）
    # Phase 2：pickle bytes；Phase 3：RDMA-transferable buffer
    payload:       bytes         = b""
    payload_bytes: int           = 0
    natural_boundary: bool       = True       # 必須是自然邊界，否則快照無效
    created_at:    datetime      = field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# L4 Phase 2 — 行為事件（動態防護模型輸入）
# ════════════════════════════════════════════════════════════════════

class BehaviorEventType(str, Enum):
    SYSCALL        = "syscall"
    TOOL_CALL      = "tool_call"
    MEMORY_READ    = "memory_read"
    MEMORY_WRITE   = "memory_write"
    SCOPE_ATTEMPT  = "scope_attempt"
    PHASE_CHANGE   = "phase_change"
    TASK_COMPLETE  = "task_complete"


class BehaviorEvent(BaseModel):
    """
    L4 動態防護模型的輸入事件。
    由核心發布至隔離佇列，防護模型從佇列消費。
    防護模型永遠不接受來自 Agent 的直接輸入——這是隔離的關鍵。
    """
    model_config = ConfigDict(frozen=True)

    event_id:    str            = Field(default_factory=lambda: uuid.uuid4().hex[:8])
    instance_id: str
    event_type:  BehaviorEventType
    syscall_name: str           = ""
    scope:       str            = ""
    success:     bool           = True
    metadata:    dict[str, Any] = Field(default_factory=dict)
    timestamp:   datetime       = Field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# Runner — 推論結果
# ════════════════════════════════════════════════════════════════════

class RunnerStatus(str, Enum):
    RUNNING   = "running"
    DONE      = "done"
    FAILED    = "failed"
    SUSPENDED = "suspended"


class InferResult(BaseModel):
    """AgentRunner 的最終執行結果。"""
    instance_id:  str
    task_id:      str
    status:       RunnerStatus
    result:       str | None = None
    error:        str | None = None
    steps:        int        = 0
    total_tokens: int        = 0
    snapshot_id:  str | None = None    # 若任務被暫停，快照 ID
    duration_ms:  float      = 0.0
