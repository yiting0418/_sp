"""
aios.core.models
────────────────
所有 Pydantic / dataclass 資料型別定義。
不含業務邏輯，不依賴其他 aios 子模組。

使用原則：
  - 跨層傳遞的不可變資料  → pydantic BaseModel (frozen)
  - 服務內部的可變狀態    → dataclass
  - 純列舉               → str Enum
"""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


# ════════════════════════════════════════════════════════════════════
# 列舉
# ════════════════════════════════════════════════════════════════════

class MemoryScope(str, Enum):
    """記憶體存取範圍上限"""
    PERSONAL  = "personal"
    WORKSPACE = "workspace"
    GLOBAL    = "global"

    def __le__(self, other: "MemoryScope") -> bool:
        _order = [self.PERSONAL, self.WORKSPACE, self.GLOBAL]
        return _order.index(self) <= _order.index(other)


class MemoryTier(str, Enum):
    """三層記憶體架構"""
    WORKING  = "working"   # 上下文視窗內，推論結束即消失
    EPISODIC = "episodic"  # 對話 / 工作階段歷史，時序索引
    SEMANTIC = "semantic"  # 長期知識庫，向量索引


class AgentStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    SUSPENDED = "suspended"
    DONE      = "done"
    FAILED    = "failed"


class Capability(str, Enum):
    """能力令牌中可授予的能力集合"""
    # 記憶體
    MEM_READ_PERSONAL   = "memory:read:personal"
    MEM_WRITE_PERSONAL  = "memory:write:personal"
    MEM_READ_WORKSPACE  = "memory:read:workspace"
    MEM_WRITE_WORKSPACE = "memory:write:workspace"
    MEM_READ_GLOBAL     = "memory:read:global"
    # 知識庫
    KB_SEARCH           = "kb:search"
    KB_INDEX            = "kb:index"
    KB_BROADCAST        = "kb:broadcast"
    # 工具
    TOOL_WEB_FETCH      = "tool:web_fetch"
    TOOL_CODE_EXEC      = "tool:code_exec:sandboxed"
    TOOL_FILE_READ      = "tool:file_read"
    TOOL_FILE_WRITE     = "tool:file_write"
    # 代理
    AGENT_SPAWN_CHILD   = "agent:spawn:child"
    CTX_HANDOFF         = "iac:ctx_handoff"


# ════════════════════════════════════════════════════════════════════
# 能力令牌（TrustToken）— 不可變，跨層傳遞
# ════════════════════════════════════════════════════════════════════

class TrustToken(BaseModel):
    """
    由 OS 核心在 agent_spawn 時簽發。
    攜帶身分、授予的能力、意圖白名單。
    所有跨層資源存取都依此令牌驗證。
    """
    model_config = ConfigDict(frozen=True)

    instance_id:      str
    owner:            str                    # "user:alice" 或 "agent:orchestrator-7"
    workspace_id:     str | None
    capabilities:     frozenset[Capability]
    max_scope:        MemoryScope
    declared_actions: frozenset[str]         # 宣告的合法 syscall 白名單
    forbidden_actions: frozenset[str]        # 明確禁止的 syscall
    intent_hash:      str                    # sha256(goal statement)
    issued_at:        datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # ── 便利查詢 ────────────────────────────────────────────────────
    def has(self, cap: Capability) -> bool:
        return cap in self.capabilities

    def allows_scope(self, scope: MemoryScope) -> bool:
        return scope <= self.max_scope

    def action_permitted(self, syscall_name: str) -> tuple[bool, str]:
        """回傳 (是否允許, 理由)"""
        if syscall_name in self.forbidden_actions:
            return False, f"'{syscall_name}' 在 forbidden_actions 中，立即終止"
        if syscall_name not in self.declared_actions:
            return False, f"'{syscall_name}' 未在 declared_actions 中宣告"
        return True, "intent whitelist passed"


# ════════════════════════════════════════════════════════════════════
# Agent 規格與狀態
# ════════════════════════════════════════════════════════════════════

class AgentSpec(BaseModel):
    """spawn 一個 Agent 所需的完整規格"""
    goal:             str
    owner:            str
    workspace_id:     str | None       = None
    capabilities:     list[Capability] = Field(default_factory=list)
    max_scope:        MemoryScope      = MemoryScope.PERSONAL
    declared_actions: list[str]        = Field(default_factory=list)
    forbidden_actions: list[str]       = Field(default_factory=list)
    max_steps:        int              = 20
    model:            str              = "claude-sonnet-4-20250514"

    def intent_hash(self) -> str:
        return hashlib.sha256(self.goal.encode()).hexdigest()


@dataclass
class AgentState:
    """推論實例的可變執行時狀態（mutable，用 dataclass）"""
    instance_id: str                  = field(default_factory=lambda: uuid.uuid4().hex)
    spec:        AgentSpec            = field(default_factory=lambda: AgentSpec(goal="", owner=""))
    token:       TrustToken | None    = None
    status:      AgentStatus          = AgentStatus.PENDING
    steps:       int                  = 0
    messages:    list[dict[str, Any]] = field(default_factory=list)
    result:      str | None           = None
    error:       str | None           = None
    created_at:  datetime             = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None      = None


# ════════════════════════════════════════════════════════════════════
# 記憶體條目
# ════════════════════════════════════════════════════════════════════

class MemoryEntry(BaseModel):
    """三層記憶體中的單一條目（不可變快照，用 pydantic）"""
    id:           str        = Field(default_factory=lambda: uuid.uuid4().hex)
    content:      str
    metadata:     dict[str, Any] = Field(default_factory=dict)
    embedding:    list[float] | None = None
    tier:         MemoryTier
    scope:        MemoryScope
    namespace:    str                        # agent_id 或 workspace_id
    created_at:   datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    accessed_at:  datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    access_count: int = 0

    model_config = ConfigDict(frozen=False)  # 允許 touch() 更新存取紀錄

    def touch(self) -> "MemoryEntry":
        self.accessed_at  = datetime.now(timezone.utc)
        self.access_count += 1
        return self


# ════════════════════════════════════════════════════════════════════
# 知識庫條目（AIOFS）
# ════════════════════════════════════════════════════════════════════

class StorageTier(str, Enum):
    HOT  = "hot"   # NVMe SSD，mmap 常駐
    WARM = "warm"  # NAS / RAID
    COLD = "cold"  # 物件儲存


class KBEntry(BaseModel):
    """AIOFS 中的一個知識庫 blob"""
    ref:          str = Field(default_factory=lambda: "kb:" + uuid.uuid4().hex[:8])
    content:      str
    metadata:     dict[str, Any] = Field(default_factory=dict)
    embedding:    list[float] | None = None
    content_hash: str = ""          # SHA-256，由 AIOFS 在儲存時填入
    tier:         StorageTier = StorageTier.HOT
    access_count: int = 0
    created_at:   datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(frozen=False)

    def touch(self) -> "KBEntry":
        self.access_count += 1
        return self


# ════════════════════════════════════════════════════════════════════
# 工具
# ════════════════════════════════════════════════════════════════════

class ToolSpec(BaseModel):
    """工具路由器中的工具描述（不可變）"""
    model_config = ConfigDict(frozen=True)

    name:                str
    description:         str
    required_capability: Capability
    parameters:          dict[str, Any]   # JSON-schema 格式


class ToolResult(BaseModel):
    """工具呼叫的回傳結果"""
    tool_name:   str
    success:     bool
    output:      Any
    error:       str | None = None
    duration_ms: float = 0.0


# ════════════════════════════════════════════════════════════════════
# 安全層回傳值
# ════════════════════════════════════════════════════════════════════

class PolicyDecision(BaseModel):
    """L4 任一防線的判斷結果"""
    model_config = ConfigDict(frozen=True)

    permitted: bool
    reason:    str
    layer:     str    # "abac" | "intent_whitelist" | "anomaly"
    cached:    bool = False


# ════════════════════════════════════════════════════════════════════
# IAC：代理間通訊物件
# ════════════════════════════════════════════════════════════════════

class ContextHandoff(BaseModel):
    """
    語意摘要交接物件（L3b）。
    不傳遞 KV-Cache 切片——因為 Transformer 全域注意力使得
    KV-Cache 切片在數學上無效。傳遞蒸餾後的語意摘要。
    """
    model_config = ConfigDict(frozen=True)

    type:             Literal["context_handoff"] = "context_handoff"
    source_agent:     str
    target_agent:     str
    completed_goal:   str
    key_findings:     list[str]
    relevant_mem_refs: list[str]          # 指向語意記憶的 MemoryEntry.id
    confidence:       float               # 0.0 – 1.0
    next_steps:       list[str]
    metadata:         dict[str, Any] = Field(default_factory=dict)
    created_at:       datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class KnowledgeBroadcast(BaseModel):
    """工作區知識廣播物件（L3b）"""
    model_config = ConfigDict(frozen=True)

    type:         Literal["knowledge_broadcast"] = "knowledge_broadcast"
    source_agent: str
    workspace_id: str
    entry:        KBEntry
    intent:       str
    created_at:   datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# L5 Syscall 請求 / 回應模型
# （每個 Syscall 強制攜帶 intent 欄位，L4 以此進行意圖白名單比對）
# ════════════════════════════════════════════════════════════════════

class MemStoreRequest(BaseModel):
    content:  str
    tier:     MemoryTier  = MemoryTier.EPISODIC
    scope:    MemoryScope = MemoryScope.PERSONAL
    metadata: dict[str, Any] = Field(default_factory=dict)
    intent:   str           # 必填

class MemRecallRequest(BaseModel):
    query:  str
    scope:  MemoryScope       = MemoryScope.PERSONAL
    top_k:  int               = 5
    tiers:  list[MemoryTier] | None = None
    intent: str               # 必填

class MemRecallResult(BaseModel):
    type:      Literal["mem_recall_result"] = "mem_recall_result"
    query:     str
    entries:   list[MemoryEntry]
    exhausted: bool = False

class KBSearchRequest(BaseModel):
    query:  str
    top_k:  int = 5
    intent: str  # 必填

class KBSearchResult(BaseModel):
    type:    Literal["kb_search_result"] = "kb_search_result"
    query:   str
    entries: list[KBEntry]

class KBIndexRequest(BaseModel):
    content:  str
    metadata: dict[str, Any] = Field(default_factory=dict)
    intent:   str  # 必填

class ToolCallRequest(BaseModel):
    name:   str
    args:   dict[str, Any] = Field(default_factory=dict)
    intent: str  # 必填

class CtxHandoffRequest(BaseModel):
    target_agent:     str
    completed_goal:   str
    key_findings:     list[str]
    relevant_mem_refs: list[str] = Field(default_factory=list)
    confidence:       float = 1.0
    next_steps:       list[str] = Field(default_factory=list)
    intent:           str  # 必填

class KBBroadcastRequest(BaseModel):
    entry:        KBEntry
    workspace_id: str
    intent:       str  # 必填

class AgentSpawnRequest(BaseModel):
    spec:         AgentSpec
    parent_token: TrustToken | None = None

class SystemSnapshot(BaseModel):
    agents:     dict[str, int]   # status.value → count
    memory:     dict[str, Any]
    tools:      int
    kb_entries: int
    timestamp:  datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
