"""
aios.core.models_p3
────────────────────
Phase 3 資料型別：分散式推論與規模化基礎設施。

新增概念：
  - NodeType / NodeInfo           — 跨節點叢集拓撲
  - KVTransferRequest/Result      — RDMA KV-Cache 遷移合約
  - GlobalScheduleDecision        — Global Scheduler 決策
  - SpeculationPrediction         — L3a Syscall 預測
  - ConsistentHashRing            — AIOFS 分散式一致性

不修改 Phase 1/2 的 models.py / models_p2.py，以獨立模組擴充。
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# ════════════════════════════════════════════════════════════════════
# 叢集拓撲
# ════════════════════════════════════════════════════════════════════

class NodeType(str, Enum):
    """節點角色類型：分離式 Prefill/Decode 的基礎。"""
    PREFILL_ONLY = "prefill_only"   # 只做 prefill，運算密集
    DECODE_ONLY  = "decode_only"    # 只做 decode，記憶體頻寬密集
    HYBRID       = "hybrid"         # 兩者皆可


@dataclass
class NodeInfo:
    """
    叢集中一個節點的即時狀態報告。
    Global Scheduler 根據此類別資訊做出排程決策。
    """
    node_id:            str
    node_type:          NodeType
    address:            str                  # host:port
    vram_mb:            float                # 總 VRAM
    vram_used_mb:       float    = 0.0
    kv_blocks_available: int     = 0
    kv_blocks_used:     int      = 0
    active_tasks:       int      = 0
    load_score:         float    = 0.0       # 0.0 (idle) ~ 1.0 (saturated)
    last_heartbeat:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def vram_utilization(self) -> float:
        return self.vram_used_mb / self.vram_mb if self.vram_mb > 0 else 0.0

    @property
    def kv_utilization(self) -> float:
        total = self.kv_blocks_available + self.kv_blocks_used
        return self.kv_blocks_used / total if total > 0 else 0.0


# ════════════════════════════════════════════════════════════════════
# RDMA KV-Cache 遷移
# ════════════════════════════════════════════════════════════════════

class TransferUrgency(int, Enum):
    CRITICAL   = 0    # 阻塞，立即傳輸（decode 等待中）
    NORMAL     = 1    # 標準優先序
    BACKGROUND = 2    # 背景預取


@dataclass
class KVTransferRequest:
    """
    RDMA KV-Cache 遷移請求。

    分離式 Prefill/Decode 的核心：
    Prefill 節點完成後，將 KV-Cache block 遷移至 Decode 節點。
    """
    source_node:  str
    target_node:  str
    block_ids:    list[int]
    sequence_id:  str            = ""
    instance_id:  str            = ""
    transfer_id:  str            = field(default_factory=lambda: uuid.uuid4().hex[:12])
    urgency:      TransferUrgency = TransferUrgency.NORMAL
    payload:      list[Any]      = field(default_factory=list)  # KV block data
    created_at:   datetime       = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


@dataclass
class KVTransferResult:
    transfer_id:  str
    success:      bool
    bytes_transferred: int = 0
    latency_us:   float = 0.0
    error:        str | None = None


# ════════════════════════════════════════════════════════════════════
# 分離式 Prefill/Decode
# ════════════════════════════════════════════════════════════════════

class ScheduleType(str, Enum):
    PREFILL = "prefill"    # 需要 prefill 節點
    DECODE  = "decode"     # 需要 decode 節點（附 KV-Cache）
    RESUME  = "resume"     # 從快照恢復


@dataclass
class GlobalScheduleDecision:
    """
    Global Scheduler 的排程決策。
    決定哪個任務應該在哪個節點上執行哪個階段。
    """
    task_id:      str
    instance_id:  str
    node_id:      str                       # 目標節點
    schedule_type: ScheduleType
    reason:       str                       # 決策理由（除錯用）
    decision_id:  str        = field(default_factory=lambda: uuid.uuid4().hex[:8])
    score:        float       = 0.0         # 評分（越高越適合）
    created_at:   datetime    = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class PrefillNodeAllocation:
    """
    Prefill 節點分配結果。
    記錄哪個 prefill 節點被分配給哪個任務，
    以及完成後 KV-Cache 應遷移至哪個 decode 節點。
    """
    task_id:        str
    instance_id:    str
    prefill_node:   str
    decode_node:    str | None = None   # 若無指定，schedule 時選擇
    allocation_id:  str       = field(default_factory=lambda: uuid.uuid4().hex[:8])
    priority:       int        = 0
    allocated_at:   datetime   = field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# L3a — Syscall 預測性預取
# ════════════════════════════════════════════════════════════════════

class SpeculationMode(str, Enum):
    OFF     = "off"      # 不預測
    OBSERVE = "observe"  # 僅收集模式，不預取
    PREDICT = "predict"  # 預測並預取


@dataclass
class SpeculationPrediction:
    """
    對下一個 Syscall 的預測結果。
    包含預測的 syscall 名稱、信心度、和上下文 hash。
    """
    predicted_syscall: str    = ""
    probability:    float     = 0.0
    prediction_id:  str       = field(default_factory=lambda: uuid.uuid4().hex[:8])
    context_hash:   str       = ""
    args_hint:      dict[str, Any] = field(default_factory=dict)
    is_read_only:   bool      = False   # 唯讀 syscall 才安全預取


@dataclass
class SyscallTrace:
    """
    單次 syscall 的執行軌跡。
    L3a Speculator 消費此類別的序列來建立預測模型。
    """
    instance_id:   str
    syscall_name:  str
    args_hash:     str       = ""
    success:       bool      = True
    latency_ms:    float     = 0.0
    context_hash:  str       = ""       # 當前推論上下文的 hash
    timestamp:     datetime  = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class PrefetchResult:
    """
    預先執行的 syscall 結果快取。
    若真正的 syscall 與預測匹配，直接回傳此快取值。
    """
    cache_key:     str
    syscall_name:  str
    args:          dict[str, Any] = field(default_factory=dict)
    result:        Any            = None
    hit_count:     int            = 0
    created_at:    datetime       = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at:    datetime | None = None

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at


# ════════════════════════════════════════════════════════════════════
# AIOFS 分散式 — 一致性雜湊
# ════════════════════════════════════════════════════════════════════

@dataclass
class RingNode:
    """一致性雜湊環上的虛擬節點。"""
    node_id:       str
    address:       str
    virtual_count: int     = 100    # 虛擬節點數（負載平衡）
    weight:        float   = 1.0    # 容量權重
    is_active:     bool    = True
    last_seen:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class ReplicaPlacement:
    """
    內容複本的放置位置。
    一致性雜湊決定 primary 和 replica 節點。
    """
    content_hash: str
    primary_node: str
    replica_nodes: list[str] = field(default_factory=list)
    replication_factor: int  = 2
    placed_at:    datetime   = field(default_factory=lambda: datetime.now(timezone.utc))
