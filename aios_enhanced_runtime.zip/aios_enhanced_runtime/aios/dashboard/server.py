from __future__ import annotations

import asyncio
import json
import os
import threading
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
    from fastapi.responses import FileResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

from aios.core.models import (
    AgentSpec, AgentStatus, Capability, MemoryScope,
)
from aios.kernel.aios_p2 import AIOS_P2
from aios.observability import get_registry, get_tracer, get_bus, SystemEvent, EventSeverity

app = FastAPI(title="AIOS Desktop", version="0.2.0") if HAS_FASTAPI else None

_STATIC_DIR = Path(__file__).parent / "static"

_aios_instance: AIOS_P2 | None = None


def set_instance(instance: AIOS_P2) -> None:
    global _aios_instance
    _aios_instance = instance


def _get_aios() -> AIOS_P2:
    if _aios_instance is None:
        raise HTTPException(status_code=503, detail="AIOS instance not initialized")
    return _aios_instance


_ws_clients: set[WebSocket] = set()
_ws_lock = threading.Lock()


def _agent_to_dict(state: Any) -> dict:
    return {
        "instance_id": state.instance_id,
        "goal": state.spec.goal[:120] if state.spec and state.spec.goal else "",
        "owner": state.spec.owner if state.spec else "",
        "status": state.status.value if state.status else "unknown",
        "steps": state.steps,
        "model": state.spec.model if state.spec else "",
        "created_at": state.created_at.isoformat() if state.created_at else None,
        "finished_at": state.finished_at.isoformat() if state.finished_at else None,
        "result": state.result,
        "error": state.error,
    }


if HAS_FASTAPI:

    @app.get("/api/status")
    def get_status():
        aios = _get_aios()
        snap = aios.kernel.sys_stats()
        kv_stats = aios.kvcache.stats
        sched_qs = aios.scheduler.queue_lengths()
        sched_stat = aios.scheduler.stats
        mm_stat = aios.model_manager.stats
        snap_stat = aios.snapshot_manager.stats
        obs_metrics = get_registry().snapshot()
        tracer_stats = get_tracer().stats()
        event_counts = get_bus().count_by_type()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "agents": snap.agents,
            "memory": snap.memory,
            "tools": snap.tools,
            "kb_entries": snap.kb_entries,
            "kvcache": {
                "total_blocks": kv_stats.total_blocks,
                "free_blocks": kv_stats.free_blocks,
                "used_blocks": kv_stats.used_blocks,
                "utilization": round(kv_stats.utilization, 3),
                "prefix_cache_hits": kv_stats.prefix_cache_hits,
                "prefix_cache_misses": kv_stats.prefix_cache_misses,
                "prefix_hit_rate": round(kv_stats.prefix_hit_rate, 3),
                "evictions": kv_stats.evictions,
                "prefix_cached_blocks": kv_stats.prefix_cached_blocks,
            },
            "scheduler": {
                "queue_lengths": sched_qs,
                "total_scheduled": sched_stat.total_scheduled,
                "preemptions": sched_stat.preemptions,
                "avg_prefill_tokens": round(sched_stat.avg_prefill_tokens, 1),
            },
            "models": {
                "total_models": mm_stat.total_models,
                "vram_models": mm_stat.vram_models,
                "dram_models": mm_stat.dram_models,
                "nvme_models": mm_stat.nvme_models,
                "hot_swaps": mm_stat.hot_swaps,
                "cache_hit_rate": round(
                    mm_stat.cache_hits / max(1, mm_stat.cache_hits + mm_stat.cache_misses), 3
                ),
                "total_adapters": mm_stat.total_adapters,
            },
            "snapshots": {
                "total": snap_stat.total_snapshots,
                "restores": snap_stat.total_restores,
                "total_bytes": snap_stat.total_bytes,
            },
            "metrics": obs_metrics,
            "tracer": tracer_stats,
            "events": event_counts,
        }

    @app.post("/api/agents/spawn")
    def spawn_agent(data: dict[str, Any]):
        aios = _get_aios()
        goal = data.get("goal", "").strip()
        if not goal:
            raise HTTPException(400, "goal is required")
        caps_raw = data.get("capabilities", [])
        actions = data.get("actions", [])
        model = data.get("model", "default")
        owner = data.get("owner", "user:desktop")
        max_steps = data.get("max_steps", 20)

        cap_list = [Capability(c) for c in caps_raw if c.strip()]
        act_list = [a.strip() for a in actions if a.strip()]

        spec = AgentSpec(
            goal=goal,
            owner=owner,
            capabilities=cap_list or [
                Capability.MEM_READ_PERSONAL,
                Capability.MEM_WRITE_PERSONAL,
                Capability.TOOL_CODE_EXEC,
                Capability.TOOL_WEB_FETCH,
                Capability.TOOL_FILE_READ,
                Capability.TOOL_FILE_WRITE,
            ],
            max_scope=MemoryScope.PERSONAL,
            declared_actions=act_list or [
                "mem_recall", "mem_store", "tool_call",
                "tool:code_exec", "tool:file_read", "tool:file_write",
                "tool:web_fetch", "tool:web_search",
            ],
            forbidden_actions=["agent_spawn"],
            max_steps=max_steps,
            model=model,
        )
        aios.register_model(model, size_mb=100.0)
        state = aios.agent_spawn(spec)
        get_bus().emit(SystemEvent(
            event_type="agent_spawned",
            source="dashboard",
            payload={"instance_id": state.instance_id, "goal": goal},
        ))

        # run in background thread
        def _run():
            state.status = AgentStatus.RUNNING
            try:
                result = aios.run_agent(state)
                if result.error:
                    get_bus().emit(SystemEvent(
                        event_type="agent_failed",
                        source="dashboard",
                        severity=EventSeverity.ERROR,
                        payload={"instance_id": state.instance_id, "error": str(result.error)},
                    ))
                else:
                    get_bus().emit(SystemEvent(
                        event_type="agent_completed",
                        source="dashboard",
                        payload={"instance_id": state.instance_id, "result": result.result or ""},
                    ))
            except Exception as e:
                state.status = AgentStatus.FAILED
                state.error = str(e)
                get_bus().emit(SystemEvent(
                    event_type="agent_failed",
                    source="dashboard",
                    severity=EventSeverity.ERROR,
                    payload={"instance_id": state.instance_id, "error": str(e)},
                ))

        threading.Thread(target=_run, daemon=True).start()
        return _agent_to_dict(state)

    @app.post("/api/agents/{instance_id}/kill")
    def kill_agent(instance_id: str):
        aios = _get_aios()
        ok = aios.kernel.agent_kill(instance_id)
        if not ok:
            raise HTTPException(404, "Agent not found")
        get_bus().emit(SystemEvent(
            event_type="agent_killed",
            source="dashboard",
            payload={"instance_id": instance_id},
        ))
        return {"ok": True}

    @app.post("/api/agents/{instance_id}/pause")
    def pause_agent(instance_id: str):
        aios = _get_aios()
        state = aios.kernel.agent_get(instance_id)
        if state is None:
            raise HTTPException(404, "Agent not found")
        state.status = AgentStatus.SUSPENDED
        get_bus().emit(SystemEvent(
            event_type="agent_paused",
            source="dashboard",
            payload={"instance_id": instance_id},
        ))
        return {"ok": True}

    @app.post("/api/agents/{instance_id}/resume")
    def resume_agent(instance_id: str):
        aios = _get_aios()
        state = aios.kernel.agent_get(instance_id)
        if state is None:
            raise HTTPException(404, "Agent not found")
        state.status = AgentStatus.RUNNING
        get_bus().emit(SystemEvent(
            event_type="agent_resumed",
            source="dashboard",
            payload={"instance_id": instance_id},
        ))
        return {"ok": True}

    @app.post("/api/exec")
    def exec_syscall(data: dict[str, Any]):
        aios = _get_aios()
        action = data.get("action", "")
        if action == "status":
            snap = aios.kernel.sys_stats()
            return snap.model_dump()
        if action == "report":
            return aios.full_report()
        raise HTTPException(400, f"unknown action: {action}")

    @app.get("/api/report")
    def get_report():
        aios = _get_aios()
        return aios.full_report()

    @app.get("/api/agents")
    def list_agents():
        aios = _get_aios()
        states = aios.kernel.agent_list()
        result = []
        for s in states:
            result.append({
                "instance_id": s.instance_id,
                "goal": s.spec.goal[:80] if s.spec.goal else "",
                "owner": s.spec.owner,
                "status": s.status.value,
                "steps": s.steps,
                "model": s.spec.model,
                "scope": s.spec.max_scope.value,
                "action_count": len(s.spec.declared_actions),
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "finished_at": s.finished_at.isoformat() if s.finished_at else None,
                "result": s.result if s.result else None,
                "error": s.error if s.error else None,
            })
        return {"agents": result, "total": len(result)}

    @app.get("/api/agents/{instance_id}")
    def get_agent(instance_id: str):
        aios = _get_aios()
        state = aios.kernel.agent_get(instance_id)
        if state is None:
            raise HTTPException(status_code=404, detail="Agent not found")
        return {
            "instance_id": state.instance_id,
            "goal": state.spec.goal,
            "owner": state.spec.owner,
            "status": state.status.value,
            "steps": state.steps,
            "model": state.spec.model,
            "capabilities": [c.value for c in state.spec.capabilities],
            "actions": list(state.spec.declared_actions),
            "forbidden": list(state.spec.forbidden_actions),
            "scope": state.spec.max_scope.value,
            "created_at": state.created_at.isoformat() if state.created_at else None,
            "finished_at": state.finished_at.isoformat() if state.finished_at else None,
            "result": state.result,
            "error": state.error,
        }

    @app.get("/api/memory")
    def get_memory():
        aios = _get_aios()
        stats = aios.kernel.memory.stats()
        return stats

    @app.get("/api/events")
    def get_events(limit: int = 50):
        bus = get_bus()
        events = bus.recent(limit)
        return {
            "events": [
                {
                    "event_id": e.event_id,
                    "event_type": e.event_type,
                    "source": e.source,
                    "severity": e.severity.value,
                    "payload": e.payload,
                    "timestamp": e.timestamp.isoformat(),
                }
                for e in events
            ],
            "counts": bus.count_by_type(),
        }

    @app.websocket("/ws/events")
    async def ws_events(websocket: WebSocket):
        await websocket.accept()
        with _ws_lock:
            _ws_clients.add(websocket)
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            pass
        finally:
            with _ws_lock:
                _ws_clients.discard(websocket)

    @app.get("/api/traces")
    def get_traces(limit: int = 50):
        tracer = get_tracer()
        spans = tracer.recent(limit)
        return {"spans": spans}

    @app.get("/api/scheduler")
    def get_scheduler():
        aios = _get_aios()
        qs = aios.scheduler.queue_lengths()
        stat = aios.scheduler.stats
        return {
            "queue_lengths": qs,
            "total_scheduled": stat.total_scheduled,
            "preemptions": stat.preemptions,
            "prefill_cycles": stat.prefill_cycles,
            "decode_cycles": stat.decode_cycles,
            "avg_prefill_tokens": round(stat.avg_prefill_tokens, 1),
            "avg_decode_tokens": round(stat.avg_decode_tokens, 1),
        }

    @app.get("/api/kvcache")
    def get_kvcache():
        aios = _get_aios()
        kv = aios.kvcache.stats
        return {
            "total_blocks": kv.total_blocks,
            "free_blocks": kv.free_blocks,
            "used_blocks": kv.used_blocks,
            "utilization": round(kv.utilization, 3),
            "prefix_cache_hits": kv.prefix_cache_hits,
            "prefix_cache_misses": kv.prefix_cache_misses,
            "prefix_hit_rate": round(kv.prefix_hit_rate, 3),
            "evictions": kv.evictions,
            "prefix_cached_blocks": kv.prefix_cached_blocks,
        }

    # ── WebSocket broadcast hook ──
    _hook_registered = False

    def _broadcast_events():
        global _hook_registered
        if _hook_registered:
            return
        _hook_registered = True
        bus = get_bus()
        loop = asyncio.new_event_loop()

        async def _send(ws: WebSocket, data: str) -> None:
            try:
                await ws.send_text(data)
            except Exception:
                with _ws_lock:
                    _ws_clients.discard(ws)

        def _on_event(e: SystemEvent) -> None:
            data = json.dumps({
                "event_id": e.event_id,
                "event_type": e.event_type,
                "source": e.source,
                "severity": e.severity.value,
                "payload": e.payload,
                "timestamp": e.timestamp.isoformat(),
            })
            with _ws_lock:
                for ws in list(_ws_clients):
                    asyncio.run_coroutine_threadsafe(_send(ws, data), loop)

        bus.on("*", _on_event)
        threading.Thread(target=loop.run_forever, daemon=True).start()

    _broadcast_events()

    _STATIC_DIR.mkdir(parents=True, exist_ok=True)

    @app.get("/")
    def serve_index():
        index_path = _STATIC_DIR / "index.html"
        if not index_path.exists():
            return JSONResponse(
                status_code=404,
                content={"error": "Frontend not built. Run 'aios dashboard' to generate it."},
            )
        return FileResponse(str(index_path))

    @app.get("/{path:path}")
    def serve_static(path: str):
        file_path = _STATIC_DIR / path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        index_path = _STATIC_DIR / "index.html"
        if index_path.exists():
            return FileResponse(str(index_path))
        return JSONResponse(status_code=404, content={"error": "Not found"})


def create_server(instance: AIOS_P2 | None = None) -> Any:
    if not HAS_FASTAPI:
        raise ImportError("fastapi and uvicorn are required. Install with: pip install fastapi uvicorn")
    if instance:
        set_instance(instance)
    return app


def run_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    instance: AIOS_P2 | None = None,
    open_browser: bool = True,
) -> None:
    if not HAS_FASTAPI:
        raise ImportError("fastapi and uvicorn are required. Install with: pip install fastapi uvicorn")
    if instance:
        set_instance(instance)

    url = f"http://{host}:{port}"
    print(f"  AIOS Dashboard → {url}")

    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")
