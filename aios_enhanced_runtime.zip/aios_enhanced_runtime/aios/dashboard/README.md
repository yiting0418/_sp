# AIOS Dashboard — 網頁視覺化監控介面

## 快速啟動

```bash
# 安裝儀表板依賴（只需做一次）
pip install -e ".[dashboard]"

# 啟動儀表板
aios dashboard
```

啟動後瀏覽器會自動開啟 `http://127.0.0.1:8765`。

如果要改綁定 IP 或埠號：
```bash
aios dashboard --host 0.0.0.0 --port 8080 --no-browser
```

---

## 儀表板長什麼樣

畫面分成好幾個區塊：

### 最上方：系統狀態列
一排卡片顯示最重要的數字：
| 卡片 | 數字代表 |
|------|----------|
| **Active Agents** | 當前有多少 Agent 在執行 + 各狀態數量 |
| **KV-Cache Usage** | KV-Cache 使用率百分比 + 進度條（紅/黃/綠） |
| **Memory Entries** | 三層記憶體的條目總數 |
| **Models Loaded** | 已註冊的模型總數（VRAM/DRAM/NVMe） |
| **KB Entries** | 知識庫條目數 + 內建工具數 |
| **Syscalls** | 累計系統呼叫次數 |

### 第一行：KV-Cache + 排程器
- **左邊 KV-Cache 甜甜圈圖**：Used(藍)/Free(灰)/Prefix(綠) 區塊數，下面有 Prefix Hit Rate、驅逐次數
- **右邊 Scheduler 長條圖**：Prefill/Decode/Suspended 三個佇列當前有多少任務在等

### 第二行：Agent 列表 + 三層記憶體
- **左邊 Agent 列表**：所有 Agent 的狀態（執行中/等待中/完成/失敗）、目標（只顯示前 80 字）、擁有者、步數、使用的模型
- **右邊 三層記憶體**：
  - **Working Memory**：目前已用 / 總預算 token 數
  - **Episodic Memory**：對話歷史條目數
  - **Semantic Memory**：長期知識條目數

### 第三行：模型分層 + 快照 + 系統指標
- **模型分層**：VRAM（紅）/ DRAM（黃）/ NVMe（藍）各層有多少模型，以及 LoRA 適配器數量、快取命中率
- **KV 快照**：自然邊界快照總數、還原次數、快取資料量
- **系統指標**：6 個小方塊顯示累計資料（Syscalls / Context Switch / Active Agents / Tool Errors / Evictions / Tokens）

### 第四行：事件日誌 + Block Map
- **事件日誌**：即時顯示 EventBus 串流的最新事件（系統會自己更新）
- **Block Map**：最多 400 個小方塊直接視覺化 KV-Cache 哪些 block 被用掉（綠=prefix 快取、藍=使用中、灰=空閒）

---

## API 端點（給想自己寫前端或接監控系統用）

| 網址 | 回傳什麼 |
|------|----------|
| `http://127.0.0.1:8765/api/status` | 全部系統狀態一次拿（含 KV、Agent、Memory、Metrics 等） |
| `http://127.0.0.1:8765/api/report` | 完整 L1–L5 + Phase 3 報告（JSON） |
| `http://127.0.0.1:8765/api/agents` | 所有 Agent 列表 |
| `http://127.0.0.1:8765/api/agents/{id}` | 單一 Agent 詳細資料 |
| `http://127.0.0.1:8765/api/events` | 即時事件（30 筆） |
| `http://127.0.0.1:8765/api/kvcache` | KV-Cache 統計 |
| `http://127.0.0.1:8765/api/scheduler` | 排程器佇列狀態 |

直接打開瀏覽器或 `curl http://127.0.0.1:8765/api/status` 就能看到 JSON 資料。

---

## 頁面上的小功能

- **auto / paused**（右上角）：點擊可以開關自動更新（預設每 3 秒重新整理一次）
- **KV Block Map**：滑鼠移到 block 上方會放大，可以看到 block 編號
- **即時更新**：所有數字和圖表都會自動重新整理

---

## 技術架構

```
aios dashboard 命令
      │
      ▼
  FastAPI 後端 (server.py)      ← 包裝 AIOS_P2 實例
      │
      ├── /api/*  (JSON API)
      │
      ▼
  靜態 HTML 前端 (index.html)
      │
      ├── Chart.js 繪製圖表
      ├── Fetch API 定時輪詢後端
      └── 深色主題 CSS
```

後端資料來源全部來自 `AIOS_P2.full_report()`、`sys_stats()`、`EventBus`、`MetricRegistry`、`Tracer` 等既有可觀測性基礎設施，不需要改動原有程式碼。
