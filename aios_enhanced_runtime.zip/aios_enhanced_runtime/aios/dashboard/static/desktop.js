var AIOS = window.AIOS = window.AIOS || {};

AIOS.Desktop = {
  _apps: {},
  _runningWindows: {},
  _taskbarButtons: {},
  _notifCount: 0,
  _clockTimer: null,

  // ── App Definitions ──
  _APP_DEFS: [
    { id: 'launcher',  icon: '🚀', label: 'Agent\nLauncher',   color: 'blue',   pinned: true },
    { id: 'monitor',   icon: '📊', label: 'Agent\nMonitor',    color: 'green',  pinned: true },
    { id: 'sysmon',    icon: '📈', label: 'System\nMonitor',   color: 'purple', pinned: true },
  ],

  async init() {
    this.wm = new AIOS.WindowManager(document.getElementById('desktop-canvas'));
    this._setupDesktopIcons();
    this._setupTaskbar();
    this._setupStartMenu();
    this._setupContextMenu();
    this._setupClock();
    this._setupEventBus();

    // Load initial data
    try {
      const initData = await AIOS.API.init();
      this._updateTrayStatus(initData.status);
    } catch (e) {
      // offline
    }
    this.refreshAgentBadge();
  },

  // ── Desktop Icons ──
  _setupDesktopIcons() {
    const canvas = document.getElementById('desktop-canvas');
    this._APP_DEFS.forEach((app, i) => {
      const icon = document.createElement('div');
      icon.className = 'desktop-icon';
      icon.style.left = (40 + i * 100) + 'px';
      icon.style.top = '30px';
      icon.dataset.app = app.id;
      icon.innerHTML = `
        <div class="icon ${app.color}">${app.icon}</div>
        <div class="label">${app.label.replace('\n', '<br>')}</div>
      `;
      icon.addEventListener('dblclick', () => this._openApp(app.id));
      canvas.appendChild(icon);
    });
  },

  // ── Taskbar ──
  _setupTaskbar() {
    const pinned = document.getElementById('taskbar-pinned');
    this._APP_DEFS.forEach(app => {
      if (!app.pinned) return;
      const btn = document.createElement('button');
      btn.className = 'taskbar-btn';
      btn.dataset.app = app.id;
      btn.innerHTML = app.icon;
      btn.title = app.label.replace('\n', ' ');
      btn.addEventListener('click', () => this._toggleApp(app.id));
      pinned.appendChild(btn);
      this._taskbarButtons[app.id] = btn;
    });

    // Start button
    document.querySelector('.start-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      this._toggleStartMenu();
    });
  },

  _setupStartMenu() {
    const list = document.getElementById('start-menu-list');
    this._APP_DEFS.forEach(app => {
      const item = document.createElement('div');
      item.className = 'app-item';
      item.dataset.app = app.id;
      item.innerHTML = `
        <span class="icon">${app.icon}</span>
        <div class="info">
          <div>${app.label.replace('\n', ' ')}</div>
          <div class="desc">${this._getAppDesc(app.id)}</div>
        </div>
      `;
      item.addEventListener('click', () => {
        this._closeStartMenu();
        this._openApp(app.id);
      });
      list.appendChild(item);
    });
  },

  // ── Context Menu ──
  _setupContextMenu() {
    const desktop = document.getElementById('desktop');
    const menu = document.getElementById('context-menu');

    desktop.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      menu.style.display = 'block';
      menu.style.left = Math.min(e.clientX, window.innerWidth - 200) + 'px';
      menu.style.top = Math.min(e.clientY, window.innerHeight - 250) + 'px';
    });

    document.addEventListener('click', () => {
      menu.style.display = 'none';
    });

    menu.querySelectorAll('[data-action]').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = item.dataset.action;
        if (action === 'open-launcher') { this._openApp('launcher'); }
        else if (action === 'open-monitor') { this._openApp('monitor'); }
        else if (action === 'open-sysmon') { this._openApp('sysmon'); }
        else if (action === 'refresh') { this.refreshAgentBadge(); }
        menu.style.display = 'none';
      });
    });
  },

  // ── Clock ──
  _setupClock() {
    this._updateClock();
    this._clockTimer = setInterval(() => this._updateClock(), 1000);
  },

  _updateClock() {
    const now = new Date();
    const time = now.toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' });
    const el = document.getElementById('desktop-clock');
    if (el) el.textContent = time;
  },

  // ── Event Bus (WebSocket) ──
  _setupEventBus() {
    AIOS.API.connectEvents((evt) => {
      if (evt.event_type === 'agent_spawned' ||
          evt.event_type === 'agent_completed' ||
          evt.event_type === 'agent_failed' ||
          evt.event_type === 'agent_killed') {
        this.refreshAgentBadge();
      }
    });
  },

  // ── App Management ──
  _openApp(appId) {
    // If already open, focus it
    if (this._runningWindows[appId]) {
      this.wm.focus(this._runningWindows[appId]);
      return;
    }

    const def = this._APP_DEFS.find(a => a.id === appId);
    if (!def) return;

    let opts;
    switch (appId) {
      case 'launcher':
        opts = {
          title: 'Agent Launcher',
          icon: '🚀',
          width: 440, height: 460,
          body: AIOS.AppLauncher.render(),
          app: appId,
          onClose: () => { delete this._runningWindows[appId]; },
        };
        break;
      case 'monitor':
        opts = {
          title: 'Agent Monitor',
          icon: '📊',
          width: 560, height: 360,
          body: AIOS.AppMonitor.render(),
          app: appId,
          onClose: () => {
            delete this._runningWindows[appId];
            if (AIOS.AppMonitor) AIOS.AppMonitor.destroy();
          },
        };
        break;
      case 'sysmon':
        opts = {
          title: 'System Monitor',
          icon: '📈',
          width: 480, height: 420,
          body: AIOS.AppSysMon.render(),
          app: appId,
          onClose: () => {
            delete this._runningWindows[appId];
            if (AIOS.AppSysMon) AIOS.AppSysMon.destroy();
          },
        };
        break;
      default: return;
    }

    const win = this.wm.create(opts);
    this._runningWindows[appId] = win.id;

    // Init the app
    const body = this.wm.getBody(win.id);
    if (body) {
      switch (appId) {
        case 'launcher': AIOS.AppLauncher.init(body); break;
        case 'monitor': AIOS.AppMonitor.init(body); break;
        case 'sysmon': AIOS.AppSysMon.init(body); break;
      }
    }

    // Highlight taskbar button
    if (this._taskbarButtons[appId]) {
      this._taskbarButtons[appId].classList.add('active');
    }
  },

  _toggleApp(appId) {
    if (this._runningWindows[appId]) {
      const winId = this._runningWindows[appId];
      const w = this.wm.windows.find(w => w.id === winId);
      if (w) {
        if (w.win.classList.contains('minimized')) {
          this.wm.restore(winId);
        } else {
          this.wm.minimize(winId);
        }
      }
    } else {
      this._openApp(appId);
    }
  },

  refreshAgentBadge() {
    // Update running app indicator
    this._APP_DEFS.forEach(def => {
      const btn = this._taskbarButtons[def.id];
      if (!btn) return;
      if (this._runningWindows[def.id]) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  },

  // ── Start Menu ──
  _toggleStartMenu() {
    document.getElementById('start-menu').classList.toggle('show');
  },

  _closeStartMenu() {
    document.getElementById('start-menu').classList.remove('show');
  },

  // ── Tray ──
  _updateTrayStatus(status) {
    const agents = status.agents || {};
    const total = Object.values(agents).reduce((a, b) => a + b, 0);
    const el = document.getElementById('tray-status');
    if (el) el.textContent = `Agent:${total}`;
  },

  // ── Helpers ──
  _getAppDesc(id) {
    const descs = {
      launcher: 'Create and launch new AI agents',
      monitor: 'Monitor and manage running agents',
      sysmon: 'View system resources and metrics',
    };
    return descs[id] || '';
  },

  destroy() {
    if (this._clockTimer) clearInterval(this._clockTimer);
    if (AIOS.AppMonitor) AIOS.AppMonitor.destroy();
    if (AIOS.AppSysMon) AIOS.AppSysMon.destroy();
  },
};

// ── Bootstrap ──
document.addEventListener('DOMContentLoaded', () => {
  AIOS.Desktop.init();
});
