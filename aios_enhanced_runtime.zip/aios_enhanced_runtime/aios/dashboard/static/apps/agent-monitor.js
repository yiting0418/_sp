var AIOS = window.AIOS = window.AIOS || {};

AIOS.AppMonitor = {
  _timer: null,
  _body: null,

  render() {
    return `
      <div class="app-monitor">
        <table>
          <thead>
            <tr>
              <th>Status</th>
              <th>Goal</th>
              <th>Steps</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="monitor-body">
            <tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">Loading...</td></tr>
          </tbody>
        </table>
        <div id="monitor-detail" style="display:none;margin-top:8px;padding:10px;border-radius:6px;background:var(--bg-desktop);font-size:12px;">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px;">
            <strong id="monitor-detail-title" style="color:var(--text-primary);"></strong>
            <span id="monitor-detail-status" style="font-weight:600;"></span>
          </div>
          <pre id="monitor-detail-output" style="font-family:var(--font-mono);font-size:11px;color:var(--text-secondary);white-space:pre-wrap;word-break:break-all;max-height:150px;overflow-y:auto;margin:0;"></pre>
        </div>
      </div>
    `;
  },

  init(body) {
    this._body = body;
    this._refresh();
    this._timer = setInterval(() => this._refresh(), 3000);
  },

  async _refresh() {
    try {
      const data = await AIOS.API.getAgents();
      this._renderTable(data.agents || []);
    } catch (e) {}
  },

  _renderTable(agents) {
    const tbody = this._body.querySelector('#monitor-body');
    if (!agents.length) {
      tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px;">No agents</td></tr>';
      if (AIOS.Desktop) AIOS.Desktop.refreshAgentBadge();
      return;
    }

    tbody.innerHTML = agents.map(a => {
      const sc = a.status === 'running' ? 'status-running' : a.status === 'pending' ? 'status-pending' : a.status === 'done' ? 'status-done' : a.status === 'failed' ? 'status-failed' : a.status === 'suspended' ? 'status-suspended' : '';
      const hasResult = a.result || a.error;
      return `<tr class="agent-row" data-id="${a.instance_id}" style="cursor:pointer;">
        <td><span class="status-badge ${sc}">${a.status}</span></td>
        <td class="goal-cell" title="${this._esc(a.goal)}">${this._esc(a.goal)}${hasResult ? ' 📋' : ''}</td>
        <td style="font-variant-numeric:tabular-nums">${a.steps}</td>
        <td>
          ${a.status === 'running' || a.status === 'pending'
            ? `<button class="action-btn pause" data-id="${a.instance_id}" data-action="pause">⏸</button><button class="action-btn kill" data-id="${a.instance_id}" data-action="kill">⏹</button>`
            : a.status === 'suspended'
              ? `<button class="action-btn resume" data-id="${a.instance_id}" data-action="resume">▶</button><button class="action-btn kill" data-id="${a.instance_id}" data-action="kill">⏹</button>`
              : `<span style="color:var(--text-muted);font-size:11px;">—</span>`}
        </td>
      </tr>`;
    }).join('');

    tbody.querySelectorAll('.agent-row').forEach(row => {
      row.addEventListener('click', async (e) => {
        if (e.target.closest('.action-btn')) return;
        const id = row.dataset.id;
        try {
          const detail = await AIOS.API.getAgent(id);
          this._showDetail(detail);
        } catch (err) {}
      });
    });

    tbody.querySelectorAll('.action-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const action = btn.dataset.action;
        try {
          if (action === 'kill') await AIOS.API.killAgent(id);
          else if (action === 'pause') await AIOS.API.pauseAgent(id);
          else if (action === 'resume') await AIOS.API.resumeAgent(id);
          this._refresh();
          if (AIOS.Desktop) AIOS.Desktop.refreshAgentBadge();
        } catch (e) { console.error('Agent action failed:', e); }
      });
    });

    if (AIOS.Desktop) AIOS.Desktop.refreshAgentBadge();
  },

  _showDetail(d) {
    const el = this._body.querySelector('#monitor-detail');
    el.style.display = 'block';
    this._body.querySelector('#monitor-detail-title').textContent = d.goal ? '📋 ' + d.goal.slice(0, 100) : 'Agent ' + d.instance_id.slice(0, 8);
    const statusEl = this._body.querySelector('#monitor-detail-status');
    statusEl.textContent = d.status.toUpperCase();
    statusEl.style.color = d.status === 'done' ? 'var(--accent-green)' : d.status === 'failed' ? 'var(--accent-red)' : d.status === 'running' ? 'var(--accent-blue)' : 'var(--text-secondary)';
    const output = d.result || d.error || 'No output';
    this._body.querySelector('#monitor-detail-output').textContent = output;
  },

  _esc(s) {
    if (!s) return '';
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  },

  destroy() { if (this._timer) clearInterval(this._timer); },
};
