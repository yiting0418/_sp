var AIOS = window.AIOS = window.AIOS || {};

AIOS.AppLauncher = {
  _CAPABILITIES: [
    { value: 'memory:read:personal', label: 'Mem Read' },
    { value: 'memory:write:personal', label: 'Mem Write' },
    { value: 'kb:search', label: 'KB Search' },
    { value: 'kb:index', label: 'KB Index' },
    { value: 'tool:web_fetch', label: 'Web Fetch' },
    { value: 'tool:code_exec:sandboxed', label: 'Code Exec' },
    { value: 'tool:file_read', label: 'File Read' },
    { value: 'tool:file_write', label: 'File Write' },
  ],

  _SELECTED_CAPS: new Set([
    'memory:read:personal',
    'memory:write:personal',
    'tool:code_exec:sandboxed',
    'tool:web_fetch',
    'tool:file_read',
    'tool:file_write',
  ]),

  _pendingAgentId: null,
  _body: null,

  getDefaultActions() {
    return [
      'mem_recall', 'mem_store', 'tool_call',
      'tool:code_exec', 'tool:file_read', 'tool:file_write',
      'tool:web_fetch', 'tool:web_search',
    ];
  },

  render() {
    const capsHtml = this._CAPABILITIES.map(c => `
      <button class="cap-chip ${this._SELECTED_CAPS.has(c.value) ? 'selected' : ''}"
              data-cap="${c.value}">${c.label}</button>
    `).join('');

    return `
      <div class="app-launcher">
        <div class="form-group">
          <label>Goal</label>
          <textarea id="launcher-goal" placeholder="Describe the task for the AI agent..." rows="3"></textarea>
        </div>
        <div class="form-group">
          <label>Model</label>
          <select id="launcher-model">
            <option value="default">Default</option>
          </select>
        </div>
        <div class="form-group">
          <label>Owner</label>
          <input id="launcher-owner" type="text" value="user:desktop" />
        </div>
        <div class="form-group">
          <label>Max Steps</label>
          <input id="launcher-steps" type="number" value="20" min="1" max="100" />
        </div>
        <div class="form-group">
          <label>Capabilities</label>
          <div class="cap-grid">${capsHtml}</div>
        </div>
        <div class="form-group">
          <button class="btn-primary" id="launcher-submit">🚀 Launch Agent</button>
        </div>
        <div id="launcher-result" style="display:none;margin-top:8px;">
          <div style="padding:10px;border-radius:6px;background:var(--bg-desktop);">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
              <strong id="launcher-status-badge" style="font-size:12px;">⏳ Running...</strong>
              <button id="launcher-view-btn" style="display:none;padding:3px 10px;border:none;border-radius:4px;background:var(--accent-blue);color:#fff;font-size:11px;cursor:pointer;">📊 Monitor</button>
            </div>
            <div id="launcher-output" style="font-size:11px;color:var(--text-secondary);max-height:400px;overflow-y:auto;margin:0;padding:0;"></div>
          </div>
        </div>
      </div>
    `;
  },

  init(body) {
    this._body = body;
    body.querySelectorAll('.cap-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const cap = chip.dataset.cap;
        if (this._SELECTED_CAPS.has(cap)) { this._SELECTED_CAPS.delete(cap); chip.classList.remove('selected'); }
        else { this._SELECTED_CAPS.add(cap); chip.classList.add('selected'); }
      });
    });
    body.querySelector('#launcher-submit').addEventListener('click', () => this._submit());
    this._ws = AIOS.API.connectEvents((evt) => {
      if (!this._pendingAgentId) return;
      if (evt.event_type === 'agent_completed' || evt.event_type === 'agent_failed') {
        if ((evt.payload || {}).instance_id === this._pendingAgentId) this._onDone(evt);
      }
    });
  },

  async _submit() {
    const b = this._body;
    const goal = b.querySelector('#launcher-goal').value.trim();
    const model = b.querySelector('#launcher-model').value;
    const owner = b.querySelector('#launcher-owner').value.trim();
    const maxSteps = parseInt(b.querySelector('#launcher-steps').value) || 20;
    const btn = b.querySelector('#launcher-submit');
    if (!goal) return this._showMsg('Please enter a goal', true);
    btn.disabled = true; btn.textContent = '⏳ Launching...';
    b.querySelector('#launcher-result').style.display = 'none';
    try {
      const r = await AIOS.API.spawnAgent({ goal, model, owner, max_steps: maxSteps, capabilities: [...this._SELECTED_CAPS], actions: this.getDefaultActions() });
      this._pendingAgentId = r.instance_id;
      this._showMsg('⏳ Running...', false);
      this._poll(r.instance_id);
      if (AIOS.Desktop) AIOS.Desktop.refreshAgentBadge();
    } catch (e) { this._showMsg('❌ ' + e.message, true); }
    finally { btn.disabled = false; btn.textContent = '🚀 Launch Agent'; }
  },

  async _poll(id) {
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 2000));
      try {
        const s = await AIOS.API.getAgent(id);
        if (s.status === 'done') { this._showFinal(s.result || '(no output)'); this._pendingAgentId = null; return; }
        if (s.status === 'failed') { this._showFinal('❌ ' + (s.error || 'Unknown error'), true); this._pendingAgentId = null; return; }
      } catch (e) {}
    }
  },

  _onDone(evt) {
    const p = evt.payload || {};
    if (evt.event_type === 'agent_completed') this._showFinal(p.result || '✅ Completed');
    else this._showFinal('❌ ' + (p.error || 'Failed'), true);
    this._pendingAgentId = null;
  },

  _showFinal(output, isError) {
    const b = this._body;
    const badge = b.querySelector('#launcher-status-badge');
    badge.textContent = isError ? '❌ Failed' : '✅ Completed';
    badge.style.color = isError ? 'var(--accent-red)' : 'var(--accent-green)';
    b.querySelector('#launcher-output').innerHTML = this._formatOutput(output);
    const vb = b.querySelector('#launcher-view-btn');
    vb.style.display = 'inline-block';
    vb.onclick = () => { if (AIOS.Desktop) AIOS.Desktop._openApp('monitor'); };
  },

  _formatOutput(text) {
    if (!text || typeof text !== 'string') return this._escHtml(text || '');
    const m = text.match(/=== web_search 結果 ===\s*\n([\s\S]*?)(?:\n===|\nKV |\n行為|$)/);
    if (!m) return `<pre style="font-family:var(--font-mono);font-size:11px;color:var(--text-secondary);white-space:pre-wrap;margin:0;">${this._escHtml(text)}</pre>`;
    const section = m[1];
    const qm = section.match(/query:\s*(.+)/);
    const query = qm ? qm[1].trim() : '';
    const rm = section.match(/results:\s*(\[.+?\])\s*$/m);
    if (!rm) return `<pre style="font-family:var(--font-mono);font-size:11px;color:var(--text-secondary);white-space:pre-wrap;margin:0;">${this._escHtml(text)}</pre>`;
    let results;
    try { results = JSON.parse(rm[1].replace(/'/g, '"')); } catch (e) { results = []; }
    if (!results.length) return `<pre style="font-family:var(--font-mono);font-size:11px;color:var(--text-secondary);white-space:pre-wrap;margin:0;">${this._escHtml(text)}</pre>`;
    const cards = results.map(r => `
      <div style="padding:10px;margin-bottom:8px;border-radius:6px;background:var(--bg-card);border:1px solid var(--border);">
        <div style="font-size:12px;font-weight:600;color:var(--accent-blue);margin-bottom:4px;line-height:1.4;">
          <a href="${this._escAttr(r.url)}" target="_blank" rel="noopener" style="color:var(--accent-blue);text-decoration:none;">${this._escHtml(r.title)}</a>
        </div>
        <div style="font-size:11px;color:var(--text-secondary);line-height:1.5;margin-bottom:4px;">${this._escHtml(r.snippet)}</div>
        <div style="font-size:10px;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${this._escHtml(r.url)}</div>
      </div>
    `).join('');
    return `<div style="margin-bottom:8px;font-size:11px;color:var(--text-secondary);">搜尋「${this._escHtml(query)}」找到 ${results.length} 筆結果：</div>${cards}`;
  },

  _escHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  },

  _escAttr(s) {
    return String(s).replace(/"/g, '&quot;').replace(/&/g, '&amp;');
  },

  _showMsg(msg, isError) {
    const el = this._body.querySelector('#launcher-result');
    el.style.display = 'block';
    this._body.querySelector('#launcher-status-badge').textContent = msg;
    this._body.querySelector('#launcher-status-badge').style.color = isError ? 'var(--accent-red)' : 'var(--accent-yellow)';
    this._body.querySelector('#launcher-output').textContent = '';
    this._body.querySelector('#launcher-view-btn').style.display = 'none';
  },

  destroy() { this._pendingAgentId = null; },
};
