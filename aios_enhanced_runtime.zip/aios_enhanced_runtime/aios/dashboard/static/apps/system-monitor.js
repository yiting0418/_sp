var AIOS = window.AIOS = window.AIOS || {};

AIOS.AppSysMon = {
  _timer: null,

  render() {
    return `
      <div class="app-sysmon">
        <div class="stat-grid" id="sysmon-stats">
          <div class="stat-card"><div class="val" id="sm-agents" style="color:var(--accent-blue);">—</div><div class="lbl">Agents</div></div>
          <div class="stat-card"><div class="val" id="sm-mem" style="color:var(--accent-cyan);">—</div><div class="lbl">Memory</div></div>
          <div class="stat-card"><div class="val" id="sm-kv" style="color:var(--accent-green);">—</div><div class="lbl">KV Usage</div><div class="bar-track"><div class="bar-fill" id="sm-kv-bar" style="width:0%;background:var(--accent-green);"></div></div></div>
          <div class="stat-card"><div class="val" id="sm-models" style="color:var(--accent-purple);">—</div><div class="lbl">Models</div></div>
          <div class="stat-card"><div class="val" id="sm-syscalls" style="color:var(--accent-yellow);">—</div><div class="lbl">Syscalls</div></div>
          <div class="stat-card"><div class="val" id="sm-snapshots" style="color:var(--accent-red);">—</div><div class="lbl">Snapshots</div></div>
        </div>
        <div class="section-title">KV Cache Blocks</div>
        <div style="display:flex;flex-wrap:wrap;gap:2px;" id="sm-kv-grid"></div>
        <div class="section-title" style="margin-top:8px;">Memory Tiers</div>
        <div id="sm-memory-tiers"></div>
      </div>
    `;
  },

  init(body) {
    this._body = body;
    this._refresh();
    this._timer = setInterval(() => this._refresh(), 3000);
  },

  async _refresh() {
    try {
      const data = await AIOS.API.getStatus();
      this._updateStats(data);
      this._updateKV(data.kvcache || {});
      this._updateMemory(data.memory || {});
    } catch (e) {
      // retry
    }
  },

  _updateStats(data) {
    const agents = data.agents || {};
    const totalAgents = Object.values(agents).reduce((a, b) => a + b, 0);
    const mem = data.memory || {};
    const memTotal = (mem.episodic_count || 0) + (mem.semantic_count || 0);
    const kv = data.kvcache || {};
    const utilPct = ((kv.utilization || 0) * 100).toFixed(1);
    const models = data.models || {};
    const snapshots = data.snapshots || {};
    const metrics = data.metrics || {};
    const syscallTotal = Object.entries(metrics)
      .filter(([k]) => k.includes('syscall_total'))
      .reduce((a, [, v]) => a + (v.value || 0), 0);

    this._setText('sm-agents', totalAgents);
    this._setText('sm-mem', memTotal);
    this._setText('sm-kv', utilPct + '%');
    this._setStyle('sm-kv-bar', 'width', utilPct + '%');
    this._setStyle('sm-kv-bar', 'background', kv.utilization > 0.7 ? 'var(--accent-red)' : kv.utilization > 0.4 ? 'var(--accent-yellow)' : 'var(--accent-green)');
    this._setText('sm-models', models.total_models || 0);
    this._setText('sm-syscalls', syscallTotal);
    this._setText('sm-snapshots', snapshots.total || 0);
  },

  _updateKV(kv) {
    const grid = this._body.querySelector('#sm-kv-grid');
    if (!grid) return;
    const total = Math.min(kv.total_blocks || 0, 300);
    const used = kv.used_blocks || 0;
    const prefix = kv.prefix_cached_blocks || 0;
    grid.innerHTML = '';
    for (let i = 0; i < total; i++) {
      const block = document.createElement('div');
      block.style.cssText = 'width:8px;height:8px;border-radius:1px;';
      if (i < prefix) { block.style.background = 'var(--accent-green)'; }
      else if (i < used) { block.style.background = 'var(--accent-blue)'; }
      else { block.style.background = 'rgba(48,54,61,0.6)'; }
      block.title = `Block ${i}`;
      grid.appendChild(block);
    }
  },

  _updateMemory(mem) {
    const container = this._body.querySelector('#sm-memory-tiers');
    if (!container) return;
    const workingUsed = mem.working_tokens_used || 0;
    const workingBudget = mem.working_token_budget || 8000;
    const workingPct = Math.min(100, (workingUsed / workingBudget) * 100);
    const episodicCount = mem.episodic_count || 0;
    const semanticCount = mem.semantic_count || 0;

    container.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
        <span style="width:60px;font-size:12px;color:var(--accent-blue);">Working</span>
        <div style="flex:1;height:12px;background:var(--bg-desktop);border-radius:3px;overflow:hidden;">
          <div style="height:100%;width:${workingPct}%;background:linear-gradient(90deg,var(--accent-blue),#1f6feb);border-radius:3px;"></div>
        </div>
        <span style="width:80px;text-align:right;font-size:11px;font-family:var(--font-mono);color:var(--text-secondary);">${workingUsed}/${workingBudget}</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
        <span style="width:60px;font-size:12px;color:var(--accent-green);">Episodic</span>
        <div style="flex:1;height:12px;background:var(--bg-desktop);border-radius:3px;overflow:hidden;">
          <div style="height:100%;width:${Math.min(100, episodicCount * 5)}%;background:linear-gradient(90deg,var(--accent-green),#238636);border-radius:3px;"></div>
        </div>
        <span style="width:80px;text-align:right;font-size:11px;font-family:var(--font-mono);color:var(--text-secondary);">${episodicCount}</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;padding:4px 0;">
        <span style="width:60px;font-size:12px;color:var(--accent-purple);">Semantic</span>
        <div style="flex:1;height:12px;background:var(--bg-desktop);border-radius:3px;overflow:hidden;">
          <div style="height:100%;width:${Math.min(100, semanticCount * 5)}%;background:linear-gradient(90deg,var(--accent-purple),#6f42c1);border-radius:3px;"></div>
        </div>
        <span style="width:80px;text-align:right;font-size:11px;font-family:var(--font-mono);color:var(--text-secondary);">${semanticCount}</span>
      </div>
    `;
  },

  _setText(id, val) {
    const el = this._body.querySelector('#' + id);
    if (el) el.textContent = val;
  },

  _setStyle(id, prop, val) {
    const el = this._body.querySelector('#' + id);
    if (el) el.style[prop] = val;
  },

  destroy() {
    if (this._timer) clearInterval(this._timer);
  },
};
