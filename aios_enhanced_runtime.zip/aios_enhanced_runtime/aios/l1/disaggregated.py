"""
aios.l1.disaggregated
──────────────────────
分離式 Prefill / Decode 協調層。

架構：
  將傳統單節點推論拆為兩個階段，在不同節點上執行：

  ┌────────────┐     RDMA KV-Cache     ┌────────────┐
  │  Prefill   │  ─────────────────→   │   Decode   │
  │  Node      │  KV block transfer    │   Node     │
  │  (GPU)     │                       │   (GPU)    │
  └────────────┘                       └────────────┘
       O(n²) attention                    逐 token 生成

  效益：
    - Prefill 節點專注計算吞吐，不浪費 VRAM 在 decode 的 KV-Cache
    - Decode 節點不需要重算 prefill，直接接收 KV-Cache 開始生成
    - 兩者可獨立 scale（prefill 節點少但強，decode 節點多）

核心元件：
  NodeRegistry            — 節點註冊與健康檢查
  DisaggregatedOrchestrator — Prefill→Decode 協調流程
"""

from __future__ import annotations

import asyncio
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p2 import InferencePhase
from aios.core.models_p3 import (
    GlobalScheduleDecision,
    KVTransferResult,
    NodeInfo,
    NodeType,
    PrefillNodeAllocation,
    ScheduleType,
    TransferUrgency,
)
from aios.l1.kvcache import KVCacheManager
from aios.l1.rdma import KVTransferManager


# ════════════════════════════════════════════════════════════════════
# 節點註冊表
# ════════════════════════════════════════════════════════════════════

class NodeRegistry:
    """
    叢集節點註冊與健康檢查。

    維護所有已知節點的即時狀態。
    每個節點定期發送 heartbeat 更新健康狀態。
    """

    def __init__(
        self,
        heartbeat_timeout_s: float = 15.0,
    ):
        self._nodes: dict[str, NodeInfo] = {}
        self._heartbeat_timeout = heartbeat_timeout_s

    def register(
        self,
        node_id:   str,
        node_type: NodeType,
        address:   str = "localhost:0",
        vram_mb:   float = 16_000.0,
        kv_blocks: int = 256,
    ) -> NodeInfo:
        """註冊一個新節點。"""
        info = NodeInfo(
            node_id=node_id,
            node_type=node_type,
            address=address,
            vram_mb=vram_mb,
            kv_blocks_available=kv_blocks,
            kv_blocks_used=0,
        )
        self._nodes[node_id] = info
        return info

    def unregister(self, node_id: str) -> None:
        self._nodes.pop(node_id, None)

    def heartbeat(self, node_id: str) -> bool:
        """更新節點心跳。回傳節點是否存在。"""
        node = self._nodes.get(node_id)
        if node is None:
            return False
        node.last_heartbeat = datetime.now(timezone.utc)
        return True

    def update_load(
        self,
        node_id:     str,
        vram_used:   float | None = None,
        kv_used:     int | None = None,
        active_tasks: int | None = None,
    ) -> None:
        """更新節點的即時負載資訊。"""
        node = self._nodes.get(node_id)
        if node is None:
            return
        if vram_used is not None:
            node.vram_used_mb = vram_used
        if kv_used is not None:
            node.kv_blocks_used = kv_used
        if active_tasks is not None:
            node.active_tasks = active_tasks
        node.load_score = self._compute_load_score(node)

    def get_node(self, node_id: str) -> NodeInfo | None:
        return self._nodes.get(node_id)

    def list_nodes(self) -> list[NodeInfo]:
        return list(self._nodes.values())

    def list_by_type(self, node_type: NodeType) -> list[NodeInfo]:
        return [
            n for n in self._nodes.values()
            if n.node_type == node_type or n.node_type == NodeType.HYBRID
        ]

    def healthy_nodes(self) -> list[NodeInfo]:
        """回傳心跳未超時的節點列表。"""
        now = datetime.now(timezone.utc)
        return [
            n for n in self._nodes.values()
            if (now - n.last_heartbeat).total_seconds() < self._heartbeat_timeout
        ]

    def best_prefill_node(self) -> NodeInfo | None:
        """選擇負載最輕的 prefill 節點。"""
        candidates = self.list_by_type(NodeType.PREFILL_ONLY)
        candidates += self.list_by_type(NodeType.HYBRID)
        healthy = [n for n in candidates if n in self.healthy_nodes()]
        if not healthy:
            return None
        return min(healthy, key=lambda n: n.active_tasks)

    def best_decode_node(self, kv_hint: str = "") -> NodeInfo | None:
        """選擇負載最輕的 decode 節點。"""
        candidates = self.list_by_type(NodeType.DECODE_ONLY)
        candidates += self.list_by_type(NodeType.HYBRID)
        healthy = [n for n in candidates if n in self.healthy_nodes()]
        if not healthy:
            return None
        return min(healthy, key=lambda n: n.load_score)

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "total_nodes":     len(self._nodes),
            "healthy":         len(self.healthy_nodes()),
            "prefill_nodes":   len(self.list_by_type(NodeType.PREFILL_ONLY)),
            "decode_nodes":    len(self.list_by_type(NodeType.DECODE_ONLY)),
            "hybrid_nodes":    len(self.list_by_type(NodeType.HYBRID)),
            "total_vram_mb":   sum(n.vram_mb for n in self._nodes.values()),
            "used_vram_mb":    sum(n.vram_used_mb for n in self._nodes.values()),
        }

    @staticmethod
    def _compute_load_score(node: NodeInfo) -> float:
        vram_util = node.vram_used_mb / max(1, node.vram_mb)
        kv_util   = node.kv_blocks_used / max(1, node.kv_blocks_available + node.kv_blocks_used)
        task_factor = node.active_tasks / max(1, node.active_tasks + 1)
        return min(1.0, (vram_util * 0.5 + kv_util * 0.3 + task_factor * 0.2))


# ════════════════════════════════════════════════════════════════════
# 分離式 Prefill/Decode 協調器
# ════════════════════════════════════════════════════════════════════

class DisaggregatedOrchestrator:
    """
    Prefill→Decode 協調流程。

    流程：
      1. 接收推論請求
      2. 選擇 prefill 節點
      3. Prefill 節點完成 attention 計算
      4. 透過 RDMA 將 KV-Cache 遷移至 decode 節點
      5. Decode 節點開始生成

    每個階段可以獨立 scale，且傳輸對上層透明。
    """

    def __init__(
        self,
        registry:       NodeRegistry,
        transfer_mgr:   KVTransferManager,
        kvcache_nodes:  dict[str, KVCacheManager],
        enable_async:   bool = True,
    ):
        self._registry      = registry
        self._transfer_mgr  = transfer_mgr
        self._kvcache_nodes = kvcache_nodes
        self._enable_async  = enable_async

        self._allocations: dict[str, PrefillNodeAllocation] = {}
        self._completed_transfers: list[KVTransferResult] = []

    async def orchestrate(
        self,
        task_id:     str,
        instance_id: str,
        prompt_tokens: int,
        prefer_node: str | None = None,
    ) -> PrefillNodeAllocation:
        """
        執行完整的 Prefill→Decode 協調。

        步驟：
          1. 選擇 prefill 節點
          2. 分配 prefill 資源
          3. 選擇 decode 節點（或等待排程器決定）
          4. 回傳分配結果
        """
        # 1. 選擇 prefill 節點
        prefill_node = self._registry.best_prefill_node()
        if prefill_node is None:
            raise RuntimeError("no available prefill node")

        # 2. 選擇 decode 節點
        decode_node = prefer_node or self._select_decode_node(instance_id)

        # 3. 建立分配記錄
        allocation = PrefillNodeAllocation(
            task_id=task_id,
            instance_id=instance_id,
            prefill_node=prefill_node.node_id,
            decode_node=decode_node,
        )
        self._allocations[task_id] = allocation

        # 4. 更新節點負載
        self._registry.update_load(
            prefill_node.node_id,
            vram_used=prefill_node.vram_used_mb + _estimate_prefill_vram(prompt_tokens),
            active_tasks=prefill_node.active_tasks + 1,
        )

        return allocation

    async def transfer_to_decode(
        self,
        task_id:     str,
        block_ids:   list[int],
        sequence_id: str = "",
        instance_id: str = "",
    ) -> KVTransferResult:
        """
        Prefill 完成後，將 KV block 傳輸到 decode 節點。

        這是分離式架構的關鍵路徑：
        每次 prefill 完成後呼叫此方法，
        將 KV-Cache 透過 RDMA 遷移至 decode 節點。
        """
        allocation = self._allocations.get(task_id)
        if allocation is None:
            raise ValueError(f"no allocation for task {task_id}")

        if not allocation.decode_node:
            raise ValueError(f"no decode node assigned for task {task_id}")

        result = await self._transfer_mgr.transfer_blocks(
            source_node=allocation.prefill_node,
            target_node=allocation.decode_node,
            block_ids=block_ids,
            sequence_id=sequence_id,
            instance_id=instance_id or allocation.instance_id,
            urgency=TransferUrgency.CRITICAL,
        )

        if result.success:
            self._completed_transfers.append(result)

            # 更新節點負載
            p_node = self._registry.get_node(allocation.prefill_node)
            d_node = self._registry.get_node(allocation.decode_node)
            if p_node:
                self._registry.update_load(
                    p_node.node_id,
                    active_tasks=max(0, p_node.active_tasks - 1),
                )
            if d_node:
                self._registry.update_load(
                    d_node.node_id,
                    kv_used=(d_node.kv_blocks_used or 0) + len(block_ids),
                    active_tasks=(d_node.active_tasks or 0) + 1,
                )

        return result

    def allocation_for(self, task_id: str) -> PrefillNodeAllocation | None:
        return self._allocations.get(task_id)

    def release(self, task_id: str) -> None:
        """釋放任務的分配記錄。"""
        self._allocations.pop(task_id, None)

    def _select_decode_node(self, instance_id: str) -> str | None:
        """選擇 decode 節點。簡單策略：選擇負載最輕者。"""
        node = self._registry.best_decode_node()
        return node.node_id if node else None

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "active_allocations": len(self._allocations),
            "completed_transfers": len(self._completed_transfers),
            "successful_transfers": sum(
                1 for r in self._completed_transfers if r.success
            ),
            "failed_transfers": sum(
                1 for r in self._completed_transfers if not r.success
            ),
        }


def _estimate_prefill_vram(prompt_tokens: int) -> float:
    """粗估 prefill 階段需要的 VRAM（MB）。"""
    return prompt_tokens * 0.002  # ~2KB per token for KV-Cache
