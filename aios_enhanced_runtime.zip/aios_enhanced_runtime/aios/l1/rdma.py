"""
aios.l1.rdma
─────────────
RDMA KV-Cache 遷移層。

抽象：
  分離式 Prefill/Decode 架構中，Prefill 節點完成 attention 計算後，
  必須將 KV tensor 遷移至 Decode 節點。本模組定義遷移的傳輸合約。

實作：
  RDMATransport       — 抽象傳輸層（模擬 RDMA verbs: read/write/send）
  LocalRDMATransport  — 同程序模擬（in-process dict copy）
  KVTransferManager   — 遷移佇列管理、優先序排程、重試

RDMA 語意（與 InfiniBand RC 對應）：
  - send(source, target, payload)  — 主動推送（對應 ibv_post_send）
  - read(source, target, addr)     — 遠端讀取（對應 ibv_post_read，zero-copy）
  - poll()                          — 完成佇列輪詢（對應 ibv_poll_cq）
"""

from __future__ import annotations

import asyncio
import time
import uuid
from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from aios.core.models_p2 import KVBlock
from aios.core.models_p3 import (
    KVTransferRequest,
    KVTransferResult,
    TransferUrgency,
)
from aios.l1.kvcache import KVCacheManager


# ════════════════════════════════════════════════════════════════════
# 抽象傳輸層
# ════════════════════════════════════════════════════════════════════

class RDMATransport(ABC):
    """
    RDMA 抽象傳輸。
    模擬 InfiniBand RC（Reliable Connection）語意。
    """

    @abstractmethod
    async def send(
        self,
        source_node: str,
        target_node: str,
        block_ids:   list[int],
        payload:     list[Any],
        urgency:     TransferUrgency = TransferUrgency.NORMAL,
    ) -> KVTransferResult:
        """主動推送 KV block 至目標節點。"""

    @abstractmethod
    async def request(
        self,
        source_node: str,
        target_node: str,
        block_ids:   list[int],
    ) -> KVTransferResult:
        """向遠端節點請求 KV block（遠端讀取，zero-copy 語意）。"""

    @abstractmethod
    def register_node(self, node_id: str) -> None:
        """註冊一個可連接的遠端節點。"""

    @abstractmethod
    def unregister_node(self, node_id: str) -> None:
        """移除節點（節點離線時呼叫）。"""


# ════════════════════════════════════════════════════════════════════
# 同程序模擬傳輸
# ════════════════════════════════════════════════════════════════════

class LocalRDMATransport(RDMATransport):
    """
    同程序模擬 RDMA 傳輸。

    用 dict 模擬遠端節點的記憶體空間：
      - send() = 寫入目標節點的「遠端記憶體」
      - request() = 從目標節點的「遠端記憶體」讀取

    此實作用於測試與原型驗證。
    生產環境應替換為真實的 ibverbs 或 UCX binding。
    """

    def __init__(self) -> None:
        # node_id → {block_id → block_data}
        self._remote_memory: dict[str, dict[int, Any]] = defaultdict(dict)
        self._latency_us: int = 50          # 模擬 RDMA 延遲
        self._bandwidth_mbps: float = 12_000.0  # 模擬 ~12 GB/s

    async def send(
        self,
        source_node: str,
        target_node: str,
        block_ids:   list[int],
        payload:     list[Any],
        urgency:     TransferUrgency = TransferUrgency.NORMAL,
    ) -> KVTransferResult:
        transfer_id = uuid.uuid4().hex[:12]
        total_bytes = sum(
            _estimate_block_size(b) for b in payload
        )

        # 模擬 RDMA 傳輸延遲
        latency = self._simulate_latency(total_bytes, urgency)
        await asyncio.sleep(latency / 1_000_000)

        # 寫入遠端記憶體
        target_mem = self._remote_memory[target_node]
        for bid, data in zip(block_ids, payload):
            target_mem[bid] = data

        return KVTransferResult(
            transfer_id=transfer_id,
            success=True,
            bytes_transferred=total_bytes,
            latency_us=latency,
        )

    async def request(
        self,
        source_node: str,
        target_node: str,
        block_ids:   list[int],
    ) -> KVTransferResult:
        transfer_id = uuid.uuid4().hex[:12]
        target_mem = self._remote_memory.get(target_node, {})
        total_bytes = 0
        payload: list[Any] = []

        for bid in block_ids:
            data = target_mem.get(bid)
            if data is None:
                return KVTransferResult(
                    transfer_id=transfer_id,
                    success=False,
                    error=f"block {bid} not found on node {target_node}",
                )
            payload.append(data)
            total_bytes += _estimate_block_size(data)

        latency = self._simulate_latency(total_bytes, TransferUrgency.CRITICAL)
        await asyncio.sleep(latency / 1_000_000)

        # 將讀取到的 block 註冊到發起節點
        source_mem = self._remote_memory[source_node]
        for bid, data in zip(block_ids, payload):
            source_mem[bid] = data

        return KVTransferResult(
            transfer_id=transfer_id,
            success=True,
            bytes_transferred=total_bytes,
            latency_us=latency,
        )

    def register_node(self, node_id: str) -> None:
        self._remote_memory[node_id] = {}

    def unregister_node(self, node_id: str) -> None:
        self._remote_memory.pop(node_id, None)

    def _simulate_latency(
        self,
        bytes_count: int,
        urgency: TransferUrgency,
    ) -> float:
        """
        模擬 RDMA 傳輸延遲（微秒）。

        計算公式：
          latency = base_latency + (bytes / bandwidth)
          base_latency 依 urgency 調整
        """
        urgency_factor = {
            TransferUrgency.CRITICAL:   1.0,
            TransferUrgency.NORMAL:     2.0,
            TransferUrgency.BACKGROUND: 5.0,
        }[urgency]

        base_us = self._latency_us * urgency_factor
        transfer_us = (bytes_count / (self._bandwidth_mbps * 1_000_000 / 8)) * 1_000_000
        return base_us + transfer_us

    def get_remote_blocks(self, node_id: str) -> dict[int, Any]:
        """除錯用：檢視遠端節點的所有 block。"""
        return dict(self._remote_memory.get(node_id, {}))


# ════════════════════════════════════════════════════════════════════
# KV 遷移管理器
# ════════════════════════════════════════════════════════════════════

class KVTransferManager:
    """
    KV-Cache 遷移管理。

    職責：
      1. 管理傳輸請求佇列（按 urgency 排序）
      2. 透過 RDMATransport 實際傳輸
      3. 傳輸完成後通知目標節點的 KVCacheManager
      4. 重試與錯誤恢復

    使用方式：
      manager = KVTransferManager(transport, kvcache_nodes)
      await manager.transfer_blocks(source, target, block_ids)
    """

    def __init__(
        self,
        transport:     RDMATransport,
        kvcache_nodes: dict[str, KVCacheManager],  # node_id → KVCacheManager
        max_retries:   int = 3,
    ):
        self._transport     = transport
        self._kvcache_nodes = kvcache_nodes
        self._max_retries   = max_retries

        # urgency → list[KVTransferRequest]
        self._pending: dict[TransferUrgency, list[KVTransferRequest]] = {
            u: [] for u in TransferUrgency
        }
        self._in_flight: dict[str, KVTransferRequest] = {}
        self._completed: list[KVTransferResult] = []

        self._stats = TransferStats()

    async def transfer_blocks(
        self,
        source_node: str,
        target_node: str,
        block_ids:   list[int],
        sequence_id: str = "",
        instance_id: str = "",
        urgency:     TransferUrgency = TransferUrgency.NORMAL,
    ) -> KVTransferResult:
        """
        排程並執行一次 KV block 傳輸。

        若相同 block 已在此節點，立即成功（略過傳輸）。
        否則通過 RDMATransport 發送。
        """
        # 檢查目標是否已有這些 block
        target_kv = self._kvcache_nodes.get(target_node)
        if target_kv:
            existing = target_kv.get_prefix_hit_blocks([])
            needed   = [b for b in block_ids if b not in existing]
        else:
            needed = block_ids

        if not needed:
            return KVTransferResult(
                transfer_id=uuid.uuid4().hex[:12],
                success=True,
                bytes_transferred=0,
                latency_us=0,
            )

        # 從 source 讀取 block data
        source_kv = self._kvcache_nodes.get(source_node)
        payload: list[Any] = []
        if source_kv:
            for bid in needed:
                block = source_kv._blocks.get(bid)
                payload.append(block.data if block else None)

        # 建立請求
        req = KVTransferRequest(
            transfer_id=uuid.uuid4().hex[:12],
            source_node=source_node,
            target_node=target_node,
            block_ids=needed,
            sequence_id=sequence_id,
            instance_id=instance_id,
            urgency=urgency,
            payload=payload,
        )

        self._pending[urgency].append(req)
        self._in_flight[req.transfer_id] = req

        result = await self._execute_transfer(req)
        self._stats.record(result)
        return result

    async def _execute_transfer(
        self,
        req: KVTransferRequest,
    ) -> KVTransferResult:
        """執行單次傳輸，含重試邏輯。"""
        last_error: str | None = None

        for attempt in range(1, self._max_retries + 1):
            result = await self._transport.send(
                source_node=req.source_node,
                target_node=req.target_node,
                block_ids=req.block_ids,
                payload=req.payload,
                urgency=req.urgency,
            )

            if result.success:
                # 將 block 註冊到目標 KVCacheManager
                target_kv = self._kvcache_nodes.get(req.target_node)
                if target_kv and req.payload:
                    self._register_blocks(target_kv, req.block_ids, req.payload)

                self._in_flight.pop(req.transfer_id, None)
                return result

            last_error = result.error
            wait = 0.01 * (2 ** attempt)  # exponential backoff
            await asyncio.sleep(wait)

        self._in_flight.pop(req.transfer_id, None)
        return KVTransferResult(
            transfer_id=req.transfer_id,
            success=False,
            error=f"transfer failed after {self._max_retries} retries: {last_error}",
        )

    def _register_blocks(
        self,
        kvcache:   KVCacheManager,
        block_ids: list[int],
        payload:   list[Any],
    ) -> None:
        """將遠端傳來的 block 註冊到本機 KVCacheManager。"""
        for bid, data in zip(block_ids, payload):
            if bid in kvcache._blocks:
                block = kvcache._blocks[bid]
                block.data    = data
                block.is_free = False
                block.ref_count += 1
                kvcache._stats.free_blocks -= 1
                kvcache._stats.used_blocks += 1

    @property
    def stats(self) -> TransferStats:
        return self._stats

    @property
    def pending_count(self) -> int:
        return sum(len(q) for q in self._pending.values())

    @property
    def in_flight_count(self) -> int:
        return len(self._in_flight)


@dataclass
class TransferStats:
    total_transfers:  int   = 0
    successful:       int   = 0
    failed:           int   = 0
    total_bytes:      int   = 0
    total_latency_us: float = 0.0

    def record(self, result: KVTransferResult) -> None:
        self.total_transfers += 1
        if result.success:
            self.successful += 1
        else:
            self.failed += 1
        self.total_bytes      += result.bytes_transferred
        self.total_latency_us += result.latency_us

    @property
    def avg_latency_us(self) -> float:
        return self.total_latency_us / max(1, self.total_transfers)

    @property
    def success_rate(self) -> float:
        return self.successful / max(1, self.total_transfers)


def _estimate_block_size(data: Any) -> int:
    """估算 KV block 的位元組大小。"""
    import numpy as np
    if isinstance(data, np.ndarray):
        return data.nbytes
    if isinstance(data, bytes):
        return len(data)
    return 1024  # default estimate
