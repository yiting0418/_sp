"""
aios.l1.kv_router
──────────────────
KV-Cache 感知請求路由。

將推論請求路由到最佳節點，考慮：
  1. KV-Cache 位置 — 將請求導向已快取其 prefix 的節點
  2. 負載平衡 — 在相同 KV 位置的節點之間分散請求
  3. 一致性雜湊 — 讓相同 prefix 的請求穩定落到同一組節點

核心資料結構：
  PrefixCacheMap  — prefix_hash → set[node_id]（全域 prefix 位置索引）
  ConsistentHashRouter — 一致性雜湊路由（prefix 層級的穩定映射）
"""

from __future__ import annotations

import hashlib
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p3 import (
    GlobalScheduleDecision,
    NodeInfo,
    NodeType,
    RingNode,
    ScheduleType,
)


# ════════════════════════════════════════════════════════════════════
# 全域 Prefix Cache 位置索引
# ════════════════════════════════════════════════════════════════════

class PrefixCacheMap:
    """
    全域 prefix cache 位置索引。

    追蹤每個 prefix hash 在哪些節點上有快取。
    由 KVCacheManager 在 cache hit/miss 時通知更新。
    """

    def __init__(self):
        # prefix_hash → set[node_id]
        self._map: dict[str, set[str]] = defaultdict(set)
        # node_id → set[prefix_hash]（反向索引，用於節點離線清理）
        self._reverse: dict[str, set[str]] = defaultdict(set)

    def record_hit(
        self,
        prefix_hash: str,
        node_id:     str,
    ) -> None:
        """記錄某節點上發生了 prefix cache hit。"""
        self._map[prefix_hash].add(node_id)
        self._reverse[node_id].add(prefix_hash)

    def record_miss(
        self,
        prefix_hash: str,
        node_id:     str,
    ) -> None:
        """記錄某節點上發生了 prefix cache miss。"""
        # 不從 map 移除（可能其他節點仍有）
        pass

    def record_eviction(
        self,
        prefix_hash: str,
        node_id:     str,
    ) -> None:
        """記錄某節點上 prefix 被驅逐。"""
        node_set = self._map.get(prefix_hash)
        if node_set:
            node_set.discard(node_id)
            if not node_set:
                del self._map[prefix_hash]
        reverse_set = self._reverse.get(node_id)
        if reverse_set:
            reverse_set.discard(prefix_hash)

    def nodes_for_prefix(self, prefix_hash: str) -> set[str]:
        """回傳擁有此 prefix cache 的節點集合。"""
        return set(self._map.get(prefix_hash, set()))

    def prefixes_on_node(self, node_id: str) -> set[str]:
        """回傳某節點上的所有 prefix hash。"""
        return set(self._reverse.get(node_id, set()))

    def remove_node(self, node_id: str) -> None:
        """節點離線時，清除其所有記錄。"""
        prefixes = self._reverse.pop(node_id, set())
        for ph in prefixes:
            node_set = self._map.get(ph)
            if node_set:
                node_set.discard(node_id)
                if not node_set:
                    del self._map[ph]

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "total_prefixes": len(self._map),
            "total_nodes_with_cache": len(self._reverse),
            "avg_nodes_per_prefix": round(
                sum(len(v) for v in self._map.values()) / max(1, len(self._map)),
                2,
            ),
        }


# ════════════════════════════════════════════════════════════════════
# 一致性雜湊路由
# ════════════════════════════════════════════════════════════════════

class ConsistentHashRouter:
    """
    一致性雜湊路由。

    用於 routing key → node 的穩定映射。
    節點增減時，只影響少量 routing key 的重新分配。

    使用方式：
      router = ConsistentHashRouter()
      router.add_node("node-a", 100)
      router.add_node("node-b", 100)
      node = router.route("prefix_hash_abc")
    """

    def __init__(
        self,
        virtual_nodes: int = 100,
    ):
        self._virtual_nodes = virtual_nodes
        # hash → node_id
        self._ring: dict[int, str] = {}
        self._sorted_hashes: list[int] = []
        self._nodes: dict[str, RingNode] = {}

    def add_node(
        self,
        node_id:   str,
        weight:    float = 1.0,
        address:   str = "",
    ) -> None:
        """
        加入節點至雜湊環。

        weight 控制虛擬節點數量：weight=1.0 時建立 virtual_nodes 個。
        高 weight 的節點獲得較多的 hash 位置，承擔更多流量。
        """
        ring_node = RingNode(
            node_id=node_id,
            address=address,
            virtual_count=int(self._virtual_nodes * weight),
            weight=weight,
        )
        self._nodes[node_id] = ring_node

        for i in range(ring_node.virtual_count):
            h = self._hash(f"{node_id}:vnode:{i}")
            self._ring[h] = node_id

        self._sorted_hashes = sorted(self._ring.keys())

    def remove_node(self, node_id: str) -> None:
        """從雜湊環移除節點。"""
        self._nodes.pop(node_id, None)
        self._ring = {
            h: nid for h, nid in self._ring.items() if nid != node_id
        }
        self._sorted_hashes = sorted(self._ring.keys())

    def route(self, key: str) -> str | None:
        """
        將 key 路由到一個節點。

        使用一致性雜湊演算法：
          1. 計算 key 的 hash
          2. 在環上找第一個 hash >= key_hash 的節點
          3. 若無，繞回第一個節點（環語意）
        """
        if not self._sorted_hashes:
            return None

        key_hash = self._hash(key)

        # binary search
        import bisect
        idx = bisect.bisect_left(self._sorted_hashes, key_hash)
        if idx >= len(self._sorted_hashes):
            idx = 0

        ring_hash = self._sorted_hashes[idx]
        return self._ring[ring_hash]

    def route_multi(self, key: str, n: int) -> list[str]:
        """
        將 key 路由到 n 個節點（用於複製或備援）。
        回傳 n 個不重複的節點 ID。
        """
        if not self._sorted_hashes or n == 0:
            return []

        key_hash = self._hash(key)
        import bisect
        idx = bisect.bisect_left(self._sorted_hashes, key_hash)

        seen: set[str] = set()
        result: list[str] = []
        for offset in range(len(self._sorted_hashes)):
            actual_idx = (idx + offset) % len(self._sorted_hashes)
            node_id = self._ring[self._sorted_hashes[actual_idx]]
            if node_id not in seen:
                seen.add(node_id)
                result.append(node_id)
            if len(result) >= n:
                break
        return result

    def get_node(self, node_id: str) -> RingNode | None:
        return self._nodes.get(node_id)

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    @property
    def ring_size(self) -> int:
        return len(self._sorted_hashes)

    @staticmethod
    def _hash(key: str) -> int:
        return int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)


# ════════════════════════════════════════════════════════════════════
# KV-Cache 感知路由器（組合 PrefixCacheMap + ConsistentHashRouter）
# ════════════════════════════════════════════════════════════════════

class KVRouter:
    """
    KV-Cache 感知請求路由器。

    路由策略層級：
      1. 若 prefix hash 有快取 → 路由到快取節點（局部性優先）
      2. 若無快取 → 用一致性雜湊穩定分配（避免 cache miss 震盪）
      3. 若目標節點不可用 → fallback 到負載最輕的節點

    使用方式：
      router = KVRouter(node_registry)
      node = router.route_request(prefix_tokens=[101, 203, ...])
    """

    def __init__(
        self,
        node_registry: Any,      # NodeRegistry
        prefix_cache:  PrefixCacheMap | None = None,
        router:        ConsistentHashRouter | None = None,
    ):
        self._registry = node_registry
        self._prefix_cache = prefix_cache or PrefixCacheMap()
        self._ch_router = router or ConsistentHashRouter()

    def add_node(self, node_id: str, weight: float = 1.0, address: str = "") -> None:
        self._ch_router.add_node(node_id, weight, address)

    def remove_node(self, node_id: str) -> None:
        self._ch_router.remove_node(node_id)
        self._prefix_cache.remove_node(node_id)

    def route_request(
        self,
        prefix_tokens:  list[int],
        instance_id:    str = "",
        schedule_type:  ScheduleType = ScheduleType.PREFILL,
    ) -> str | None:
        """
        為推論請求選擇最佳節點。

        Args:
          prefix_tokens: 請求的 prefix token 序列
          instance_id:   推論實例 ID
          schedule_type: 排程類型

        Returns:
          目標節點 ID，若無可用節點則回傳 None。
        """
        prefix_hash = self._compute_prefix_hash(prefix_tokens)
        healthy     = self._registry.healthy_nodes()
        healthy_ids = {n.node_id for n in healthy}

        if not healthy_ids:
            return None

        # 策略 1: KV-Cache 局部性
        cached_nodes = self._prefix_cache.nodes_for_prefix(prefix_hash)
        candidates   = cached_nodes & healthy_ids
        if candidates:
            self._prefix_cache.record_hit(prefix_hash, next(iter(candidates)))
            return min(candidates, key=lambda nid: self._get_load(nid))

        # 策略 2: 一致性雜湊
        hashed_node = self._ch_router.route(prefix_hash)
        if hashed_node and hashed_node in healthy_ids:
            self._prefix_cache.record_miss(prefix_hash, hashed_node)
            return hashed_node

        # Fallback: 負載最輕
        fallback = min(healthy, key=lambda n: n.load_score)
        self._prefix_cache.record_miss(prefix_hash, fallback.node_id)
        return fallback.node_id

    def route_prefill(
        self,
        prefix_tokens: list[int],
        instance_id:   str = "",
    ) -> str | None:
        """選擇 prefill 節點。"""
        return self.route_request(prefix_tokens, instance_id, ScheduleType.PREFILL)

    def route_decode(
        self,
        prefix_tokens: list[int],
        instance_id:   str = "",
    ) -> str | None:
        """選擇 decode 節點（偏好 DECODE_ONLY 節點）。"""
        healthy = self._registry.healthy_nodes()
        decoders = [
            n for n in healthy
            if n.node_type in (NodeType.DECODE_ONLY, NodeType.HYBRID)
        ]
        if not decoders:
            return None

        prefix_hash = self._compute_prefix_hash(prefix_tokens)
        cached = self._prefix_cache.nodes_for_prefix(prefix_hash)
        decoder_ids = {n.node_id for n in decoders}
        candidates = cached & decoder_ids
        if candidates:
            return min(candidates, key=lambda nid: self._get_load(nid))

        return min(decoders, key=lambda n: n.load_score).node_id

    def update_prefix_cache(
        self,
        prefix_hash: str,
        node_id:     str,
        is_hit:      bool,
    ) -> None:
        if is_hit:
            self._prefix_cache.record_hit(prefix_hash, node_id)
        else:
            self._prefix_cache.record_miss(prefix_hash, node_id)

    def _compute_prefix_hash(self, tokens: list[int]) -> str:
        if not tokens:
            return ""
        import hashlib as hl
        return hl.sha256(
            b"".join(t.to_bytes(4, "little") for t in tokens[:64])
        ).hexdigest()[:16]

    def _get_load(self, node_id: str) -> float:
        node = self._registry.get_node(node_id)
        return node.load_score if node else float("inf")

    @property
    def prefix_stats(self) -> dict[str, Any]:
        return self._prefix_cache.stats
