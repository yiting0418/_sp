"""
aios.l1.scheduler
──────────────────
Tensor 感知排程器。

核心設計：
  推論任務有兩個截然不同的計算階段，必須以不同策略排程：

  PREFILL  — 計算密集，O(n²) attention，適合大批次合併
             排程依據：Time-to-first-token（越快越好）

  DECODE   — 記憶體頻寬密集，逐 token 生成，適合 Continuous Batching
             排程依據：吞吐量（tokens/sec）

排程器維護兩個獨立的優先佇列；每個排程週期：
  1. 優先處理所有待 PREFILL 的高優先序任務
  2. 將所有 DECODE 任務合併為一個 batch 統一推進
  3. PREFILL 完成後自動晉升至 DECODE 佇列
"""

from __future__ import annotations

import heapq
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p2 import (
    InferencePhase,
    InferenceTask,
    TaskPriority,
)
from aios.l1.kvcache import KVCacheManager


# ════════════════════════════════════════════════════════════════════
# 排程決策
# ════════════════════════════════════════════════════════════════════

@dataclass
class ScheduleDecision:
    """一次排程週期的輸出：告訴執行層要做什麼。"""
    prefill_batch: list[InferenceTask] = field(default_factory=list)
    decode_batch:  list[InferenceTask] = field(default_factory=list)
    suspended:     list[str]           = field(default_factory=list)   # task_id
    cycle_id:      int                 = 0
    timestamp:     datetime            = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def total_tasks(self) -> int:
        return len(self.prefill_batch) + len(self.decode_batch)


@dataclass
class SchedulerStats:
    total_scheduled:    int   = 0
    prefill_cycles:     int   = 0
    decode_cycles:      int   = 0
    preemptions:        int   = 0
    avg_prefill_tokens: float = 0.0
    avg_decode_tokens:  float = 0.0


# ════════════════════════════════════════════════════════════════════
# Priority Queue Entry（heapq 需要可比較物件）
# ════════════════════════════════════════════════════════════════════

@dataclass(order=True)
class _QueueEntry:
    priority:  int          # TaskPriority.value，越小越高優先
    enqueue_time: float     # monotonic，相同 priority 時先進先出
    task_id:   str = field(compare=False)
    task:      InferenceTask = field(compare=False)


# ════════════════════════════════════════════════════════════════════
# Tensor Scheduler
# ════════════════════════════════════════════════════════════════════

class TensorScheduler:
    """
    兩階段 Tensor 感知排程器。

    PREFILL 佇列：priority heap，高優先序任務先做 prefill。
    DECODE  佇列：priority heap，高優先序任務優先佔用 decode slot。

    Continuous Batching：
      每個 decode 週期，所有 DECODE 任務合併為一個 batch，
      在同一個 forward pass 中各自生成下一個 token。
      新完成 prefill 的任務可在當前週期就加入 decode batch（不等下一輪）。

    Preemption：
      若 VRAM 不足以服務所有 decode 任務，驅逐優先序最低的任務
      並建立 KV-Cache 快照（由 L2 SnapshotManager 處理）。
    """

    def __init__(
        self,
        kvcache:          KVCacheManager,
        max_prefill_batch: int = 8,     # 同時 prefill 的最大任務數
        max_decode_batch:  int = 32,    # 同時 decode 的最大任務數
        vram_headroom:     float = 0.1, # 保留 10% VRAM 避免 OOM
    ):
        self._kvcache           = kvcache
        self._max_prefill_batch = max_prefill_batch
        self._max_decode_batch  = max_decode_batch
        self._vram_headroom     = vram_headroom

        self._prefill_queue: list[_QueueEntry] = []   # heapq
        self._decode_queue:  list[_QueueEntry] = []   # heapq
        self._tasks:         dict[str, InferenceTask] = {}

        self._cycle_id = 0
        self._stats    = SchedulerStats()

    # ── 任務提交 ─────────────────────────────────────────────────────

    def submit(self, task: InferenceTask) -> None:
        """提交一個新推論任務。進入 PREFILL 佇列。"""
        task.phase = InferencePhase.PREFILL
        self._tasks[task.task_id] = task
        entry = _QueueEntry(
            priority=task.priority.value,
            enqueue_time=time.monotonic(),
            task_id=task.task_id,
            task=task,
        )
        heapq.heappush(self._prefill_queue, entry)

    def resume(self, task: InferenceTask) -> None:
        """恢復一個被暫停的任務（從快照恢復後呼叫）。"""
        task.phase = InferencePhase.DECODE   # 恢復後直接進入 decode
        self._tasks[task.task_id] = task
        entry = _QueueEntry(
            priority=task.priority.value,
            enqueue_time=time.monotonic(),
            task_id=task.task_id,
            task=task,
        )
        heapq.heappush(self._decode_queue, entry)

    # ── 排程週期 ─────────────────────────────────────────────────────

    def schedule(self) -> ScheduleDecision:
        """
        執行一個排程週期，回傳本週期的執行決策。
        呼叫方（Runtime）根據決策驅動推論引擎。
        """
        self._cycle_id += 1
        decision = ScheduleDecision(cycle_id=self._cycle_id)

        # 1. 處理 PREFILL 批次
        prefill_batch = self._select_prefill_batch()
        for task in prefill_batch:
            task.phase      = InferencePhase.PREFILL
            task.started_at = datetime.now(timezone.utc)
            decision.prefill_batch.append(task)
            self._stats.prefill_cycles    += 1
            self._stats.total_scheduled   += 1
            self._stats.avg_prefill_tokens = _running_avg(
                self._stats.avg_prefill_tokens,
                task.prompt_tokens,
                self._stats.prefill_cycles,
            )

        # 2. prefill 完成的任務晉升至 decode（模擬：prefill 在本週期立即完成）
        for task in prefill_batch:
            task.phase = InferencePhase.DECODE
            entry = _QueueEntry(
                priority=task.priority.value,
                enqueue_time=time.monotonic(),
                task_id=task.task_id,
                task=task,
            )
            heapq.heappush(self._decode_queue, entry)

        # 3. 檢查 VRAM 壓力，必要時搶佔低優先序 decode 任務
        while self._is_vram_pressure() and self._decode_queue:
            victim_entry = self._pop_lowest_priority_decode()
            if victim_entry:
                victim_entry.task.phase = InferencePhase.SUSPENDED
                decision.suspended.append(victim_entry.task_id)
                self._stats.preemptions += 1

        # 4. 組成 decode 批次
        decode_batch = self._select_decode_batch()
        for task in decode_batch:
            task.phase             = InferencePhase.DECODE
            task.generated_tokens += 1   # 模擬：每個 decode 週期生成 1 token
            decision.decode_batch.append(task)
            self._stats.decode_cycles    += 1
            self._stats.total_scheduled  += 1
            self._stats.avg_decode_tokens = _running_avg(
                self._stats.avg_decode_tokens,
                task.generated_tokens,
                self._stats.decode_cycles,
            )

        return decision

    def complete_task(self, task_id: str) -> InferenceTask | None:
        """標記任務完成，釋放其 KV-Cache（保留 prefix）。"""
        task = self._tasks.pop(task_id, None)
        if task is None:
            return None
        task.phase        = InferencePhase.IDLE
        task.completed_at = datetime.now(timezone.utc)

        if task.block_table:
            self._kvcache.release_sequence(
                task.block_table.sequence_id,
                retain_prefix=True,   # 跨輪保留 prefix
            )
        return task

    # ── 佇列查詢 ─────────────────────────────────────────────────────

    def queue_lengths(self) -> dict[str, int]:
        return {
            "prefill": len(self._prefill_queue),
            "decode":  len(self._decode_queue),
            "total":   len(self._tasks),
        }

    @property
    def stats(self) -> SchedulerStats:
        return self._stats

    # ── 內部排程邏輯 ─────────────────────────────────────────────────

    def _select_prefill_batch(self) -> list[InferenceTask]:
        batch: list[InferenceTask] = []
        temp: list[_QueueEntry]    = []

        while self._prefill_queue and len(batch) < self._max_prefill_batch:
            entry = heapq.heappop(self._prefill_queue)
            # 已完成或已暫停的任務略過
            if entry.task.phase not in (InferencePhase.PREFILL,):
                continue
            batch.append(entry.task)

        # 未選中的放回（因 max_batch 限制而被略過的）
        for e in temp:
            heapq.heappush(self._prefill_queue, e)

        return batch

    def _select_decode_batch(self) -> list[InferenceTask]:
        batch: list[InferenceTask] = []
        leftover: list[_QueueEntry] = []

        while self._decode_queue and len(batch) < self._max_decode_batch:
            entry = heapq.heappop(self._decode_queue)
            task  = entry.task
            if task.phase == InferencePhase.SUSPENDED:
                continue
            if task.generated_tokens >= task.max_tokens:
                self.complete_task(task.task_id)
                continue
            batch.append(task)
            # 未完成的任務放回等下一輪
            if task.generated_tokens < task.max_tokens:
                leftover.append(entry)

        for e in leftover:
            heapq.heappush(self._decode_queue, e)

        return batch

    def _pop_lowest_priority_decode(self) -> _QueueEntry | None:
        """找出並移除優先序最低（數字最大）的 decode 任務。"""
        if not self._decode_queue:
            return None
        # 轉換為 list，找最低優先序
        worst_idx = max(
            range(len(self._decode_queue)),
            key=lambda i: (
                self._decode_queue[i].priority,
                -self._decode_queue[i].enqueue_time,
            )
        )
        entry = self._decode_queue.pop(worst_idx)
        heapq.heapify(self._decode_queue)
        return entry

    def _is_vram_pressure(self) -> bool:
        util = self._kvcache.utilization()
        return util > (1.0 - self._vram_headroom)


def _running_avg(current: float, new_val: float, n: int) -> float:
    if n <= 1:
        return float(new_val)
    return current + (new_val - current) / n
