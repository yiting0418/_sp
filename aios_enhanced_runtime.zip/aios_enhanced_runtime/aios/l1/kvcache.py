"""
aios.l1.kvcache
────────────────
KV-Cache 管理器：PagedAttention 風格的分頁記憶體管理。

架構必要條件（來自設計文件）：
  「L1 KV-Cache 管理器必須以『跨輪次保留 prefix』為預設行為。
    這不是可選最佳化，而是使 Syscall 成本可接受的基礎設施前提。」

核心特性：
  1. 分頁管理     — 每個 block 固定 block_size token，避免記憶體碎片
  2. 跨序列共享   — 相同 prefix hash 的 block 只存一份（prefix cache）
  3. 跨輪保留     — 推論完成後 prefix block 不立即釋放，等待複用
  4. 引用計數     — 多個序列共享同一 block 時安全管理生命週期
  5. LRU 驅逐     — 記憶體壓力時驅逐最久未使用的 free block
"""

from __future__ import annotations

import hashlib
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import numpy as np

from aios.core.models_p2 import BlockTable, KVBlock


# ════════════════════════════════════════════════════════════════════
# KV-Cache 統計
# ════════════════════════════════════════════════════════════════════

@dataclass
class KVCacheStats:
    total_blocks:       int   = 0
    free_blocks:        int   = 0
    used_blocks:        int   = 0
    prefix_cached_blocks: int = 0
    prefix_cache_hits:  int   = 0
    prefix_cache_misses: int  = 0
    evictions:          int   = 0

    @property
    def utilization(self) -> float:
        if self.total_blocks == 0:
            return 0.0
        return self.used_blocks / self.total_blocks

    @property
    def prefix_hit_rate(self) -> float:
        total = self.prefix_cache_hits + self.prefix_cache_misses
        return self.prefix_cache_hits / total if total > 0 else 0.0


# ════════════════════════════════════════════════════════════════════
# KV-Cache Manager
# ════════════════════════════════════════════════════════════════════

class KVCacheManager:
    """
    PagedAttention 風格的 KV-Cache 管理器。

    模擬一個有 `total_blocks` 個固定大小頁面的記憶體池。
    Phase 2：以 numpy 模擬 KV 資料。
    Phase 3：替換為真實 GPU VRAM 指標。

    關鍵設計：
      - block 分配對上層透明（序列只看邏輯 block table）
      - prefix_hash 相同的 block 跨序列共用（ref_count 管理）
      - 跨輪保留：sequence 完成後，prefix block 的 ref_count 降至 0
        但不立即釋放——保留在 prefix_cache 中供下一輪複用
    """

    NUM_HEADS:  int = 4     # 模擬值，Phase 3 依模型設定
    HEAD_DIM:   int = 32    # 模擬值

    def __init__(
        self,
        total_blocks: int = 256,
        block_size:   int = 16,
        num_heads:    int = 4,
        head_dim:     int = 32,
        prefix_cache_capacity: int = 64,    # 最多保留多少個 prefix block
    ):
        self.block_size              = block_size
        self.num_heads               = num_heads
        self.head_dim                = head_dim
        self.prefix_cache_capacity   = prefix_cache_capacity

        # 物理 block 池
        self._blocks: dict[int, KVBlock] = {}
        for bid in range(total_blocks):
            self._blocks[bid] = KVBlock(block_id=bid, block_size=block_size)

        # 空閒 block 佇列（LRU 驅逐用）
        self._free_ids: list[int] = list(range(total_blocks))

        # prefix_hash → block_id（跨序列 prefix 共享）
        # 使用 OrderedDict 維持 LRU 順序
        self._prefix_cache: OrderedDict[str, int] = OrderedDict()

        # sequence_id → BlockTable
        self._block_tables: dict[str, BlockTable] = {}

        self._stats = KVCacheStats(total_blocks=total_blocks, free_blocks=total_blocks)

    # ── 公開 API ─────────────────────────────────────────────────────

    def allocate_sequence(self, sequence_id: str) -> BlockTable:
        """建立一個新序列的 BlockTable。"""
        bt = BlockTable(sequence_id=sequence_id)
        self._block_tables[sequence_id] = bt
        return bt

    def append_tokens(
        self,
        sequence_id: str,
        token_count: int,
        prefix_tokens: list[int] | None = None,
    ) -> BlockTable:
        """
        為序列追加 token_count 個 token，必要時分配新 block。

        若提供 prefix_tokens，先嘗試 prefix cache 命中：
          命中 → 重用現有 block，跳過 prefill（Syscall 成本大幅降低）
          未命中 → 分配新 block，完成 prefill 後加入 prefix cache
        """
        bt = self._block_tables.get(sequence_id)
        if bt is None:
            bt = self.allocate_sequence(sequence_id)

        # 嘗試 prefix cache 命中
        prefix_blocks_reused = 0
        if prefix_tokens:
            prefix_blocks_reused = self._try_prefix_cache(bt, prefix_tokens)

        # 計算還需要多少新 block
        tokens_covered   = (len(bt.logical_blocks) - prefix_blocks_reused) * self.block_size
        tokens_needed    = token_count - tokens_covered
        if tokens_needed < 0:
            tokens_needed = 0

        new_blocks_needed = max(
            0,
            (len(bt.logical_blocks) * self.block_size + tokens_needed
             - len(bt.logical_blocks) * self.block_size + self.block_size - 1)
            // self.block_size
        )
        # 簡單計算：目前 block 剩餘空間
        if bt.logical_blocks:
            last_used = bt.token_count % self.block_size
            remaining_in_last = self.block_size - last_used if last_used > 0 else 0
            overflow = max(0, token_count - remaining_in_last)
        else:
            overflow = token_count

        extra_blocks = max(0, (overflow + self.block_size - 1) // self.block_size)
        for _ in range(extra_blocks):
            bid = self._allocate_block()
            if bid is None:
                self._evict_lru()
                bid = self._allocate_block()
            if bid is not None:
                bt.logical_blocks.append(bid)
                self._blocks[bid].ref_count += 1
                self._stats.used_blocks     += 1
                self._stats.free_blocks     -= 1

        bt.token_count += token_count
        return bt

    def release_sequence(
        self,
        sequence_id: str,
        retain_prefix: bool = True,
    ) -> None:
        """
        釋放序列的 block。

        retain_prefix=True（預設）：
          prefix block 的 ref_count 降為 0 但保留在 prefix_cache 中，
          供下一輪相同 prefix 的序列複用——跨輪保留的核心機制。

        retain_prefix=False：
          強制釋放所有 block（記憶體壓力時使用）。
        """
        bt = self._block_tables.pop(sequence_id, None)
        if bt is None:
            return

        for bid in bt.logical_blocks:
            block = self._blocks.get(bid)
            if block is None:
                continue
            block.ref_count = max(0, block.ref_count - 1)

            # prefix block 且 retain_prefix：放回 prefix_cache，不釋放
            if retain_prefix and block.prefix_hash and block.ref_count == 0:
                # 已在 prefix_cache 中，不需處理
                continue

            if block.ref_count == 0:
                self._free_block(bid)

    def get_prefix_hit_blocks(
        self,
        prefix_tokens: list[int],
    ) -> list[int]:
        """
        查詢與給定 prefix_tokens 匹配的快取 block ids。
        回傳可直接複用的物理 block id 列表。
        """
        hits: list[int] = []
        for end in range(self.block_size, len(prefix_tokens) + 1, self.block_size):
            chunk  = prefix_tokens[:end]
            h      = _hash_tokens(chunk)
            if h in self._prefix_cache:
                bid = self._prefix_cache[h]
                self._prefix_cache.move_to_end(h)  # LRU update
                hits.append(bid)
            else:
                break   # prefix cache 是連續的，一旦 miss 就停止
        return hits

    def snapshot_block_table(self, sequence_id: str) -> list[int]:
        """回傳序列當前 block table 的快照（physical block id 列表）。"""
        bt = self._block_tables.get(sequence_id)
        return list(bt.logical_blocks) if bt else []

    def restore_block_table(
        self,
        sequence_id: str,
        block_ids:   list[int],
        token_count: int,
    ) -> BlockTable:
        """從快照恢復 block table（用於 KVSnapshot restore）。"""
        bt = BlockTable(
            sequence_id=sequence_id,
            logical_blocks=list(block_ids),
            token_count=token_count,
        )
        self._block_tables[sequence_id] = bt
        for bid in block_ids:
            if bid in self._blocks:
                self._blocks[bid].ref_count += 1
                self._blocks[bid].is_free    = False
        return bt

    # ── 統計 ─────────────────────────────────────────────────────────

    @property
    def stats(self) -> KVCacheStats:
        self._stats.prefix_cached_blocks = len(self._prefix_cache)
        return self._stats

    def utilization(self) -> float:
        return self._stats.utilization

    # ── 內部輔助 ─────────────────────────────────────────────────────

    def _allocate_block(self) -> int | None:
        if not self._free_ids:
            return None
        bid   = self._free_ids.pop(0)
        block = self._blocks[bid]
        block.is_free    = False
        block.ref_count  = 0
        block.prefix_hash = None
        # 模擬初始化 KV 資料（Phase 3：由推論引擎填充）
        block.data = np.zeros(
            (2, self.block_size, self.num_heads, self.head_dim),
            dtype=np.float16,
        )
        return bid

    def _free_block(self, bid: int) -> None:
        block = self._blocks.get(bid)
        if block is None or block.is_free:
            return
        block.is_free     = True
        block.ref_count   = 0
        block.prefix_hash = None
        block.data        = None
        self._free_ids.append(bid)
        self._stats.free_blocks += 1
        self._stats.used_blocks  = max(0, self._stats.used_blocks - 1)

    def _try_prefix_cache(
        self,
        bt:            BlockTable,
        prefix_tokens: list[int],
    ) -> int:
        """嘗試複用 prefix cache，回傳複用的 block 數量。"""
        reused = 0
        for end in range(self.block_size, len(prefix_tokens) + 1, self.block_size):
            chunk = prefix_tokens[:end]
            h     = _hash_tokens(chunk)
            if h in self._prefix_cache:
                bid = self._prefix_cache[h]
                self._prefix_cache.move_to_end(h)
                if bid not in bt.logical_blocks:
                    bt.logical_blocks.append(bid)
                    self._blocks[bid].ref_count += 1
                    self._blocks[bid].touch()
                reused += 1
                self._stats.prefix_cache_hits += 1
            else:
                self._stats.prefix_cache_misses += 1
                break
        return reused

    def _register_prefix(self, tokens: list[int], block_id: int) -> None:
        """將一個新完成 prefill 的 block 加入 prefix cache。"""
        h = _hash_tokens(tokens)
        if h in self._prefix_cache:
            return
        # LRU 驅逐 prefix cache
        if len(self._prefix_cache) >= self.prefix_cache_capacity:
            oldest_h, oldest_bid = next(iter(self._prefix_cache.items()))
            del self._prefix_cache[oldest_h]
            # 若沒有序列正在引用，才真正釋放
            old_block = self._blocks.get(oldest_bid)
            if old_block and old_block.ref_count == 0:
                self._free_block(oldest_bid)

        self._prefix_cache[h] = block_id
        self._blocks[block_id].prefix_hash = h

    def _evict_lru(self) -> int:
        """驅逐最久未使用的空閒 block（或 ref_count=0 的 prefix block）。"""
        # 先找 ref_count=0 且不在 prefix_cache 中的 block
        candidates = [
            b for b in self._blocks.values()
            if not b.is_free and b.ref_count == 0 and b.prefix_hash is None
        ]
        if not candidates:
            # 退而求其次：驅逐最舊的 prefix cache block
            candidates = [
                self._blocks[bid] for bid in self._prefix_cache.values()
                if self._blocks[bid].ref_count == 0
            ]
        if not candidates:
            return 0

        victim = min(candidates, key=lambda b: b.last_used)
        if victim.prefix_hash and victim.prefix_hash in self._prefix_cache:
            del self._prefix_cache[victim.prefix_hash]
        self._free_block(victim.block_id)
        self._stats.evictions += 1
        return 1


def _hash_tokens(tokens: list[int]) -> str:
    """計算 token 序列的確定性雜湊，用於 prefix cache 查找。"""
    return hashlib.sha256(
        b"".join(t.to_bytes(4, "little") for t in tokens)
    ).hexdigest()[:16]
