"""
aios.l1.global_scheduler
─────────────────────────
跨節點 Global Scheduler。

作為 Kubernetes Scheduler Plugin 的設計對應：
  架構上模仿 K8s scheduler extender 的 Filter → Score → Bind 三階段：

  Filter  — 過濾不可用的節點（無資源、KV-Cache 不存在、心跳超時）
  Score   — 對可用節點評分（KV-Cache 局部性、VRAM 餘量、負載）
  Bind    — 將任務綁定到最高分節點

排程策略：
  - KV-Cache 局部性優先：若已有 prefix cache，優先選該節點
  - 分離式架構感知：prefill 選運算節點，decode 選記憶體節點
  - VRAM headroom：避免將任務排程到即將 OOM 的節點
  - 負載平衡：分數包含 active_tasks 的倒數
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p2 import InferencePhase, InferenceTask, TaskPriority
from aios.core.models_p3 import (
    GlobalScheduleDecision,
    NodeInfo,
    NodeType,
    ScheduleType,
)


# ════════════════════════════════════════════════════════════════════
# 排程外掛介面（K8s Extender 風格）
# ════════════════════════════════════════════════════════════════════

@dataclass
class FilterResult:
    """Filter 階段的輸出：通過與被過濾的節點。"""
    passed:    list[NodeInfo]
    filtered:  dict[str, str]  # node_id → reason

    @property
    def all_passed(self) -> bool:
        return len(self.filtered) == 0


@dataclass
class ScoreResult:
    """Score 階段的輸出：每個節點的分數。"""
    scores: dict[str, float]  # node_id → score (0.0 ~ 100.0)


@dataclass
class SchedulerPlugin:
    """
    K8s Scheduler Plugin 模擬介面。

    對應 K8s scheduler framework 的擴充點：
      - Filter  : 實現 FilterPlugin
      - Score   : 實現 ScorePlugin（含 NormalizeScore）
      - Bind    : 實現 BindPlugin
      - PreBind : 實現 ReservePlugin（預留資源）
    """

    def filter(
        self,
        nodes:        list[NodeInfo],
        task:         InferenceTask,
        schedule_type: ScheduleType,
    ) -> FilterResult:
        """過濾不適合此任務的節點。"""
        raise NotImplementedError

    def score(
        self,
        nodes:        list[NodeInfo],
        task:         InferenceTask,
        schedule_type: ScheduleType,
    ) -> ScoreResult:
        """對通過 filter 的節點評分。"""
        raise NotImplementedError

    def bind(
        self,
        decision: GlobalScheduleDecision,
    ) -> bool:
        """將任務綁定到選定節點。"""
        raise NotImplementedError


# ════════════════════════════════════════════════════════════════════
# KV-Cache 感知排程器
# ════════════════════════════════════════════════════════════════════

class KVAwareScheduler(SchedulerPlugin):
    """
    KV-Cache 感知排程外掛。

    Filter 階段：
      - 節點必須是對應 schedule_type 的有效角色
      - 節點必須健康（heartbeat 未超時）
      - VRAM 餘量必須足夠

    Score 階段：
      - KV-Cache 局部性：若節點已有任務的 prefix cache +40 分
      - VRAM 餘量：餘量越多 +30 分
      - 負載：active_tasks 越少 +20 分
      - KV block 可用數：越多 +10 分
    """

    def __init__(
        self,
        node_registry: Any,  # NodeRegistry
        prefix_cache_map: dict[str, set[str]] | None = None,
        # prefix_hash → set[node_id] 的映射（由 KVRouter 維護）
    ):
        self._node_registry   = node_registry
        self._prefix_cache_map = prefix_cache_map or {}

        self._decisions: list[GlobalScheduleDecision] = []
        self._stats = GlobalSchedulerStats()

    def filter(
        self,
        nodes:        list[NodeInfo],
        task:         InferenceTask,
        schedule_type: ScheduleType,
    ) -> FilterResult:
        passed: list[NodeInfo] = []
        filtered: dict[str, str] = {}

        for node in nodes:
            reason = self._check_node(node, task, schedule_type)
            if reason:
                filtered[node.node_id] = reason
            else:
                passed.append(node)

        return FilterResult(passed=passed, filtered=filtered)

    def score(
        self,
        nodes:        list[NodeInfo],
        task:         InferenceTask,
        schedule_type: ScheduleType,
    ) -> ScoreResult:
        scores: dict[str, float] = {}

        for node in nodes:
            s = 0.0

            # KV-Cache 局部性（+0~40 分）
            s += self._score_kv_locality(node, task) * 40.0

            # VRAM 餘量（+0~30 分）
            s += self._score_vram_headroom(node) * 30.0

            # 負載（+0~20 分）
            s += self._score_load(node) * 20.0

            # KV block 可用數（+0~10 分）
            s += self._score_kv_blocks(node) * 10.0

            # schedule_type 匹配（bonus +10）
            s += self._score_type_match(node, schedule_type) * 10.0

            scores[node.node_id] = round(s, 2)

        return ScoreResult(scores=scores)

    def bind(
        self,
        decision: GlobalScheduleDecision,
    ) -> bool:
        self._decisions.append(decision)
        self._stats.record(decision)
        return True

    def _check_node(
        self,
        node:          NodeInfo,
        task:          InferenceTask,
        schedule_type: ScheduleType,
    ) -> str | None:
        """檢查節點是否可用。回傳 None 表示通過。"""
        # 健康檢查
        now = datetime.now(timezone.utc)
        if (now - node.last_heartbeat).total_seconds() > 30.0:
            return "heartbeat timeout"

        # 角色匹配
        if schedule_type == ScheduleType.PREFILL:
            if node.node_type not in (NodeType.PREFILL_ONLY, NodeType.HYBRID):
                return "not a prefill node"
        elif schedule_type == ScheduleType.DECODE:
            if node.node_type not in (NodeType.DECODE_ONLY, NodeType.HYBRID):
                return "not a decode node"

        # VRAM 餘量（保留 20% headroom）
        vram_free = node.vram_mb - node.vram_used_mb
        if vram_free < node.vram_mb * 0.2:
            return "insufficient VRAM headroom"

        # KV block 可用數（至少 4 blocks）
        kv_free = node.kv_blocks_available
        if kv_free < 4:
            return "insufficient KV blocks"

        return None

    def _score_kv_locality(self, node: NodeInfo, task: InferenceTask) -> float:
        """若節點已有此任務的 KV-Cache prefix，給高分。"""
        for prefix_set in self._prefix_cache_map.values():
            if node.node_id in prefix_set:
                return 1.0
        return 0.0

    def _score_vram_headroom(self, node: NodeInfo) -> float:
        """VRAM 餘量越多越好。"""
        free = node.vram_mb - node.vram_used_mb
        ratio = free / max(1, node.vram_mb)
        return min(1.0, ratio * 2.0)  # 使用 50% 時即滿分

    def _score_load(self, node: NodeInfo) -> float:
        """負載越輕越好。"""
        return max(0.0, 1.0 - node.load_score)

    def _score_kv_blocks(self, node: NodeInfo) -> float:
        """KV block 可用比例越高越好。"""
        total = node.kv_blocks_available + node.kv_blocks_used
        return node.kv_blocks_available / max(1, total)

    def _score_type_match(
        self,
        node:          NodeInfo,
        schedule_type: ScheduleType,
    ) -> float:
        """專用節點比 hybrid 節點更適合其角色。"""
        if schedule_type == ScheduleType.PREFILL:
            return 1.0 if node.node_type == NodeType.PREFILL_ONLY else 0.5
        elif schedule_type == ScheduleType.DECODE:
            return 1.0 if node.node_type == NodeType.DECODE_ONLY else 0.5
        return 0.5

    @property
    def decisions(self) -> list[GlobalScheduleDecision]:
        return list(self._decisions)

    @property
    def stats(self) -> GlobalSchedulerStats:
        return self._stats


# ════════════════════════════════════════════════════════════════════
# Global Scheduler（組合 Filter + Score + Bind）
# ════════════════════════════════════════════════════════════════════

class GlobalScheduler:
    """
    跨節點全域排程器。

    組合多個 SchedulerPlugin（可疊加），執行完整的排程週期：
      Filter → Score → Normalize → Bind

    使用方式：
      scheduler = GlobalScheduler(node_registry)
      decision = scheduler.schedule(task, ScheduleType.PREFILL)
    """

    def __init__(
        self,
        node_registry: Any,   # NodeRegistry
        plugins:       list[SchedulerPlugin] | None = None,
    ):
        self._registry = node_registry
        self._plugins  = plugins or [KVAwareScheduler(node_registry)]

        self._decisions: list[GlobalScheduleDecision] = []
        self._stats = GlobalSchedulerStats()

    def add_plugin(self, plugin: SchedulerPlugin) -> None:
        self._plugins.append(plugin)

    def schedule(
        self,
        task:          InferenceTask,
        schedule_type: ScheduleType = ScheduleType.PREFILL,
    ) -> GlobalScheduleDecision:
        """
        執行一次完整的跨節點排程。

        Returns:
          若無可用節點，回傳 decision 的 node_id="" 且 score=0。
        """
        nodes = self._registry.healthy_nodes()
        if not nodes:
            decision = GlobalScheduleDecision(
                task_id=task.task_id,
                instance_id=task.instance_id or "",
                node_id="",
                schedule_type=schedule_type,
                reason="no healthy nodes available",
                score=0.0,
            )
            self._decisions.append(decision)
            return decision

        # 1. Filter：所有 plugin 的 filter 都必須通過
        passed_nodes = nodes
        for plugin in self._plugins:
            result = plugin.filter(passed_nodes, task, schedule_type)
            passed_nodes = result.passed
            if not passed_nodes:
                break

        if not passed_nodes:
            decision = GlobalScheduleDecision(
                task_id=task.task_id,
                instance_id=task.instance_id or "",
                node_id="",
                schedule_type=schedule_type,
                reason="all nodes filtered out",
                score=0.0,
            )
            self._decisions.append(decision)
            return decision

        # 2. Score：彙總所有 plugin 的分數
        aggregated: dict[str, float] = {}
        for plugin in self._plugins:
            result = plugin.score(passed_nodes, task, schedule_type)
            for nid, score in result.scores.items():
                aggregated[nid] = aggregated.get(nid, 0.0) + score

        # 3. 選擇最高分節點
        best_node_id = max(aggregated, key=aggregated.get)
        best_score   = aggregated[best_node_id]

        reason_parts: list[str] = []
        for nid, score in sorted(aggregated.items(), key=lambda x: -x[1]):
            reason_parts.append(f"{nid}={score:.1f}")
        reason = "scores: " + ", ".join(reason_parts)

        decision = GlobalScheduleDecision(
            task_id=task.task_id,
            instance_id=task.instance_id or "",
            node_id=best_node_id,
            schedule_type=schedule_type,
            reason=reason,
            score=best_score,
        )

        # 4. Bind：通知所有 plugin
        for plugin in self._plugins:
            plugin.bind(decision)

        self._decisions.append(decision)
        self._stats.record(decision)
        return decision

    @property
    def stats(self) -> GlobalSchedulerStats:
        return self._stats


@dataclass
class GlobalSchedulerStats:
    total_decisions:  int = 0
    prefill_assignments: int = 0
    decode_assignments: int = 0
    resume_assignments: int = 0
    avg_score:        float = 0.0

    def record(self, decision: GlobalScheduleDecision) -> None:
        self.total_decisions += 1
        if decision.schedule_type == ScheduleType.PREFILL:
            self.prefill_assignments += 1
        elif decision.schedule_type == ScheduleType.DECODE:
            self.decode_assignments += 1
        elif decision.schedule_type == ScheduleType.RESUME:
            self.resume_assignments += 1
        self.avg_score = _running_avg(self.avg_score, decision.score, self.total_decisions)


def _running_avg(current: float, new_val: float, n: int) -> float:
    if n <= 1:
        return float(new_val)
    return current + (new_val - current) / n
