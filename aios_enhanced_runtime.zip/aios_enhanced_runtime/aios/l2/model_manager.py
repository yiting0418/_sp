"""
aios.l2.model_manager
──────────────────────
模型常駐管理器。

核心原則：
  模型不是每次請求才載入的批次程式，而是「常駐服務」。
  L2 決定哪些模型值得常駐於 VRAM，哪些在 DRAM 等待熱載入，
  哪些應卸載至 NVMe。

LoRA 熱切換：
  同一基礎模型可搭配不同 LoRA 適配器。
  基礎模型權重只載入一次；切換適配器只需載入差量（< 1% 體積）。

Phase 2 實作說明：
  模型權重以 dict stub 模擬，不使用真實 GPU。
  所有計時（載入延遲）以 size_mb 估算的 sleep 模擬。
  Phase 3 替換為 safetensors mmap + CUDA 直接載入。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p2 import LoRAEntry, ModelEntry, ModelTier


# ════════════════════════════════════════════════════════════════════
# 常駐決策
# ════════════════════════════════════════════════════════════════════

@dataclass
class ResidencyDecision:
    model_id:  str
    action:    str          # "promote" | "demote" | "keep" | "evict"
    from_tier: ModelTier
    to_tier:   ModelTier | None
    reason:    str


@dataclass
class ModelManagerStats:
    total_models:     int   = 0
    vram_models:      int   = 0
    dram_models:      int   = 0
    nvme_models:      int   = 0
    total_adapters:   int   = 0
    hot_swaps:        int   = 0
    promotions:       int   = 0
    demotions:        int   = 0
    cache_hits:       int   = 0   # 請求時模型已在 VRAM
    cache_misses:     int   = 0   # 請求時需要載入


# ════════════════════════════════════════════════════════════════════
# Model Manager
# ════════════════════════════════════════════════════════════════════

class ModelManager:
    """
    L2 模型常駐管理器。

    職責：
      1. 模型的三層常駐（VRAM / DRAM / NVMe）
      2. 依存取頻率自動晉升 / 降級
      3. LoRA 適配器的熱切換（只載入差量）
      4. VRAM 壓力時選擇最佳的驅逐候選
    """

    # 存取次數門檻
    PROMOTE_THRESHOLD = 3    # 達到此次數 → 晉升至更快的層
    DEMOTE_THRESHOLD  = 1    # 低於此次數（在一次 tiering pass 中）→ 降級

    def __init__(
        self,
        vram_capacity_mb: float = 16_000.0,   # 模擬 16 GB VRAM
        dram_capacity_mb: float = 64_000.0,   # 模擬 64 GB DRAM
    ):
        self._vram_cap    = vram_capacity_mb
        self._dram_cap    = dram_capacity_mb
        self._vram_used   = 0.0
        self._dram_used   = 0.0
        self._models:     dict[str, ModelEntry] = {}
        self._stats       = ModelManagerStats()

    # ── 模型注冊 ─────────────────────────────────────────────────────

    def register(
        self,
        model_id:   str,
        size_mb:    float,
        tier:       ModelTier = ModelTier.NVME,
        stub_weights: dict[str, Any] | None = None,
    ) -> ModelEntry:
        """注冊一個新模型。預設從 NVMe 開始（冷）。"""
        if model_id in self._models:
            return self._models[model_id]

        entry = ModelEntry(
            model_id=model_id,
            size_mb=size_mb,
            tier=tier,
            weights=stub_weights or {"_stub": True, "model_id": model_id},
        )
        self._models[model_id] = entry
        self._stats.total_models += 1
        self._update_tier_counts()
        return entry

    def register_lora(
        self,
        base_model_id: str,
        adapter_id:    str,
        task_type:     str,
        delta_size_mb: float = 0.0,
        stub_delta:    dict[str, Any] | None = None,
    ) -> LoRAEntry | None:
        """注冊一個 LoRA 適配器到指定的基礎模型。"""
        base = self._models.get(base_model_id)
        if base is None:
            return None

        adapter = LoRAEntry(
            adapter_id=adapter_id,
            base_model_id=base_model_id,
            task_type=task_type,
            delta_size_mb=delta_size_mb,
            delta=stub_delta or {"_stub": True, "adapter_id": adapter_id},
        )
        base.adapters[adapter_id] = adapter
        self._stats.total_adapters += 1
        return adapter

    # ── 模型取得（含自動載入）────────────────────────────────────────

    def get_model(
        self,
        model_id:   str,
        adapter_id: str | None = None,
    ) -> tuple[ModelEntry, float]:
        """
        取得模型（必要時載入）。
        回傳 (ModelEntry, load_latency_ms)。

        若模型已在 VRAM → cache hit，延遲 = 0。
        否則 → cache miss，執行載入流程。
        """
        entry = self._models.get(model_id)
        if entry is None:
            raise KeyError(f"未知的模型: {model_id}")

        entry.touch()

        if entry.tier == ModelTier.VRAM:
            self._stats.cache_hits += 1
            latency = 0.0
        else:
            self._stats.cache_misses += 1
            latency = self._load_to_vram(entry)

        # LoRA 適配器切換
        if adapter_id and adapter_id != entry.active_adapter:
            self._hot_swap_adapter(entry, adapter_id)

        return entry, latency

    def ensure_loaded(self, model_id: str) -> ModelEntry:
        """確保模型在 VRAM 中（預熱用）。"""
        entry, _ = self.get_model(model_id)
        return entry

    # ── 分層管理 ─────────────────────────────────────────────────────

    def run_tiering_pass(self) -> list[ResidencyDecision]:
        """
        執行一次常駐決策（通常由後台排程器定期觸發）。
        高頻存取模型晉升；低頻模型降級。
        """
        decisions: list[ResidencyDecision] = []

        for entry in list(self._models.values()):
            if entry.access_count >= self.PROMOTE_THRESHOLD:
                d = self._promote(entry)
            elif entry.access_count < self.DEMOTE_THRESHOLD:
                d = self._demote(entry)
            else:
                d = ResidencyDecision(
                    model_id=entry.model_id,
                    action="keep",
                    from_tier=entry.tier,
                    to_tier=None,
                    reason=f"access_count={entry.access_count}，保持 {entry.tier.value}",
                )
            decisions.append(d)
            # 重置本輪計數
            entry.access_count = 0

        self._update_tier_counts()
        return decisions

    def evict_model(self, model_id: str, target_tier: ModelTier = ModelTier.NVME) -> bool:
        """強制驅逐模型至指定層（VRAM 壓力時由排程器呼叫）。"""
        entry = self._models.get(model_id)
        if entry is None or entry.tier == target_tier:
            return False
        self._release_tier_memory(entry)
        entry.tier = target_tier
        self._update_tier_counts()
        self._stats.demotions += 1
        return True

    def select_eviction_candidate(self) -> str | None:
        """
        選擇最佳的 VRAM 驅逐候選：
        LRU（最久未使用）+ 最低優先序（access_count 最少）。
        """
        vram_models = [e for e in self._models.values() if e.tier == ModelTier.VRAM]
        if not vram_models:
            return None
        victim = min(vram_models, key=lambda e: (e.access_count, e.last_used))
        return victim.model_id

    # ── 統計 ─────────────────────────────────────────────────────────

    @property
    def stats(self) -> ModelManagerStats:
        self._update_tier_counts()
        return self._stats

    def vram_usage(self) -> tuple[float, float]:
        """回傳 (已用 MB, 總容量 MB)。"""
        return self._vram_used, self._vram_cap

    def memory_report(self) -> dict[str, Any]:
        return {
            "vram_used_mb":  round(self._vram_used, 1),
            "vram_cap_mb":   self._vram_cap,
            "vram_util":     round(self._vram_used / self._vram_cap, 3),
            "dram_used_mb":  round(self._dram_used, 1),
            "dram_cap_mb":   self._dram_cap,
            "models":        {
                mid: {"tier": e.tier.value, "size_mb": e.size_mb,
                      "adapter": e.active_adapter}
                for mid, e in self._models.items()
            },
        }

    # ── 內部輔助 ─────────────────────────────────────────────────────

    def _load_to_vram(self, entry: ModelEntry) -> float:
        """模擬從 DRAM/NVMe 載入至 VRAM。回傳估算延遲（ms）。"""
        latency = entry.load_latency_ms

        # 若 VRAM 不足，先驅逐其他模型
        while self._vram_used + entry.size_mb > self._vram_cap:
            victim_id = self.select_eviction_candidate()
            if victim_id is None or victim_id == entry.model_id:
                break
            self.evict_model(victim_id, ModelTier.DRAM)

        self._release_tier_memory(entry)
        entry.tier    = ModelTier.VRAM
        self._vram_used += entry.size_mb
        self._stats.promotions += 1
        return latency

    def _release_tier_memory(self, entry: ModelEntry) -> None:
        """釋放模型當前佔用的層記憶體。"""
        if entry.tier == ModelTier.VRAM:
            self._vram_used = max(0.0, self._vram_used - entry.size_mb)
        elif entry.tier == ModelTier.DRAM:
            self._dram_used = max(0.0, self._dram_used - entry.size_mb)

    def _hot_swap_adapter(self, entry: ModelEntry, adapter_id: str) -> float:
        """
        熱切換 LoRA 適配器。
        基礎模型權重不動，只替換差量。
        延遲 ∝ delta_size_mb（遠小於基礎模型）。
        """
        adapter = entry.adapters.get(adapter_id)
        if adapter is None:
            return 0.0

        # 卸載舊適配器
        if entry.active_adapter:
            old = entry.adapters.get(entry.active_adapter)
            if old:
                old.loaded = False

        # 載入新適配器（只有 delta，極快）
        adapter.loaded         = True
        adapter.touch()
        entry.active_adapter   = adapter_id
        self._stats.hot_swaps += 1

        # 估算切換延遲：delta 通常 < 100MB，很快
        swap_latency_ms = adapter.delta_size_mb * 0.1
        return swap_latency_ms

    def _promote(self, entry: ModelEntry) -> ResidencyDecision:
        from_tier = entry.tier
        if entry.tier == ModelTier.NVME:
            entry.tier = ModelTier.DRAM
            self._dram_used += entry.size_mb
            self._stats.promotions += 1
            action, to_tier = "promote", ModelTier.DRAM
        elif entry.tier == ModelTier.DRAM:
            self._load_to_vram(entry)
            action, to_tier = "promote", ModelTier.VRAM
        else:
            action, to_tier = "keep", None
        return ResidencyDecision(
            model_id=entry.model_id, action=action,
            from_tier=from_tier, to_tier=to_tier,
            reason=f"access_count={entry.access_count} >= {self.PROMOTE_THRESHOLD}",
        )

    def _demote(self, entry: ModelEntry) -> ResidencyDecision:
        from_tier = entry.tier
        if entry.tier == ModelTier.VRAM:
            self._release_tier_memory(entry)
            entry.tier    = ModelTier.DRAM
            self._dram_used += entry.size_mb
            self._stats.demotions += 1
            action, to_tier = "demote", ModelTier.DRAM
        elif entry.tier == ModelTier.DRAM:
            self._release_tier_memory(entry)
            entry.tier  = ModelTier.NVME
            self._stats.demotions += 1
            action, to_tier = "demote", ModelTier.NVME
        else:
            action, to_tier = "keep", None
        return ResidencyDecision(
            model_id=entry.model_id, action=action,
            from_tier=from_tier, to_tier=to_tier,
            reason=f"access_count={entry.access_count} < {self.DEMOTE_THRESHOLD}",
        )

    def _update_tier_counts(self) -> None:
        self._stats.vram_models = sum(1 for e in self._models.values() if e.tier == ModelTier.VRAM)
        self._stats.dram_models = sum(1 for e in self._models.values() if e.tier == ModelTier.DRAM)
        self._stats.nvme_models = sum(1 for e in self._models.values() if e.tier == ModelTier.NVME)
