"""
aios.l2.snapshot
─────────────────
KV-Cache 快照管理器。

設計決策（來自設計文件）：
  只在自然邊界（工具呼叫宣告完成、句子邊界）建立快照。
  不在 decode 迴圈中途強制中斷。

  原因：decode 迴圈設計為連續執行；中途打斷會產生不一致的
  KV-Cache 狀態，序列化不可靠。

  在自然邊界時，KV-Cache 狀態完整且一致，可安全序列化至 DRAM。

快照用途：
  1. 長時間等待（等待工具結果、人類審核）→ 釋放 VRAM，後續恢復
  2. 跨節點遷移（Phase 3 RDMA 傳輸）→ 本模組只負責序列化
  3. 故障恢復 → 從最近快照重建任務狀態
"""

from __future__ import annotations

import pickle
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import numpy as np

from aios.core.models_p2 import InferencePhase, InferenceTask, KVSnapshot
from aios.l1.kvcache import KVCacheManager


# ════════════════════════════════════════════════════════════════════
# 快照統計
# ════════════════════════════════════════════════════════════════════

@dataclass
class SnapshotStats:
    total_snapshots:   int   = 0
    total_restores:    int   = 0
    total_bytes:       int   = 0
    invalid_attempts:  int   = 0   # 嘗試在非自然邊界建立快照的次數
    avg_snapshot_ms:   float = 0.0
    avg_restore_ms:    float = 0.0


# ════════════════════════════════════════════════════════════════════
# Snapshot Manager
# ════════════════════════════════════════════════════════════════════

class SnapshotManager:
    """
    KV-Cache 快照的建立、儲存、恢復。

    儲存後端（Phase 2）：in-process dict（模擬 DRAM）。
    Phase 3 替換為：RDMA 可傳輸的 pinned memory buffer。
    """

    def __init__(self, kvcache: KVCacheManager):
        self._kvcache  = kvcache
        self._store:   dict[str, KVSnapshot] = {}     # snapshot_id → KVSnapshot
        self._index:   dict[str, list[str]]  = {}     # instance_id → [snapshot_id]
        self._stats    = SnapshotStats()

    # ── 建立快照 ─────────────────────────────────────────────────────

    def create(
        self,
        task:             InferenceTask,
        is_natural_boundary: bool,
    ) -> KVSnapshot | None:
        """
        在自然邊界建立快照。

        is_natural_boundary=False 時拒絕建立，並記錄為無效嘗試。
        這是「只在自然邊界暫停」原則的強制執行點。
        """
        if not is_natural_boundary:
            self._stats.invalid_attempts += 1
            return None   # 拒絕在非自然邊界序列化

        import time
        t0 = time.perf_counter()

        # 取得當前 block table
        block_ids = self._kvcache.snapshot_block_table(
            task.block_table.sequence_id if task.block_table else task.task_id
        )

        # Phase 2：將 KV 資料序列化為 bytes（模擬 DRAM 存儲）
        payload = self._serialize_blocks(block_ids)

        snap = KVSnapshot(
            instance_id=task.instance_id,
            task_id=task.task_id,
            token_count=task.prompt_tokens + task.generated_tokens,
            block_table=block_ids,
            payload=payload,
            payload_bytes=len(payload),
            natural_boundary=True,
        )

        self._store[snap.snapshot_id] = snap
        self._index.setdefault(task.instance_id, []).append(snap.snapshot_id)

        elapsed_ms = (time.perf_counter() - t0) * 1000
        self._stats.total_snapshots += 1
        self._stats.total_bytes     += len(payload)
        self._stats.avg_snapshot_ms  = _running_avg(
            self._stats.avg_snapshot_ms, elapsed_ms, self._stats.total_snapshots
        )

        # 快照後釋放 VRAM（保留 prefix）
        if task.block_table:
            self._kvcache.release_sequence(
                task.block_table.sequence_id,
                retain_prefix=True,
            )

        return snap

    # ── 恢復快照 ─────────────────────────────────────────────────────

    def restore(
        self,
        snapshot_id: str,
        task:        InferenceTask,
    ) -> bool:
        """
        從快照恢復任務的 KV-Cache 狀態。
        成功後任務可直接從暫停點繼續 decode，無需重新 prefill。
        """
        snap = self._store.get(snapshot_id)
        if snap is None:
            return False

        import time
        t0 = time.perf_counter()

        # 還原 block table
        seq_id = task.block_table.sequence_id if task.block_table else task.task_id
        self._kvcache.restore_block_table(
            sequence_id=seq_id,
            block_ids=snap.block_table,
            token_count=snap.token_count,
        )

        # 還原 KV 資料
        self._deserialize_blocks(snap.block_table, snap.payload)

        task.phase             = InferencePhase.DECODE
        task.generated_tokens  = snap.token_count - task.prompt_tokens

        elapsed_ms = (time.perf_counter() - t0) * 1000
        self._stats.total_restores  += 1
        self._stats.avg_restore_ms   = _running_avg(
            self._stats.avg_restore_ms, elapsed_ms, self._stats.total_restores
        )
        return True

    def get_latest(self, instance_id: str) -> KVSnapshot | None:
        """取得指定 instance 的最新快照。"""
        snap_ids = self._index.get(instance_id, [])
        if not snap_ids:
            return None
        latest_id = snap_ids[-1]
        return self._store.get(latest_id)

    def list_snapshots(self, instance_id: str) -> list[KVSnapshot]:
        snap_ids = self._index.get(instance_id, [])
        return [self._store[sid] for sid in snap_ids if sid in self._store]

    def delete(self, snapshot_id: str) -> bool:
        snap = self._store.pop(snapshot_id, None)
        if snap is None:
            return False
        ids = self._index.get(snap.instance_id, [])
        if snapshot_id in ids:
            ids.remove(snapshot_id)
        return True

    @property
    def stats(self) -> SnapshotStats:
        return self._stats

    # ── 序列化輔助（Phase 2：numpy → bytes）─────────────────────────

    def _serialize_blocks(self, block_ids: list[int]) -> bytes:
        """將 block 的 numpy KV 資料序列化為 bytes。"""
        payload: dict[int, Any] = {}
        for bid in block_ids:
            block = self._kvcache._blocks.get(bid)
            if block and block.data is not None:
                payload[bid] = block.data.tobytes()
            else:
                payload[bid] = None
        return pickle.dumps(payload)

    def _deserialize_blocks(self, block_ids: list[int], payload: bytes) -> None:
        """將 bytes 反序列化回 block 的 numpy KV 資料。"""
        if not payload:
            return
        try:
            data_map: dict[int, Any] = pickle.loads(payload)  # noqa: S301
        except Exception:
            return

        for bid in block_ids:
            block = self._kvcache._blocks.get(bid)
            if block and bid in data_map and data_map[bid] is not None:
                block.data = np.frombuffer(
                    data_map[bid], dtype=np.float16
                ).reshape(
                    2,
                    self._kvcache.block_size,
                    self._kvcache.num_heads,
                    self._kvcache.head_dim,
                ).copy()
                block.is_free   = False
                block.ref_count = max(block.ref_count, 1)


def _running_avg(current: float, new_val: float, n: int) -> float:
    if n <= 1:
        return float(new_val)
    return current + (new_val - current) / n
