"""
aios.tools
───────────
工具子系統：registry + 沙箱執行 + 路由器。

  ToolRegistry  — 工具的 central registry
  ToolSandbox   — 隔離執行，結果過濾後才注入代理上下文
  ToolRouter    — 統一入口：驗證 → 沙箱執行 → 回傳 ToolResult
"""

from __future__ import annotations

import io
import sys
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable

from aios.core.models import Capability, ToolResult, ToolSpec


# ════════════════════════════════════════════════════════════════════
# 內建工具 handlers
# ════════════════════════════════════════════════════════════════════

def _handle_web_fetch(url: str, **_: Any) -> dict:
    """使用 urllib 取得指定 URL 的網頁內容（自動跟隨重新導向，HTML 轉純文字）。"""
    import re as _re, urllib.request, urllib.error, urllib.parse

    # 將 URL 中的非 ASCII 字元做 percent-encoding（避免 ASCII 編碼錯誤）
    def _encode_url(u: str) -> str:
        parsed = urllib.parse.urlsplit(u)
        encoded_path = urllib.parse.quote(parsed.path, safe="/@!$&'()*+,;=-._~:")
        encoded_query = urllib.parse.quote(parsed.query, safe="=/@!$&'()*+,;=-._~:%")
        encoded_fragment = urllib.parse.quote(parsed.fragment, safe="=/@!$&'()*+,;=-._~:%")
        return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, encoded_path, encoded_query, encoded_fragment))

    url = _encode_url(url)
    # DuckDuckGo 搜尋結果頁面 → 改用結構化解析
    if "html.duckduckgo.com/html" in url:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("q", [""])[0]
        results = _search_duckduckgo(q, 10)
        return {"url": url, "query": q, "results": results, "total": len(results)}
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "AIOS/1.0 (research agent; +https://aios.org)",
                "Accept": "text/html,application/json,*/*",
                "Accept-Language": "zh-TW,zh-HK;q=0.9,zh;q=0.8,en;q=0.7",
            },
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read()
            try:
                text = content.decode("utf-8")
            except UnicodeDecodeError:
                text = content.decode("utf-8", errors="replace")
        ctype = resp.headers.get_content_type() or ""
        if "html" in ctype:
            text = _re.sub(r"<script[^>]*>.*?</script>", "", text, flags=_re.DOTALL)
            text = _re.sub(r"<style[^>]*>.*?</style>", "", text, flags=_re.DOTALL)
            text = _re.sub(r"<[^>]+>", "", text)
            text = _re.sub(r"\n\s*\n", "\n", text)
            text = text.strip()
        return {
            "url":      url,
            "content":  text[:50_000],
            "status":   resp.status,
            "encoding": resp.headers.get_content_charset() or "utf-8",
        }
    except urllib.error.HTTPError as e:
        return {"url": url, "error": f"HTTP {e.code}: {e.reason}"}
    except urllib.error.URLError as e:
        return {"url": url, "error": f"連線失敗: {e.reason}"}
    except Exception as e:
        return {"url": url, "error": str(e)}


def _handle_web_search(query: str, top_k: int = 5, **_: Any) -> dict:
    """搜尋網路內容。先嘗試 Wikipedia API，若無結果則改用 DuckDuckGo HTML 搜尋。"""
    import json, urllib.request, urllib.parse, urllib.error
    results = _search_wikipedia(query, top_k)
    if results:
        return {"query": query, "source": "wikipedia", "results": results, "total": len(results)}
    results = _search_duckduckgo(query, top_k)
    return {"query": query, "source": "duckduckgo" if results else "none",
            "results": results, "total": len(results)}


def _search_wikipedia(query: str, top_k: int) -> list[dict]:
    import json, urllib.request, urllib.parse, urllib.error
    params = urllib.parse.urlencode({
        "action": "query",
        "list": "search",
        "format": "json",
        "srlimit": min(top_k, 20),
        "srsearch": query,
    })
    url = f"https://en.wikipedia.org/w/api.php?{params}"
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "AIOS/1.0 (research; +https://aios.org)"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        results = []
        for item in data.get("query", {}).get("search", []):
            results.append({
                "title":   item["title"],
                "snippet": item.get("snippet", "").replace("<span class=\"searchmatch\">", "").replace("</span>", ""),
                "url":     f"https://en.wikipedia.org/wiki/{urllib.parse.quote(item['title'].replace(' ', '_'))}",
            })
        return results
    except Exception:
        return []


def _search_duckduckgo(query: str, top_k: int) -> list[dict]:
    """使用 DuckDuckGo HTML 搜尋作為備援。"""
    import html as html_mod, urllib.request, urllib.parse, urllib.error, re
    try:
        data = urllib.parse.urlencode({"q": query}).encode()
        req = urllib.request.Request(
            "https://html.duckduckgo.com/html/",
            data=data,
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; AIOS/1.0; +https://aios.org)",
            },
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        results = []
        for block in re.finditer(r'<a rel="nofollow" class="result__a" href="(.*?)".*?>(.*?)</a>.*?<a class="result__snippet"[^>]*>(.*?)</a>', raw, re.DOTALL):
            url = html_mod.unescape(block.group(1))
            title = re.sub(r"<.*?>", "", block.group(2))
            snippet = re.sub(r"<.*?>", "", block.group(3))
            results.append({"title": title.strip(), "snippet": snippet.strip(), "url": url})
            if len(results) >= top_k:
                break
        if not results:
            for block in re.finditer(r'<a rel="nofollow" class="result__url"[^>]*href="(.*?)".*?>(.*?)</a>', raw, re.DOTALL):
                url = html_mod.unescape(block.group(1))
                title_match = re.search(r'class="result__title"[^>]*>.*?<a[^>]*>(.*?)</a>', raw[block.start():], re.DOTALL)
                snippet_match = re.search(r'class="result__snippet"[^>]*>(.*?)</', raw[block.start():], re.DOTALL)
                title = re.sub(r"<.*?>", "", title_match.group(1) if title_match else "")
                snippet = re.sub(r"<.*?>", "", snippet_match.group(1) if snippet_match else "")
                results.append({"title": title.strip(), "snippet": snippet.strip(), "url": url})
                if len(results) >= top_k:
                    break
        return results
    except Exception:
        return []


def _handle_code_exec(code: str, **_: Any) -> dict:
    """
    極度受限的 Python 沙箱。
    Phase 1：禁止 import、禁止存取檔案系統、stdout 重導向。
    Phase 2：替換為 seccomp / nsjail 真實沙箱。
    """
    if "import" in code:
        return {"error": "Phase 1 沙箱：禁止 import 語句"}
    if "__" in code:
        return {"error": "Phase 1 沙箱：禁止 dunder 存取"}

    # 只開放安全的內建函式；print 重導向至 StringIO
    _SAFE_BUILTINS = {
        "print": print, "len": len, "range": range, "enumerate": enumerate,
        "zip": zip, "map": map, "filter": filter, "sorted": sorted,
        "reversed": reversed, "sum": sum, "min": min, "max": max,
        "abs": abs, "round": round, "int": int, "float": float,
        "str": str, "bool": bool, "list": list, "dict": dict,
        "tuple": tuple, "set": set, "type": type, "repr": repr,
        "isinstance": isinstance, "hasattr": hasattr,
    }

    buf = io.StringIO()
    old_stdout, sys.stdout = sys.stdout, buf
    local_vars: dict[str, Any] = {}
    try:
        exec(  # noqa: S102
            compile(code, "<aios_sandbox>", "exec"),
            {"__builtins__": _SAFE_BUILTINS},
            local_vars,
        )
        output = buf.getvalue()
    except Exception as exc:
        return {"error": str(exc)}
    finally:
        sys.stdout = old_stdout

    return {
        "output": output,
        "locals": {k: repr(v) for k, v in local_vars.items()},
    }


_WORKSPACE = "/tmp/aios_workspace"

def _handle_file_read(path: str, **_: Any) -> dict:
    import os
    os.makedirs(_WORKSPACE, exist_ok=True)
    real = os.path.realpath(path)
    if not real.startswith(os.path.realpath(_WORKSPACE)):
        return {"error": f"存取拒絕：路徑必須在 {_WORKSPACE} 下"}
    try:
        with open(real) as f:
            return {"content": f.read()}
    except FileNotFoundError:
        return {"error": f"找不到檔案: {real}"}


def _handle_file_write(path: str, content: str, **_: Any) -> dict:
    import os
    os.makedirs(_WORKSPACE, exist_ok=True)
    real = os.path.realpath(path)
    if not real.startswith(os.path.realpath(_WORKSPACE)):
        return {"error": f"存取拒絕：路徑必須在 {_WORKSPACE} 下"}
    with open(real, "w") as f:
        f.write(content)
    return {"written_bytes": len(content), "path": real}


# ════════════════════════════════════════════════════════════════════
# Tool Registry
# ════════════════════════════════════════════════════════════════════

@dataclass
class ToolRegistry:
    """
    所有可供代理呼叫的工具的中央登錄。
    工具在 OS 啟動時注冊；代理透過 tool_list() 探索。
    """
    _tools:    dict[str, ToolSpec]    = field(default_factory=dict, init=False)
    _handlers: dict[str, Callable]    = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self._register_builtins()

    def register(self, spec: ToolSpec, handler: Callable) -> None:
        self._tools[spec.name]    = spec
        self._handlers[spec.name] = handler

    def get_spec(self, name: str) -> ToolSpec | None:
        return self._tools.get(name)

    def get_handler(self, name: str) -> Callable | None:
        return self._handlers.get(name)

    def all_specs(self) -> list[ToolSpec]:
        return list(self._tools.values())

    def _register_builtins(self) -> None:
        builtins: list[tuple[ToolSpec, Callable]] = [
            (
                ToolSpec(
                    name="web_search",
                    description="搜尋網頁內容（使用 Wikipedia API），回傳標題、摘要與 URL。",
                    required_capability=Capability.TOOL_WEB_FETCH,
                    parameters={
                        "query": {"type": "string", "description": "搜尋關鍵字"},
                        "top_k": {"type": "integer", "description": "回傳筆數（最多 20）"},
                    },
                ),
                _handle_web_search,
            ),
            (
                ToolSpec(
                    name="web_fetch",
                    description="取得指定 URL 的網頁內容。自動跟隨重新導向，支援 UTF-8 編碼。",
                    required_capability=Capability.TOOL_WEB_FETCH,
                    parameters={"url": {"type": "string", "description": "目標 URL"}},
                ),
                _handle_web_fetch,
            ),
            (
                ToolSpec(
                    name="code_exec",
                    description="在受限沙箱中執行 Python 程式碼片段。",
                    required_capability=Capability.TOOL_CODE_EXEC,
                    parameters={
                        "code": {"type": "string", "description": "Python 程式碼"},
                    },
                ),
                _handle_code_exec,
            ),
            (
                ToolSpec(
                    name="file_read",
                    description=f"讀取 {_WORKSPACE}/ 下的檔案。",
                    required_capability=Capability.TOOL_FILE_READ,
                    parameters={
                        "path": {"type": "string", "description": "檔案路徑"},
                    },
                ),
                _handle_file_read,
            ),
            (
                ToolSpec(
                    name="file_write",
                    description=f"寫入 {_WORKSPACE}/ 下的檔案。",
                    required_capability=Capability.TOOL_FILE_WRITE,
                    parameters={
                        "path":    {"type": "string", "description": "檔案路徑"},
                        "content": {"type": "string", "description": "寫入內容"},
                    },
                ),
                _handle_file_write,
            ),
        ]
        for spec, handler in builtins:
            self.register(spec, handler)


# ════════════════════════════════════════════════════════════════════
# Tool Sandbox
# ════════════════════════════════════════════════════════════════════

@dataclass
class ToolSandbox:
    """
    工具執行的隔離層。
    結果先進入沙箱，由此過濾後才注入代理的上下文。
    代理無法透過工具呼叫取得超出能力令牌範圍的存取權。

    Phase 1：in-process，靠參數白名單和輸出大小限制隔離。
    Phase 2：替換為真實 seccomp / nsjail 行程隔離。
    """
    max_output_bytes: int = 64 * 1024   # 64 KB 輸出上限

    def execute(
        self,
        handler:  Callable,
        args:     dict[str, Any],
    ) -> dict[str, Any]:
        """執行 handler，攔截所有異常，截斷超長輸出。"""
        t0 = time.perf_counter()
        try:
            raw = handler(**args)
        except Exception:
            raw = {"error": traceback.format_exc(limit=5)}

        # 截斷超長輸出
        raw_str = str(raw)
        if len(raw_str) > self.max_output_bytes:
            raw = {
                "truncated": True,
                "content":   raw_str[: self.max_output_bytes],
                "note":      f"輸出超過 {self.max_output_bytes} bytes，已截斷",
            }
        return {"result": raw, "duration_ms": (time.perf_counter() - t0) * 1000}


# ════════════════════════════════════════════════════════════════════
# Tool Router
# ════════════════════════════════════════════════════════════════════

@dataclass
class ToolRouter:
    """
    工具呼叫的統一入口。
    流程：能力驗證（由 PolicyEngine 完成，外部傳入決策）→ 沙箱執行 → 回傳 ToolResult

    ToolRouter 本身不做權限判斷；PolicyEngine 的決策由 kernel 層傳入。
    這保持了關注點分離：安全層 ≠ 執行層。
    """
    registry: ToolRegistry
    sandbox:  ToolSandbox = field(default_factory=ToolSandbox)

    def execute(
        self,
        name: str,
        args: dict[str, Any],
    ) -> ToolResult:
        """
        假設呼叫者已通過 PolicyEngine 驗證。
        直接執行工具，回傳 ToolResult。
        """
        spec    = self.registry.get_spec(name)
        handler = self.registry.get_handler(name)

        if spec is None or handler is None:
            return ToolResult(
                tool_name=name,
                success=False,
                output=None,
                error=f"未知的工具: '{name}'",
            )

        result = self.sandbox.execute(handler, args)
        output = result["result"]
        is_error = isinstance(output, dict) and "error" in output

        return ToolResult(
            tool_name=name,
            success=not is_error,
            output=output,
            error=output.get("error") if is_error else None,
            duration_ms=result["duration_ms"],
        )

    def accessible_tools(self, capabilities: frozenset[Capability]) -> list[ToolSpec]:
        """回傳給定能力集合可存取的工具列表。"""
        return [
            spec for spec in self.registry.all_specs()
            if spec.required_capability in capabilities
        ]
