"""
aios.fs.aiofs
──────────────
AIOFS：AI 原生檔案系統（Phase 1 in-memory 實作）。

三層設計：
  語意索引層  — 每個 blob 有 embedding，支援語意查詢
  內容定址層  — SHA-256 hash 去重，相同內容只存一份
  分層儲存    — HOT / WARM / COLD（Phase 1 統一 in-memory，模擬三層）
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from aios.core.models import KBEntry, StorageTier
from aios.memory import _cosine, _deterministic_embed


# ════════════════════════════════════════════════════════════════════
# 分層儲存模擬（Phase 1 全部 in-memory，但記錄 tier 標記）
# ════════════════════════════════════════════════════════════════════

# 存取次數門檻：超過此值晉升，低於此值降級（簡化模擬）
_PROMOTE_THRESHOLD = 5
_DEMOTE_THRESHOLD  = 1


@dataclass
class AIOFS:
    """
    AI 原生檔案系統。

    特性：
      - content-addressed：相同內容只存一份（SHA-256 主鍵）
      - semantic-indexed：支援向量相似度查詢
      - tiered：HOT / WARM / COLD 分層（Phase 1 模擬）
    """
    embed_fn: Callable[[str], list[float]] = field(
        default_factory=lambda: _deterministic_embed,
    )

    # CAS 主索引：content_hash → KBEntry
    _cas:  dict[str, KBEntry] = field(default_factory=dict, init=False)
    # ref → content_hash 的反向索引
    _refs: dict[str, str]     = field(default_factory=dict, init=False)

    # ── 寫入 ────────────────────────────────────────────────────────

    def index(
        self,
        content:  str,
        metadata: dict[str, Any] | None = None,
    ) -> KBEntry:
        """
        索引一個新的 blob。
        若相同內容已存在，回傳現有條目（去重）。
        """
        content_hash = hashlib.sha256(content.encode()).hexdigest()

        if content_hash in self._cas:
            existing = self._cas[content_hash]
            existing.touch()
            return existing

        entry = KBEntry(
            content=content,
            metadata=metadata or {},
            content_hash=content_hash,
            tier=StorageTier.HOT,
        )
        entry.embedding = self.embed_fn(content)

        self._cas[content_hash]   = entry
        self._refs[entry.ref]     = content_hash
        return entry

    # ── 讀取（語意查詢）────────────────────────────────────────────

    def search(
        self,
        query:     str,
        top_k:     int   = 5,
        min_score: float = 0.0,
        tier_filter: list[StorageTier] | None = None,
    ) -> list[tuple[KBEntry, float]]:
        """
        向量相似度搜尋。
        回傳 [(entry, score)] 按 score 降序排列。
        """
        q_vec = self.embed_fn(query)
        scored: list[tuple[KBEntry, float]] = []

        for entry in self._cas.values():
            if tier_filter and entry.tier not in tier_filter:
                continue
            if entry.embedding is None:
                continue
            score = _cosine(q_vec, entry.embedding)
            if score >= min_score:
                scored.append((entry, score))

        scored.sort(key=lambda x: x[1], reverse=True)

        for entry, _ in scored[:top_k]:
            entry.touch()
            self._maybe_promote(entry)

        return scored[:top_k]

    # ── 讀取（by ref）───────────────────────────────────────────────

    def get_by_ref(self, ref: str) -> KBEntry | None:
        content_hash = self._refs.get(ref)
        if content_hash is None:
            return None
        entry = self._cas.get(content_hash)
        if entry:
            entry.touch()
        return entry

    def get_by_hash(self, content_hash: str) -> KBEntry | None:
        entry = self._cas.get(content_hash)
        if entry:
            entry.touch()
        return entry

    # ── 分層管理 ─────────────────────────────────────────────────────

    def _maybe_promote(self, entry: KBEntry) -> None:
        """存取頻率高時晉升至更快的層。"""
        if entry.access_count >= _PROMOTE_THRESHOLD:
            if entry.tier == StorageTier.COLD:
                entry.tier = StorageTier.WARM
            elif entry.tier == StorageTier.WARM:
                entry.tier = StorageTier.HOT

    def run_tiering_pass(self) -> dict[str, int]:
        """
        執行一次分層決策（通常由後台排程器定期觸發）。
        低存取頻率的條目降級至 WARM / COLD。
        回傳各層的條目數統計。
        """
        for entry in self._cas.values():
            if entry.access_count < _DEMOTE_THRESHOLD:
                if entry.tier == StorageTier.HOT:
                    entry.tier = StorageTier.WARM
                elif entry.tier == StorageTier.WARM:
                    entry.tier = StorageTier.COLD

        counts: dict[str, int] = {t.value: 0 for t in StorageTier}
        for entry in self._cas.values():
            counts[entry.tier.value] += 1
        return counts

    # ── 統計 ────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        counts = {t.value: 0 for t in StorageTier}
        for entry in self._cas.values():
            counts[entry.tier.value] += 1
        return {
            "total_entries": len(self._cas),
            "tiers":         counts,
        }

    def count(self) -> int:
        return len(self._cas)


# ════════════════════════════════════════════════════════════════════
# Phase 3：一致性雜湊環（AIOFS 分散式層）
# ════════════════════════════════════════════════════════════════════

from aios.core.models_p3 import ReplicaPlacement, RingNode


class ConsistentHashRing:
    """
    AIOFS 用的一致性雜湊環。

    負責決定每個 blob（以 content_hash 識別）
    應儲存在哪個節點（primary）以及哪些副本節點（replicas）。

    使用方式：
      ring = ConsistentHashRing(virtual_nodes=100, replication_factor=2)
      ring.add_node("node-a")
      ring.add_node("node-b")
      placement = ring.place("sha256:abcdef...")
    """

    def __init__(
        self,
        virtual_nodes:       int = 100,
        replication_factor:  int = 2,
    ) -> None:
        self._virtual_nodes     = virtual_nodes
        self._replication_factor = replication_factor
        self._ring:    dict[int, str] = {}
        self._sorted:  list[int]      = []
        self._nodes:   dict[str, RingNode] = {}

    def add_node(self, node_id: str, address: str = "", weight: float = 1.0) -> None:
        rn = RingNode(
            node_id=node_id,
            address=address,
            virtual_count=int(self._virtual_nodes * weight),
            weight=weight,
        )
        self._nodes[node_id] = rn
        for i in range(rn.virtual_count):
            h = _ring_hash(f"{node_id}:vn:{i}")
            self._ring[h] = node_id
        self._sorted = sorted(self._ring.keys())

    def remove_node(self, node_id: str) -> None:
        self._nodes.pop(node_id, None)
        self._ring = {h: nid for h, nid in self._ring.items() if nid != node_id}
        self._sorted = sorted(self._ring.keys())

    def place(self, content_hash: str) -> ReplicaPlacement:
        """回傳 content_hash 的 primary + replica 節點列表。"""
        nodes = self._route_multi(content_hash, self._replication_factor + 1)
        primary  = nodes[0] if nodes else ""
        replicas = nodes[1:self._replication_factor] if len(nodes) > 1 else []
        return ReplicaPlacement(
            content_hash=content_hash,
            primary_node=primary,
            replica_nodes=replicas,
            replication_factor=self._replication_factor,
        )

    def is_responsible(self, node_id: str, content_hash: str) -> bool:
        """判斷 node_id 是否對 content_hash 負責（primary 或 replica）。"""
        placement = self.place(content_hash)
        return (node_id == placement.primary_node
                or node_id in placement.replica_nodes)

    @property
    def ring_size(self) -> int:
        return len(self._sorted)

    @property
    def node_count(self) -> int:
        return len(self._nodes)

    def _route_multi(self, key: str, n: int) -> list[str]:
        if not self._sorted or n == 0:
            return []
        import bisect
        key_hash = _ring_hash(key)
        idx  = bisect.bisect_left(self._sorted, key_hash)
        seen: set[str] = set()
        result: list[str] = []
        for offset in range(len(self._sorted)):
            actual = (idx + offset) % len(self._sorted)
            nid = self._ring[self._sorted[actual]]
            if nid not in seen:
                seen.add(nid)
                result.append(nid)
            if len(result) >= n:
                break
        return result


def _ring_hash(key: str) -> int:
    import hashlib
    return int(hashlib.sha256(key.encode()).hexdigest()[:16], 16)


# ════════════════════════════════════════════════════════════════════
# Phase 3：分散式 AIOFS
# ════════════════════════════════════════════════════════════════════

class DistributedAIOFS:
    """
    分散式 AIOFS。

    在多節點叢集上分散儲存 KB blob。
    Phase 3 in-process 模擬：所有 blob 仍在記憶體中，
    但路由決策使用真實的一致性雜湊環。

    每個 blob 的 metadata["storage_node"] 記錄了實際路由到的節點。
    """

    def __init__(
        self,
        virtual_nodes:      int = 100,
        replication_factor: int = 2,
    ) -> None:
        self._ring  = ConsistentHashRing(virtual_nodes, replication_factor)
        self._local: AIOFS = AIOFS()       # 本地 AIOFS（in-process blob 儲存）
        self._local_node: str = ""
        self._nodes: set[str] = set()

    def add_node(self, node_id: str, address: str = "") -> None:
        self._ring.add_node(node_id, address=address)
        self._nodes.add(node_id)

    def remove_node(self, node_id: str) -> None:
        self._ring.remove_node(node_id)
        self._nodes.discard(node_id)

    def set_local_node(self, node_id: str) -> None:
        self._local_node = node_id

    def index(
        self,
        content:  str,
        metadata: dict | None = None,
    ) -> KBEntry | None:
        """
        索引 blob：決定 primary 節點，寫入本地儲存並記錄路由。
        """
        import hashlib
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        placement    = self._ring.place(content_hash)

        meta = dict(metadata or {})
        meta["storage_node"]    = placement.primary_node
        meta["replica_nodes"]   = placement.replica_nodes
        meta["replication_factor"] = placement.replication_factor

        return self._local.index(content, meta)

    def search(self, query: str, top_k: int = 5) -> list[tuple[KBEntry, float]]:
        """語意搜尋（Phase 3 模擬：只查本地節點）。"""
        return self._local.search(query, top_k=top_k)

    def get_by_hash(self, content_hash: str) -> KBEntry | None:
        return self._local.get_by_hash(content_hash)

    def get_by_ref(self, ref: str) -> KBEntry | None:
        return self._local.get_by_ref(ref)

    def run_tiering_pass(self) -> dict[str, int]:
        return self._local.run_tiering_pass()

    def stats(self) -> dict:
        return {
            "total_entries": self._local.count(),
            "nodes":         len(self._nodes),
            "ring_size":     self._ring.ring_size,
            "local_node":    self._local_node,
            "tiers":         self._local.stats().get("tiers", {}),
        }

    def count(self) -> int:
        return self._local.count()

