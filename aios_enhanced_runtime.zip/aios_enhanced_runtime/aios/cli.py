"""
aios.cli
────────
AIOS 命令列介面。
"""

from __future__ import annotations

import json
import os
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

from aios.core.models import (
    AgentSpec,
    Capability,
    MemoryScope,
    MemoryTier,
    MemStoreRequest,
    MemRecallRequest,
    ToolCallRequest,
)
from aios.kernel.aios_p2 import AIOS_P2

app = typer.Typer(
    name="aios",
    help="AI-Native Operating System — CLI",
    no_args_is_help=True,
)
console = Console()

_INSTANCE: AIOS_P2 | None = None


def _get() -> AIOS_P2:
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = AIOS_P2.build(verbose=True)
    return _INSTANCE


@app.callback()
def _main() -> None:
    pass


@app.command()
def run(
    goal: str = typer.Argument(..., help="Agent 的目標"),
    owner: str = typer.Option("user:cli", "--owner", "-o", help="Agent 擁有者"),
    model: str = typer.Option("default", "--model", "-m", help="模型名稱"),
    capabilities: str = typer.Option(
        "memory:read:personal,memory:write:personal,tool:code_exec:sandboxed,tool:web_fetch",
        "--caps", "-c",
        help="逗號分隔的能力列表",
    ),
    actions: str = typer.Option(
        "mem_recall,mem_store,tool_call,tool:code_exec,tool:web_search,tool:web_fetch,tool:file_read,tool:file_write",
        "--actions", "-a",
        help="逗號分隔的宣告動作",
    ),
    forbidden: str = typer.Option(
        "agent_spawn",
        "--forbid", "-f",
        help="逗號分隔的禁止動作",
    ),
    verbose: bool = typer.Option(
        True, "--verbose/--quiet", "-v/-q",
        help="顯示詳細輸出",
    ),
    max_steps: int = typer.Option(
        20, "--max-steps", "-s",
        help="最大推論步數",
    ),
) -> None:
    """執行一個 AI Agent。"""
    aios = _get()
    aios.runner_config.verbose = verbose
    aios.register_model(model, size_mb=100.0)

    cap_list = [Capability(c.strip()) for c in capabilities.split(",") if c.strip()]
    act_list = [a.strip() for a in actions.split(",") if a.strip()]
    forbid_list = [f.strip() for f in forbidden.split(",") if f.strip()]

    spec = AgentSpec(
        goal=goal,
        owner=owner,
        capabilities=cap_list,
        max_scope=MemoryScope.PERSONAL,
        declared_actions=act_list,
        forbidden_actions=forbid_list,
        max_steps=max_steps,
        model=model,
    )

    console.print(Panel(f"[bold]🚀 Spawning Agent[/]\n[cyan]{goal}[/]", width=80))
    state = aios.agent_spawn(spec)

    with console.status("[bold green]Agent 執行中..."):
        result = aios.run_agent(state)

    if result.status.value == "done":
        console.print(f"[bold green]✓ 完成[/] (步數: {result.steps})")
        if result.result:
            console.print(Panel(result.result, width=80))
        else:
            console.print("(無輸出)")
    else:
        console.print(Panel(
            f"[bold red]✗ 失敗[/]: {result.error}",
            width=80,
        ))
        sys.exit(1)


@app.command()
def status() -> None:
    """顯示 AIOS 系統狀態儀表板。"""
    aios = _get()
    snap = aios.kernel.sys_stats()

    table = Table(title="AIOS 系統狀態", width=80)
    table.add_column("項目", style="cyan")
    table.add_column("數值", style="green")

    for status_name, count in snap.agents.items():
        table.add_row(f"Agent ({status_name})", str(count))
    table.add_row("---", "---")

    for key, val in snap.memory.items():
        if isinstance(val, int):
            table.add_row(f"記憶體/{key}", str(val))

    table.add_row("工具數", str(snap.tools))
    table.add_row("KB 條目", str(snap.kb_entries))

    console.print(table)

    kv = aios.kvcache.stats
    extra = Table(width=80)
    extra.add_column("KV-Cache", style="cyan")
    extra.add_column("數值", style="green")
    extra.add_row("總區塊", str(kv.total_blocks))
    extra.add_row("可用區塊", str(kv.free_blocks))
    extra.add_row("使用率", f"{kv.utilization:.1%}")
    extra.add_row("前綴命中率", f"{kv.prefix_hit_rate:.1%}")
    extra.add_row("驅逐次數", str(kv.evictions))
    console.print(extra)


@app.command()
def report() -> None:
    """顯示完整的 AIOS 系統報告（含 L1-L5 與 Phase 3）。"""
    aios = _get()
    r = aios.full_report()
    console.print_json(json.dumps(r, indent=2, default=str))
    console.print(Panel(
        f"[green]L1 KV-Cache:[/] {r['l1_kvcache']['utilization']:.1%} used  |  "
        f"[green]L2 模型:[/] {r['l2_model_manager']['total_models']}  |  "
        f"[green]L5 Agent:[/] {sum(r['l5_kernel']['agents'].values())} active",
        width=80,
    ))


@app.command()
def shell() -> None:
    """進入互動式 AIOS Shell（多輪對話）。"""
    from datetime import datetime, timezone

    aios = _get()
    aios.runner_config.verbose = False

    console.print(Panel.fit(
        "[bold cyan]AIOS Interactive Shell[/]\n"
        "與 AIOS 進行多輪對話。支援計算、搜尋、問答。\n"
        "[dim]指令：[/dim] [bold]/exit[/] 離開  [bold]/status[/] 系統狀態",
        width=80,
    ))

    spec = AgentSpec(
        goal="互動式對話",
        owner="user:shell",
        capabilities=[
            Capability.MEM_READ_PERSONAL,
            Capability.MEM_WRITE_PERSONAL,
            Capability.TOOL_CODE_EXEC,
            Capability.TOOL_FILE_READ,
            Capability.TOOL_FILE_WRITE,
            Capability.TOOL_WEB_FETCH,
        ],
        max_scope=MemoryScope.PERSONAL,
        declared_actions=[
            "mem_recall", "mem_store", "tool_call",
            "tool:code_exec", "tool:file_read", "tool:file_write",
            "tool:web_fetch", "tool:web_search",
        ],
        forbidden_actions=["agent_spawn"],
        model="default",
    )

    # 建立持久 agent
    state = aios.agent_spawn(spec)
    turn = 0

    while True:
        try:
            goal = console.input(f"[bold cyan]({turn}) goal> [/]").strip()
        except (EOFError, KeyboardInterrupt):
            aios.kernel.agent_kill(state.instance_id)
            console.print("\n[bold yellow]Bye![/]")
            break

        if not goal:
            continue
        if goal == "/exit":
            aios.kernel.agent_kill(state.instance_id)
            break
        if goal == "/status":
            snap = aios.kernel.sys_stats()
            console.print(f"[green]Agents:[/] {snap.agents}")
            console.print(f"[green]Memory:[/] {snap.memory}")
            continue
        if goal == "/clear":
            turn = 0
            aios.kernel.agent_kill(state.instance_id)
            state = aios.agent_spawn(spec)
            console.print("[yellow]對話已清除，新開一輪。[/]")
            continue
        if goal == "/help":
            console.print(Panel.fit(
                "[bold]AIOS Shell 指令[/]\n"
                "  /exit   離開 Shell\n"
                "  /status 顯示系統狀態\n"
                "  /clear  清除對話歷史\n"
                "  /help   顯示此說明\n\n"
                "[bold]支援的輸入[/]\n"
                "  • 計算: 計算1+1, 2**10, 3*4+5\n"
                "  • 搜尋: 搜尋 AI 論文, 找 Python 教學\n"
                "  • 網頁: 抓取 https://example.com\n"
                "  • 任意文字: 會嘗試透過工具理解與回覆",
                width=80,
            ))
            continue

        turn += 1

        # 先將使用者輸入存入 episodic 記憶
        aios.kernel.mem_store(
            state.token,
            MemStoreRequest(
                content=f"[使用者 turn {turn}] {goal}",
                tier=MemoryTier.EPISODIC,
                intent=f"記錄對話第 {turn} 輪",
            ),
        )

        # 更新目標並執行
        spec = spec.model_copy(update={"goal": goal})
        state.spec = spec
        result = aios.run_agent(state)

        if result.status.value == "done":
            panel = Panel(
                result.result or "(無輸出)",
                width=80,
            )
            console.print(panel)

            # 將結果存入 episodic 記憶
            aios.kernel.mem_store(
                state.token,
                MemStoreRequest(
                    content=f"[AIOS turn {turn}] {result.result[:500]}",
                    tier=MemoryTier.EPISODIC,
                    intent=f"AIOS 回覆第 {turn} 輪",
                ),
            )
        else:
            console.print(f"[bold red]錯誤:[/] {result.error}")


@app.command()
def distributed(
    goal: str = typer.Argument("分散式推論演示", help="Agent 目標"),
    nodes: int = typer.Option(3, "--nodes", "-n", help="模擬節點數"),
) -> None:
    """在分散式模式 (Phase 3) 下執行 Agent。"""
    global _INSTANCE
    _INSTANCE = AIOS_P2.build(
        total_kv_blocks=256,
        vram_capacity_mb=16_000.0,
        verbose=True,
        enable_distributed=True,
        num_nodes=nodes,
    )
    aios = _INSTANCE
    aios.register_model("default", size_mb=100.0)

    spec = AgentSpec(
        goal=goal,
        owner="user:dist",
        capabilities=[
            Capability.MEM_READ_PERSONAL,
            Capability.MEM_WRITE_PERSONAL,
        ],
        max_scope=MemoryScope.PERSONAL,
        declared_actions=["mem_recall", "mem_store"],
        forbidden_actions=[],
        model="default",
    )

    state = aios.agent_spawn(spec)
    result = aios.run_agent(state)

    report_data = aios.full_report()
    console.print_json(json.dumps(report_data, indent=2, default=str))

    if result.status.value == "done":
        console.print(f"[bold green]✓[/] {result.result}")
    else:
        console.print(f"[bold red]✗[/] {result.error}")


@app.command()
def dashboard(
    host: str = typer.Option("127.0.0.1", "--host", "-H", help="綁定 IP"),
    port: int = typer.Option(8765, "--port", "-p", help="監聽埠號"),
    no_browser: bool = typer.Option(False, "--no-browser", "-n", help="不自動開啟瀏覽器"),
) -> None:
    """啟動 AIOS Web 儀表板。"""
    aios = _get()
    console.print(
        Panel.fit(
            "[bold cyan]AIOS Dashboard[/]\n"
            "啟動 Web 伺服器，提供即時系統監控儀表板。\n"
            f"[dim]http://{host}:{port}[/]",
            width=80,
        )
    )
    try:
        from aios.dashboard.server import run_server
        run_server(host=host, port=port, instance=aios, open_browser=not no_browser)
    except ImportError as e:
        console.print(f"[bold red]缺少相依套件:[/] {e}")
        console.print("[yellow]安裝方式: pip install fastapi uvicorn[/]")
        raise typer.Exit(1)


def main() -> None:
    app()
