"""aios.cluster.gpu_scheduler — GPU-aware placement with phase affinity and KV locality"""
from __future__ import annotations
import threading, time, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from aios.core.models_p2 import InferencePhase, InferenceTask, TaskPriority
from aios.observability import get_bus, get_tracer, GPU_UTIL, SystemEvent, EventSeverity

class DeviceClass(str, Enum):
    H100="h100"; A100="a100"; A10G="a10g"; APPLE="apple"; CPU="cpu"

_SPECS:dict[DeviceClass,tuple[float,float,float]]={
    DeviceClass.H100:(80.0,989.0,3350.0), DeviceClass.A100:(80.0,312.0,2000.0),
    DeviceClass.A10G:(24.0,125.0,600.0),  DeviceClass.APPLE:(64.0,40.0,400.0),
    DeviceClass.CPU:(64.0,1.0,51.0),
}

@dataclass
class GPUDevice:
    device_id:str; device_class:DeviceClass; node_id:str
    vram_total_gb:float=0.0; vram_used_gb:float=0.0
    compute_util:float=0.0; mem_bw_util:float=0.0; healthy:bool=True
    resident_prefixes:set=field(default_factory=set); tasks_running:int=0
    last_heartbeat:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    def __post_init__(self):
        if self.vram_total_gb==0.0: self.vram_total_gb=_SPECS[self.device_class][0]
    @property
    def vram_free_gb(self)->float: return max(0.0,self.vram_total_gb-self.vram_used_gb)
    @property
    def vram_utilisation(self)->float: return self.vram_used_gb/self.vram_total_gb if self.vram_total_gb else 0.0
    @property
    def compute_tflops(self)->float: return _SPECS[self.device_class][1]
    @property
    def mem_bw_gbps(self)->float: return _SPECS[self.device_class][2]
    def allocate(self,gb:float)->bool:
        if gb>self.vram_free_gb: return False
        self.vram_used_gb+=gb; self.tasks_running+=1; return True
    def release(self,gb:float):
        self.vram_used_gb=max(0.0,self.vram_used_gb-gb); self.tasks_running=max(0,self.tasks_running-1)
    def simulated_heartbeat(self):
        self.compute_util=max(0.0,self.compute_util*0.95+self.tasks_running*0.03)
        self.mem_bw_util=max(0.0,self.mem_bw_util*0.95+self.vram_utilisation*0.05)
        self.last_heartbeat=datetime.now(timezone.utc)
        GPU_UTIL.set(self.compute_util)

@dataclass
class PlacementDecision:
    task_id:str; device_id:str|None; node_id:str|None; score:float; reason:str
    phase:InferencePhase; vram_needed:float
    timestamp:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    @property
    def placed(self)->bool: return self.device_id is not None

class GPUScheduler:
    HEADROOM=0.15; LOCALITY=50.0; UTIL_PENALTY=20.0
    def __init__(self):
        self._devs:dict[str,GPUDevice]={}; self._lk=threading.Lock()
        self._tracer=get_tracer(); self._bus=get_bus(); self._decisions:list[PlacementDecision]=[]
    def register_device(self,did,cls,nid,vram_total_gb=0.0)->GPUDevice:
        d=GPUDevice(did,cls,nid,vram_total_gb)
        with self._lk: self._devs[did]=d
        return d
    def unregister_device(self,did):
        with self._lk: self._devs.pop(did,None)
    def heartbeat(self,did,**m):
        with self._lk:
            d=self._devs.get(did)
            if d:
                for k,v in m.items():
                    if hasattr(d,k): setattr(d,k,v)
                d.last_heartbeat=datetime.now(timezone.utc)
    def place(self,task:InferenceTask,vram_needed:float=1.0,prefix_hash:str|None=None)->PlacementDecision:
        with self._tracer.start("gpu_place",phase=task.phase.value) as span:
            dec=self._score(task,vram_needed,prefix_hash)
            if dec.placed:
                d=self._devs[dec.device_id]; d.allocate(vram_needed)
                if prefix_hash: d.resident_prefixes.add(prefix_hash)
                span.set("device",dec.device_id).set("score",dec.score)
            else:
                self._bus.emit(SystemEvent("gpu.no_placement","GPUScheduler",EventSeverity.WARN,
                                           {"task_id":task.task_id,"vram_needed":vram_needed}))
            self._decisions.append(dec); return dec
    def release(self,did,gb):
        with self._lk:
            d=self._devs.get(did)
            if d: d.release(gb)
    def _score(self,task,vram_needed,prefix_hash)->PlacementDecision:
        best_score=-1.0; best=None
        with self._lk: cands=list(self._devs.values())
        for d in cands:
            if not d.healthy: continue
            headroom=d.vram_free_gb-vram_needed
            if headroom<d.vram_total_gb*self.HEADROOM: continue
            s=self._compute_score(d,task.phase,prefix_hash,headroom)
            if s>best_score: best_score=s; best=d
        if best is None:
            return PlacementDecision(task.task_id,None,None,-1.0,"no_device",task.phase,vram_needed)
        return PlacementDecision(task.task_id,best.device_id,best.node_id,best_score,
                                  f"class={best.device_class.value}",task.phase,vram_needed)
    def _compute_score(self,d,phase,ph,headroom)->float:
        ps=(d.compute_tflops/1000.0 if phase==InferencePhase.PREFILL else d.mem_bw_gbps/3500.0)
        vs=headroom/d.vram_total_gb
        loc=self.LOCALITY if(ph and ph in d.resident_prefixes) else 0.0
        return ps*30+vs*40+loc-d.compute_util*self.UTIL_PENALTY
    def device_report(self)->list:
        with self._lk:
            return [{"device_id":d.device_id,"class":d.device_class.value,"node":d.node_id,
                     "vram_total":d.vram_total_gb,"vram_used":round(d.vram_used_gb,2),
                     "vram_free":round(d.vram_free_gb,2),"compute_util":round(d.compute_util,3),
                     "tasks":d.tasks_running,"healthy":d.healthy}
                    for d in self._devs.values()]
    def tick(self):
        with self._lk:
            for d in self._devs.values(): d.simulated_heartbeat()
    @property
    def device_count(self)->int: return len(self._devs)
    @property
    def placements(self)->list: return list(self._decisions)
