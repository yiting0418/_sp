"""aios.cluster.migration — checkpoint, transfer, restore across nodes"""
from __future__ import annotations
import time, uuid, pickle
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from aios.core.models import AgentState, AgentStatus
from aios.core.models_p2 import InferenceTask
from aios.observability import MIGRATIONS, get_bus, get_tracer, SystemEvent, EventSeverity
from aios.runtime.engine import EngineState

class MigrationReason(str, Enum):
    LOAD_BALANCE="load_balance"; EVACUATION="evacuation"; AFFINITY="affinity"; FAULT="fault"

class MigrationStatus(str, Enum):
    PENDING="pending"; CHECKPOINT="checkpoint"; TRANSFER="transfer"
    RESTORE="restore"; DONE="done"; FAILED="failed"

@dataclass
class AgentCheckpoint:
    checkpoint_id:str=field(default_factory=lambda:"ckpt:"+uuid.uuid4().hex[:8])
    instance_id:str=""; source_node:str=""; goal:str=""
    messages:list=field(default_factory=list); result:str|None=None; steps:int=0
    engine_state:EngineState|None=None; memory_refs:list=field(default_factory=list)
    context_dump:str=""; created_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    size_bytes:int=0

@dataclass
class MigrationRecord:
    migration_id:str=field(default_factory=lambda:"mig:"+uuid.uuid4().hex[:8])
    instance_id:str=""; source_node:str=""; target_node:str=""
    reason:MigrationReason=MigrationReason.LOAD_BALANCE; status:MigrationStatus=MigrationStatus.PENDING
    checkpoint:AgentCheckpoint|None=None; error:str|None=None
    started_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    completed_at:datetime|None=None; duration_ms:float=0.0

class MigrationManager:
    def __init__(self): self._recs:dict[str,MigrationRecord]={}; self._tracer=get_tracer(); self._bus=get_bus()
    def migrate(self,state:AgentState,task:InferenceTask|None,src:str,tgt:str,
                reason:MigrationReason=MigrationReason.LOAD_BALANCE,
                engine_state:EngineState|None=None)->MigrationRecord:
        rec=MigrationRecord(instance_id=state.instance_id,source_node=src,target_node=tgt,reason=reason)
        self._recs[rec.migration_id]=rec; t0=time.perf_counter()
        with self._tracer.start("agent_migrate",reason=reason.value) as span:
            try:
                rec.status=MigrationStatus.CHECKPOINT
                ckpt=self._checkpoint(state,task,src,engine_state); rec.checkpoint=ckpt
                rec.status=MigrationStatus.TRANSFER; self._transfer(ckpt,src,tgt)
                rec.status=MigrationStatus.RESTORE;  self._restore(state,ckpt,tgt)
                rec.status=MigrationStatus.DONE; MIGRATIONS.inc()
                span.set("ckpt_bytes",ckpt.size_bytes)
            except Exception as e:
                rec.status=MigrationStatus.FAILED; rec.error=str(e); span.set_error(e)
                self._bus.emit(SystemEvent("migration.failed","MigrationManager",EventSeverity.ERROR,
                                           {"id":rec.migration_id,"error":str(e)})); raise
            finally:
                rec.completed_at=datetime.now(timezone.utc)
                rec.duration_ms=(time.perf_counter()-t0)*1000
        self._bus.emit(SystemEvent("migration.done","MigrationManager",
                                   payload={"id":rec.migration_id,"src":src,"tgt":tgt,"ms":rec.duration_ms}))
        return rec
    def get_record(self,mid): return self._recs.get(mid)
    def list_records(self,instance_id=None)->list:
        recs=list(self._recs.values())
        if instance_id: recs=[r for r in recs if r.instance_id==instance_id]
        return sorted(recs,key=lambda r:r.started_at)
    def stats(self)->dict:
        recs=list(self._recs.values())
        done=[r for r in recs if r.status==MigrationStatus.DONE]
        fail=[r for r in recs if r.status==MigrationStatus.FAILED]
        return {"total":len(recs),"done":len(done),"failed":len(fail),
                "avg_ms":sum(r.duration_ms for r in done)/len(done) if done else 0.0,
                "by_reason":{r.value:sum(1 for x in recs if x.reason==r) for r in MigrationReason}}
    def _checkpoint(self,state,task,src,engine_state)->AgentCheckpoint:
        ckpt=AgentCheckpoint(instance_id=state.instance_id,source_node=src,goal=state.spec.goal,
                              messages=list(state.messages),result=state.result,steps=state.steps,
                              engine_state=engine_state,context_dump=str(state.messages[-3:]) if state.messages else "")
        try: ckpt.size_bytes=len(pickle.dumps(ckpt))
        except: ckpt.size_bytes=len(str(ckpt).encode())
        return ckpt
    def _transfer(self,ckpt,src,tgt):
        lat=ckpt.size_bytes/(10*1024*1024)*1000; time.sleep(min(lat/1000,0.005))
    def _restore(self,state,ckpt,tgt):
        state.messages=list(ckpt.messages); state.steps=ckpt.steps
        state.result=ckpt.result; state.status=AgentStatus.SUSPENDED
