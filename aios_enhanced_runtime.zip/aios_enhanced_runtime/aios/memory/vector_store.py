"""aios.memory.vector_store — HNSW-style persistent vector store"""
from __future__ import annotations
import hashlib, json, math, os, random, threading, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
from aios.observability import MEMORY_RECALL_MS, get_tracer

class DistanceMetric(str):
    COSINE="cosine"; DOT="dot"; L2="l2"

def _cos(a,b):
    na=float(np.linalg.norm(a)); nb=float(np.linalg.norm(b))
    return float(np.dot(a,b)/(na*nb)) if na>0 and nb>0 else 0.0
def _dot(a,b): return float(np.dot(a,b))
def _l2(a,b):  return -float(np.linalg.norm(a-b))
_METRICS={DistanceMetric.COSINE:_cos, DistanceMetric.DOT:_dot, DistanceMetric.L2:_l2}

@dataclass
class VectorEntry:
    doc_id:str; content:str; embedding:list
    metadata:dict=field(default_factory=dict); namespace:str=""
    created_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    updated_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc)); access_count:int=0
    def to_dict(self)->dict:
        return{"doc_id":self.doc_id,"content":self.content,"embedding":self.embedding,
               "metadata":self.metadata,"namespace":self.namespace,
               "created_at":self.created_at.isoformat(),"updated_at":self.updated_at.isoformat(),
               "access_count":self.access_count}
    @classmethod
    def from_dict(cls,d)->VectorEntry:
        return cls(doc_id=d["doc_id"],content=d["content"],embedding=d["embedding"],
                   metadata=d.get("metadata",{}),namespace=d.get("namespace",""),
                   created_at=datetime.fromisoformat(d.get("created_at",datetime.now(timezone.utc).isoformat())),
                   updated_at=datetime.fromisoformat(d.get("updated_at",datetime.now(timezone.utc).isoformat())),
                   access_count=d.get("access_count",0))

@dataclass
class SearchResult:
    entry:VectorEntry; score:float; rank:int

class _HNSW:
    M=16; M0=32; EF=40
    def __init__(self,dim,metric=DistanceMetric.COSINE):
        self.dim=dim; self._dist=_METRICS[metric]
        self._vecs:list[np.ndarray]=[]; self._ids:list[str]=[]
        self._graph:list[dict[int,set[int]]]=[{}]; self._max_layer=0; self._ep:int|None=None
    def add(self,doc_id,vec):
        idx=len(self._vecs); self._vecs.append(vec); self._ids.append(doc_id)
        level=min(int(-math.log(random.random())*(1/math.log(self.M))),6)
        while len(self._graph)<=level: self._graph.append({})
        self._max_layer=max(self._max_layer,level)
        if self._ep is None:
            self._ep=idx
            for l in range(level+1): self._graph[l][idx]=set()
            return
        ep=self._ep
        for l in range(self._max_layer,level,-1): ep=self._greedy(vec,ep,l)
        for l in range(min(level,self._max_layer)+1):
            nbs=self._search_layer(vec,ep,self.EF,l)
            m=self.M0 if l==0 else self.M
            chosen=sorted(nbs,key=lambda x:x[0],reverse=True)[:m]
            self._graph[l].setdefault(idx,set())
            for _,ni in chosen:
                self._graph[l][idx].add(ni); self._graph[l].setdefault(ni,set()).add(idx)
                if len(self._graph[l][ni])>m:
                    nv=self._vecs[ni]
                    pruned=sorted(self._graph[l][ni],key=lambda x:self._dist(nv,self._vecs[x]),reverse=True)[:m]
                    self._graph[l][ni]=set(pruned)
            ep=idx
    def search(self,q,k,ef=50)->list:
        if self._ep is None or not self._vecs: return []
        ep=self._ep
        for l in range(self._max_layer,0,-1): ep=self._greedy(q,ep,l)
        cands=self._search_layer(q,ep,max(ef,k),0)
        return sorted(cands,key=lambda x:x[0],reverse=True)[:k]
    def _greedy(self,q,ep,layer)->int:
        best=ep; bs=self._dist(q,self._vecs[ep]); changed=True
        while changed:
            changed=False
            for nb in self._graph[layer].get(best,set()):
                s=self._dist(q,self._vecs[nb])
                if s>bs: bs=s; best=nb; changed=True
        return best
    def _search_layer(self,q,ep,ef,layer)->list:
        vis={ep}; s=self._dist(q,self._vecs[ep])
        cands=[(s,ep)]; res=[(s,ep)]
        while cands:
            cands.sort(reverse=True); bs,bi=cands.pop(0)
            if res and bs<min(r[0] for r in res): break
            for nb in self._graph[layer].get(bi,set()):
                if nb not in vis:
                    vis.add(nb); sc=self._dist(q,self._vecs[nb])
                    cands.append((sc,nb)); res.append((sc,nb))
                    if len(res)>ef:
                        res.sort(reverse=True); res=res[:ef]
        return res
    def __len__(self)->int: return len(self._vecs)

class PersistentVectorStore:
    def __init__(self,dim=128,metric=DistanceMetric.COSINE,persist_dir=None,ef_search=50):
        self.dim=dim; self.metric=metric; self.persist_dir=persist_dir; self.ef_search=ef_search
        self._idx:dict[str,_HNSW]={}; self._ent:dict[str,dict[str,VectorEntry]]={}
        self._lk=threading.RLock(); self._tracer=get_tracer()
        if persist_dir: os.makedirs(persist_dir,exist_ok=True); self._load_all()
    def upsert(self,doc_id,content,embedding,namespace="default",metadata=None)->VectorEntry:
        vec=np.array(embedding,dtype=np.float32)
        with self._lk:
            ns=self._ent.setdefault(namespace,{})
            idx=self._get_or_create(namespace)
            if doc_id in ns:
                e=ns[doc_id]; e.content=content; e.embedding=embedding
                e.metadata=metadata or {}; e.updated_at=datetime.now(timezone.utc)
            else:
                e=VectorEntry(doc_id,content,embedding,metadata or {},namespace); ns[doc_id]=e; idx.add(doc_id,vec)
        if self.persist_dir: self._persist(namespace)
        return e
    def delete(self,doc_id,namespace="default")->bool:
        with self._lk:
            ns=self._ent.get(namespace,{})
            if doc_id not in ns: return False
            del ns[doc_id]; self._rebuild(namespace)
        if self.persist_dir: self._persist(namespace)
        return True
    def search(self,qv,namespace="default",top_k=5,min_score=0.0,ef=None)->list[SearchResult]:
        import time as _t
        with self._tracer.start("vector_search",ns=namespace,k=top_k) as span:
            t0=_t.perf_counter()
            vec=np.array(qv,dtype=np.float32)
            with self._lk:
                idx=self._idx.get(namespace); ns=self._ent.get(namespace,{}); ids=list(idx._ids) if idx else []
            if idx is None or len(idx)==0: return []
            hits=idx.search(vec,top_k,ef or self.ef_search)
            out=[]
            for rank,(score,ni) in enumerate(hits):
                if score<min_score: continue
                if ni>=len(ids): continue
                e=ns.get(ids[ni])
                if e is None: continue
                e.access_count+=1; out.append(SearchResult(e,score,rank+1))
            ms=(_t.perf_counter()-t0)*1000; MEMORY_RECALL_MS.observe(ms)
            span.set("results",len(out)).set("ms",ms); return out
    def get(self,doc_id,namespace="default")->VectorEntry|None:
        with self._lk: return self._ent.get(namespace,{}).get(doc_id)
    def list_namespaces(self)->list:
        with self._lk: return list(self._ent.keys())
    def count(self,namespace=None)->int:
        with self._lk:
            if namespace: return len(self._ent.get(namespace,{}))
            return sum(len(v) for v in self._ent.values())
    def _persist(self,ns):
        if not self.persist_dir: return
        p=Path(self.persist_dir)/f"{ns}.json"
        with self._lk: data=[e.to_dict() for e in self._ent.get(ns,{}).values()]
        p.write_text(json.dumps(data,ensure_ascii=False))
    def _load_all(self):
        if not self.persist_dir: return
        for f in Path(self.persist_dir).glob("*.json"):
            try:
                data=json.loads(f.read_text())
                for d in data:
                    e=VectorEntry.from_dict(d); self.upsert(e.doc_id,e.content,e.embedding,f.stem,e.metadata)
            except: pass
    def _get_or_create(self,ns)->_HNSW:
        if ns not in self._idx: self._idx[ns]=_HNSW(self.dim,self.metric)
        return self._idx[ns]
    def _rebuild(self,ns):
        ni=_HNSW(self.dim,self.metric)
        for e in self._ent.get(ns,{}).values(): ni.add(e.doc_id,np.array(e.embedding,dtype=np.float32))
        self._idx[ns]=ni
