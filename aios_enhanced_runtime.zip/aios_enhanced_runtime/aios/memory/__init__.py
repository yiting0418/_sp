"""
aios.memory
────────────
三層記憶體子系統。

  WorkingMemory   — 上下文視窗，token 預算制，推論結束即消失
  EpisodicMemory  — 對話 / 工作階段歷史，時序索引，跨輪持久化
  SemanticMemory  — 長期知識庫，向量相似度索引，跨代理可共享

MemorySubsystem 是 L5 Syscall 呼叫的統一介面。
"""

from __future__ import annotations

import hashlib
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable

import numpy as np

from aios.core.models import MemoryEntry, MemoryScope, MemoryTier


# ════════════════════════════════════════════════════════════════════
# 嵌入向量工具
# ════════════════════════════════════════════════════════════════════

def _deterministic_embed(text: str, dim: int = 128) -> list[float]:
    """
    Phase 1 用的確定性偽嵌入。
    - 同一文字永遠產生相同向量
    - 相似文字（字符頻率接近）向量較近
    - 不需要 GPU / 模型推論
    Phase 2 替換為真實 embedding API。
    """
    seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2 ** 32)
    rng  = np.random.default_rng(seed)

    # 字符頻率特徵（前 128 個 ASCII）
    freq = np.zeros(128, dtype=np.float32)
    for ch in text.lower():
        if ord(ch) < 128:
            freq[ord(ch)] += 1
    if freq.sum() > 0:
        freq /= freq.sum()

    noise = rng.standard_normal(dim).astype(np.float32)
    vec   = noise + np.resize(freq, dim) * 2.0
    norm  = float(np.linalg.norm(vec))
    return (vec / norm).tolist() if norm > 1e-9 else noise.tolist()


def _cosine(a: list[float], b: list[float]) -> float:
    va, vb = np.array(a, np.float32), np.array(b, np.float32)
    denom  = float(np.linalg.norm(va)) * float(np.linalg.norm(vb))
    return float(np.dot(va, vb) / denom) if denom > 1e-9 else 0.0


# ════════════════════════════════════════════════════════════════════
# L1：工作記憶體
# ════════════════════════════════════════════════════════════════════

@dataclass
class WorkingMemory:
    """
    上下文視窗的 OS 抽象。
    以 token 預算為上限；超出時從最舊的條目開始驅逐。
    推論實例結束時整個 Working Memory 消失。
    """
    token_budget: int = 8_000
    _entries:     deque[MemoryEntry] = field(default_factory=deque, init=False)
    _used_tokens: int                = field(default=0, init=False)

    @staticmethod
    def _tokens(text: str) -> int:
        return max(1, len(text) // 4)   # 4 chars ≈ 1 token（粗估）

    def push(
        self,
        content:   str,
        namespace: str,
        metadata:  dict[str, Any] | None = None,
    ) -> MemoryEntry:
        cost = self._tokens(content)
        # 超出預算：從最舊的開始驅逐
        while self._used_tokens + cost > self.token_budget and self._entries:
            evicted = self._entries.popleft()
            self._used_tokens -= self._tokens(evicted.content)

        entry = MemoryEntry(
            content=content,
            metadata=metadata or {},
            tier=MemoryTier.WORKING,
            scope=MemoryScope.PERSONAL,
            namespace=namespace,
        )
        self._entries.append(entry)
        self._used_tokens += cost
        return entry

    def dump(self) -> list[MemoryEntry]:
        return list(self._entries)

    def clear(self) -> None:
        self._entries.clear()
        self._used_tokens = 0

    @property
    def usage(self) -> tuple[int, int]:
        return self._used_tokens, self.token_budget


# ════════════════════════════════════════════════════════════════════
# L2：情節記憶
# ════════════════════════════════════════════════════════════════════

@dataclass
class EpisodicMemory:
    """
    對話 / 工作階段歷史。
    - 插入順序保留
    - 以 namespace + scope 過濾
    - 跨推論輪次持久化
    """
    _store: list[MemoryEntry] = field(default_factory=list, init=False)

    def store(self, entry: MemoryEntry) -> MemoryEntry:
        entry.tier = MemoryTier.EPISODIC
        self._store.append(entry)
        return entry

    def recall_recent(
        self,
        namespace: str,
        scope:     MemoryScope = MemoryScope.PERSONAL,
        n:         int = 20,
    ) -> list[MemoryEntry]:
        """回傳最近的 n 筆，最新的在最前面。"""
        results = [
            e for e in reversed(self._store)
            if e.namespace == namespace and e.scope == scope
        ][:n]
        for e in results:
            e.touch()
        return results

    def recall_all(self, namespace: str) -> list[MemoryEntry]:
        return [e for e in self._store if e.namespace == namespace]

    def count(self) -> int:
        return len(self._store)


# ════════════════════════════════════════════════════════════════════
# L3：語意記憶
# ════════════════════════════════════════════════════════════════════

@dataclass
class SemanticMemory:
    """
    長期知識庫，以 cosine 相似度索引。
    embed_fn 可注入任何真實的 embedding 函式（Phase 2）。
    """
    embed_fn: Callable[[str], list[float]] = field(
        default_factory=lambda: _deterministic_embed,
    )
    _store: list[MemoryEntry] = field(default_factory=list, init=False)

    def store(self, entry: MemoryEntry) -> MemoryEntry:
        entry.tier = MemoryTier.SEMANTIC
        if entry.embedding is None:
            entry.embedding = self.embed_fn(entry.content)
        self._store.append(entry)
        return entry

    def recall(
        self,
        query:     str,
        namespace: str,
        scope:     MemoryScope = MemoryScope.PERSONAL,
        top_k:     int = 5,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryEntry, float]]:
        q_vec = self.embed_fn(query)
        scored: list[tuple[MemoryEntry, float]] = []

        for e in self._store:
            if not self._namespace_visible(e, namespace, scope):
                continue
            if e.embedding is None:
                continue
            score = _cosine(q_vec, e.embedding)
            if score >= min_score:
                scored.append((e, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        for e, _ in scored[:top_k]:
            e.touch()
        return scored[:top_k]

    def count(self) -> int:
        return len(self._store)

    @staticmethod
    def _namespace_visible(
        entry:     MemoryEntry,
        namespace: str,
        scope:     MemoryScope,
    ) -> bool:
        if scope == MemoryScope.GLOBAL:
            return True
        if entry.namespace == namespace:
            return True
        if scope == MemoryScope.WORKSPACE and entry.scope == MemoryScope.WORKSPACE:
            return True
        return False


# ════════════════════════════════════════════════════════════════════
# 統一介面：MemorySubsystem
# ════════════════════════════════════════════════════════════════════

@dataclass
class MemorySubsystem:
    """
    L5 Syscall 呼叫的統一記憶體介面。
    路由讀寫至正確的記憶體層，並執行去重與排序。
    """
    embed_fn: Callable[[str], list[float]] | None = None

    def __post_init__(self) -> None:
        embed = self.embed_fn or _deterministic_embed
        self.working  = WorkingMemory()
        self.episodic = EpisodicMemory()
        self.semantic = SemanticMemory(embed_fn=embed)

    # ── 寫入 ────────────────────────────────────────────────────────

    def store(
        self,
        content:   str,
        namespace: str,
        scope:     MemoryScope = MemoryScope.PERSONAL,
        tier:      MemoryTier  = MemoryTier.EPISODIC,
        metadata:  dict[str, Any] | None = None,
    ) -> MemoryEntry:
        entry = MemoryEntry(
            content=content,
            metadata=metadata or {},
            scope=scope,
            namespace=namespace,
            tier=tier,
        )
        match tier:
            case MemoryTier.WORKING:
                return self.working.push(content, namespace, metadata)
            case MemoryTier.EPISODIC:
                return self.episodic.store(entry)
            case MemoryTier.SEMANTIC:
                return self.semantic.store(entry)
            case _:
                raise ValueError(f"未知的記憶體層: {tier}")

    # ── 讀取 ────────────────────────────────────────────────────────

    def recall(
        self,
        query:     str,
        namespace: str,
        scope:     MemoryScope = MemoryScope.PERSONAL,
        top_k:     int = 5,
        tiers:     list[MemoryTier] | None = None,
    ) -> list[MemoryEntry]:
        """
        複合查詢三層記憶體，合併去重，按相關性排序。
        若未指定 tiers，預設查詢 EPISODIC + SEMANTIC。
        """
        tiers = tiers or [MemoryTier.EPISODIC, MemoryTier.SEMANTIC]
        candidates: list[MemoryEntry] = []

        if MemoryTier.WORKING in tiers:
            candidates.extend(self.working.dump())

        if MemoryTier.EPISODIC in tiers:
            candidates.extend(
                self.episodic.recall_recent(namespace, scope, n=top_k)
            )

        if MemoryTier.SEMANTIC in tiers:
            hits = self.semantic.recall(query, namespace, scope, top_k=top_k)
            candidates.extend(e for e, _ in hits)

        # 去重（保留第一次出現）
        seen: set[str] = set()
        unique: list[MemoryEntry] = []
        for e in candidates:
            if e.id not in seen:
                seen.add(e.id)
                unique.append(e)

        return unique[:top_k]

    # ── 統計 ────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        used, budget = self.working.usage
        return {
            "working_tokens_used":   used,
            "working_token_budget":  budget,
            "episodic_count":        self.episodic.count(),
            "semantic_count":        self.semantic.count(),
        }
