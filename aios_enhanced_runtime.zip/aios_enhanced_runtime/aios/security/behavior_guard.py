"""
aios.security.behavior_guard
─────────────────────────────
L4 Phase 2 動態防護層。

設計前提（來自設計文件）：
  Phase 2 引入動態防護模型的四個前提條件：
    1. 有足夠真實行為日誌可訓練分類器
    2. 分類器運行在完全隔離的行程，不接受任何來自 Agent 的輸入
    3. 動態模型的 PERMIT 不能覆蓋 ABAC 的 DENY（只能補充）
    4. 動態模型的輸出攜帶可解釋的判斷理由

Phase 2 實作策略：
  以「隔離佇列 + 規則式行為分析器」模擬動態防護，
  不依賴真實的外部 LLM（避免「防護模型本身是攻擊面」）。

  行為分析器依據行為序列的統計特徵判斷是否異常：
    - Syscall 時間間隔的異常（突發）
    - 工具呼叫模式的偏離（宣告 vs 實際）
    - 記憶體存取的範圍擴散（逐步探測邊界）
    - 跨 namespace 讀取的頻率

  Phase 3 可將分析器替換為真實的隔離行程 ML 分類器。

關鍵約束：
  BehaviorGuard.analyze() 的輸入只來自核心發布的 BehaviorEvent，
  永遠不接受 Agent 生成的任何文字內容。
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models_p2 import BehaviorEvent, BehaviorEventType


# ════════════════════════════════════════════════════════════════════
# 行為分析結果
# ════════════════════════════════════════════════════════════════════

@dataclass
class BehaviorVerdict:
    """
    動態防護層的分析結果。
    verdict=True 表示行為正常；verdict=False 表示偵測到異常。
    不能覆蓋 ABAC 的 DENY——只能在 ABAC PERMIT 之後補充檢查。
    """
    instance_id: str
    verdict:     bool         # True = 正常；False = 異常
    confidence:  float        # 0.0–1.0
    reason:      str
    signals:     list[str]    = field(default_factory=list)
    timestamp:   datetime     = field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# 行為特徵（每個 instance 維護）
# ════════════════════════════════════════════════════════════════════

@dataclass
class BehaviorProfile:
    """一個 Agent instance 的行為統計特徵。"""
    instance_id:     str
    # Syscall 時間戳（用於突發偵測）
    syscall_times:   deque = field(default_factory=lambda: deque(maxlen=100))
    # 各類型 Syscall 的計數
    syscall_counts:  dict[str, int] = field(default_factory=dict)
    # 實際呼叫的工具（vs 宣告的 declared_actions）
    tools_called:    set[str] = field(default_factory=set)
    # 嘗試的 namespace（用於範圍擴散偵測）
    namespaces_attempted: set[str] = field(default_factory=set)
    # 連續失敗的存取嘗試
    consecutive_denials:  int = 0
    # 首次事件時間
    first_seen:      float = field(default_factory=time.monotonic)
    last_event:      float = field(default_factory=time.monotonic)


# ════════════════════════════════════════════════════════════════════
# Behavior Guard
# ════════════════════════════════════════════════════════════════════

class BehaviorGuard:
    """
    L4 動態行為防護。

    架構保證：
      - 輸入：只接受核心發布的 BehaviorEvent（結構化事件，非 Agent 文字）
      - 輸出：BehaviorVerdict（補充判斷，不覆蓋 ABAC）
      - 分析在「隔離佇列」中非同步進行，不在請求熱路徑上

    Phase 2 規則集：
      R1 突發偵測   — 短時間內 Syscall 數超過閾值
      R2 工具漂移   — 呼叫了未在 declared_actions 中宣告的工具
      R3 namespace 探測 — 在多個不同 namespace 上發生 scope_attempt
      R4 連續拒絕   — 連續多次被 ABAC 拒絕（可能在試探邊界）
      R5 非活躍異常 — 長時間無活動後突然高頻 Syscall
    """

    # 閾值設定
    BURST_WINDOW_SEC   = 5.0
    BURST_THRESHOLD    = 15      # R1：5 秒內 > 15 次
    DRIFT_THRESHOLD    = 3       # R2：超出宣告工具 3 次
    NAMESPACE_PROBE    = 4       # R3：嘗試 4 個不同 namespace
    CONSECUTIVE_DENY   = 5       # R4：連續 5 次拒絕
    INACTIVITY_SEC     = 60.0    # R5：超過 60 秒無活動
    BURST_AFTER_IDLE   = 10      # R5：靜止後 5 秒內 > 10 次

    def __init__(self) -> None:
        self._profiles:   dict[str, BehaviorProfile] = {}
        self._event_queue: deque[BehaviorEvent]       = deque(maxlen=10_000)
        self._verdicts:   dict[str, list[BehaviorVerdict]] = defaultdict(list)

    # ── 事件接收（由核心發布）────────────────────────────────────────

    def publish(self, event: BehaviorEvent) -> None:
        """
        核心發布行為事件。
        BehaviorGuard 不接受任何來自 Agent 的直接輸入——
        只接受核心在驗證後發布的結構化事件。
        """
        self._event_queue.append(event)
        self._update_profile(event)

    def analyze(self, instance_id: str) -> BehaviorVerdict:
        """
        分析指定 instance 的行為特徵，回傳 BehaviorVerdict。
        在 ABAC PERMIT 之後作為補充檢查呼叫。
        """
        profile = self._profiles.get(instance_id)
        if profile is None:
            return BehaviorVerdict(
                instance_id=instance_id,
                verdict=True,
                confidence=1.0,
                reason="無行為記錄，允許",
            )

        signals:    list[str] = []
        risk_score: float     = 0.0

        # R1：突發偵測
        now = time.monotonic()
        recent = sum(1 for t in profile.syscall_times if now - t < self.BURST_WINDOW_SEC)
        if recent > self.BURST_THRESHOLD:
            signals.append(f"R1_BURST: {recent} syscalls in {self.BURST_WINDOW_SEC}s")
            risk_score += 0.4

        # R2：工具漂移（Phase 2 存根：工具名稱未對照 declared_actions，因為 guard 不持有 token）
        # 在完整實作中，此處比對 profile.tools_called vs token.declared_actions
        # Phase 2：若呼叫工具數 > 5 種視為潛在漂移
        if len(profile.tools_called) > 5:
            signals.append(f"R2_TOOL_DRIFT: {len(profile.tools_called)} distinct tools")
            risk_score += 0.2

        # R3：namespace 探測
        if len(profile.namespaces_attempted) >= self.NAMESPACE_PROBE:
            signals.append(f"R3_NS_PROBE: {len(profile.namespaces_attempted)} namespaces")
            risk_score += 0.3

        # R4：連續拒絕
        if profile.consecutive_denials >= self.CONSECUTIVE_DENY:
            signals.append(f"R4_CONSEC_DENY: {profile.consecutive_denials} denials")
            risk_score += 0.5

        # R5：靜止後突發
        idle_time = profile.last_event - profile.first_seen
        if idle_time > self.INACTIVITY_SEC and recent > self.BURST_AFTER_IDLE:
            signals.append(f"R5_IDLE_BURST: idle={idle_time:.0f}s then {recent} calls")
            risk_score += 0.3

        risk_score = min(risk_score, 1.0)
        verdict    = risk_score < 0.6   # 風險分數 < 0.6 才允許

        result = BehaviorVerdict(
            instance_id=instance_id,
            verdict=verdict,
            confidence=1.0 - risk_score,
            reason="正常" if verdict else f"風險分數 {risk_score:.2f}，信號: {'; '.join(signals)}",
            signals=signals,
        )
        self._verdicts[instance_id].append(result)
        return result

    # ── 查詢 ─────────────────────────────────────────────────────────

    def get_verdicts(self, instance_id: str) -> list[BehaviorVerdict]:
        return list(self._verdicts.get(instance_id, []))

    def profile_of(self, instance_id: str) -> BehaviorProfile | None:
        return self._profiles.get(instance_id)

    def queue_depth(self) -> int:
        return len(self._event_queue)

    # ── 內部 ─────────────────────────────────────────────────────────

    def _update_profile(self, event: BehaviorEvent) -> None:
        if event.instance_id not in self._profiles:
            self._profiles[event.instance_id] = BehaviorProfile(
                instance_id=event.instance_id
            )
        p = self._profiles[event.instance_id]
        now = time.monotonic()

        p.syscall_times.append(now)
        p.syscall_counts[event.event_type.value] = (
            p.syscall_counts.get(event.event_type.value, 0) + 1
        )
        p.last_event = now

        if event.event_type == BehaviorEventType.TOOL_CALL:
            p.tools_called.add(event.syscall_name)

        if event.event_type == BehaviorEventType.SCOPE_ATTEMPT:
            p.namespaces_attempted.add(event.scope)

        if not event.success:
            p.consecutive_denials += 1
        else:
            p.consecutive_denials = 0
