"""
aios.security.policy
─────────────────────
L4 安全層：三道防線的實作。

  第一道 [硬邊界] ABAC 能力令牌比對          O(1)，不可繞過
  第二道 [軟邊界] 結構化意圖白名單比對        O(1)，spawn 時鎖定
  第三道 [監控]  行為異常計數規則            O(1)，可審計

設計決策：Phase 1 不引入動態防護模型。
原因：
  1. 動態模型在熱路徑上，延遲無法接受（50–500ms / Syscall）
  2. 防護模型本身對提示注入脆弱（防護攻擊面即攻擊面）
  3. 決策過程不可審計，Phase 1 除錯代價高
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from dataclasses import dataclass, field

from aios.core.models import (
    Capability,
    MemoryScope,
    MemoryTier,
    PolicyDecision,
    TrustToken,
)
from aios.security.token import TokenIssuer


# ════════════════════════════════════════════════════════════════════
# 能力 → 允許的 MemoryScope 映射
# ════════════════════════════════════════════════════════════════════

_READ_CAP: dict[MemoryScope, Capability] = {
    MemoryScope.PERSONAL:  Capability.MEM_READ_PERSONAL,
    MemoryScope.WORKSPACE: Capability.MEM_READ_WORKSPACE,
    MemoryScope.GLOBAL:    Capability.MEM_READ_GLOBAL,
}
_WRITE_CAP: dict[MemoryScope, Capability] = {
    MemoryScope.PERSONAL:  Capability.MEM_WRITE_PERSONAL,
    MemoryScope.WORKSPACE: Capability.MEM_WRITE_WORKSPACE,
    MemoryScope.GLOBAL:    Capability.MEM_WRITE_WORKSPACE,  # GLOBAL write = WORKSPACE cap
}


# ════════════════════════════════════════════════════════════════════
# 異常計數器
# ════════════════════════════════════════════════════════════════════

@dataclass
class AnomalyRule:
    name:         str
    max_count:    int          # 時間視窗內允許的最大次數
    window_sec:   float        # 時間視窗長度（秒）
    consequence:  str          # "warn" | "suspend" | "terminate"


@dataclass
class AnomalyTracker:
    """
    為每個 instance_id 維護一個滑動視窗事件佇列。
    所有計數操作為 O(1) amortized。
    """
    rules: list[AnomalyRule] = field(default_factory=lambda: [
        AnomalyRule("syscall_burst",      max_count=20, window_sec=10,  consequence="warn"),
        AnomalyRule("scope_escalation",   max_count=3,  window_sec=60,  consequence="suspend"),
        AnomalyRule("forbidden_attempt",  max_count=1,  window_sec=300, consequence="terminate"),
    ])
    _windows: dict[str, dict[str, deque]] = field(
        default_factory=lambda: defaultdict(lambda: defaultdict(deque)),
        init=False,
    )

    def record(self, instance_id: str, event: str) -> str | None:
        """
        記錄一個事件。
        若觸發任一規則，回傳 consequence 字串；否則回傳 None。
        """
        now = time.monotonic()
        for rule in self.rules:
            if rule.name != event:
                continue
            q = self._windows[instance_id][rule.name]
            q.append(now)
            # 滑出視窗外的事件
            while q and (now - q[0]) > rule.window_sec:
                q.popleft()
            if len(q) >= rule.max_count:
                return rule.consequence
        return None

    def counts(self, instance_id: str) -> dict[str, int]:
        now = time.monotonic()
        result: dict[str, int] = {}
        for rule in self.rules:
            q = self._windows[instance_id][rule.name]
            result[rule.name] = sum(1 for t in q if (now - t) <= rule.window_sec)
        return result


# ════════════════════════════════════════════════════════════════════
# Policy Engine — 三道防線的協調者
# ════════════════════════════════════════════════════════════════════

@dataclass
class PolicyEngine:
    issuer:  TokenIssuer
    anomaly: AnomalyTracker = field(default_factory=AnomalyTracker)

    # 決策快取：key → (decision, monotonic_time)
    _cache:  dict[str, tuple[PolicyDecision, float]] = field(
        default_factory=dict, init=False,
    )
    CACHE_TTL: float = field(default=5.0, init=False)  # 秒

    # ── 公開 check API ───────────────────────────────────────────────

    def check_memory_read(
        self,
        token:     TrustToken,
        namespace: str,
        scope:     MemoryScope,
    ) -> PolicyDecision:
        key = f"mem_read|{token.instance_id}|{namespace}|{scope}"
        if cached := self._from_cache(key):
            return cached

        d = (
            self._check_token_valid(token)
            or self._check_capability(token, _READ_CAP[scope], "memory:read")
            or self._check_scope(token, scope)
            or self._check_namespace_read(token, namespace, scope)
            or self._check_intent_whitelist(token, "mem_recall")
            or _permit("abac")
        )
        self._cache[key] = (d, time.monotonic())
        return d

    def check_memory_write(
        self,
        token:     TrustToken,
        namespace: str,
        scope:     MemoryScope,
    ) -> PolicyDecision:
        key = f"mem_write|{token.instance_id}|{namespace}|{scope}"
        if cached := self._from_cache(key):
            return cached

        d = (
            self._check_token_valid(token)
            or self._check_capability(token, _WRITE_CAP[scope], "memory:write")
            or self._check_scope(token, scope)
            or self._check_namespace_write(token, namespace, scope)
            or self._check_intent_whitelist(token, "mem_store")
            or _permit("abac")
        )
        self._cache[key] = (d, time.monotonic())
        return d

    def check_tool_call(
        self,
        token:        TrustToken,
        tool_name:    str,
        required_cap: Capability,
    ) -> PolicyDecision:
        key = f"tool|{token.instance_id}|{tool_name}"
        if cached := self._from_cache(key):
            return cached

        # forbidden_actions 必須在 capability check 之前驗證：
        # 即使代理缺少能力，forbidden_attempt 仍應被記錄進異常計數器。
        d = (
            self._check_token_valid(token)
            or self._check_intent_whitelist(token, f"tool:{tool_name}")  # forbidden 優先
            or self._check_capability(token, required_cap, f"tool:{tool_name}")
            or self._check_intent_whitelist(token, "tool_call")
            or _permit("abac")
        )
        self._cache[key] = (d, time.monotonic())
        return d

    def check_kb_operation(
        self,
        token:      TrustToken,
        operation:  str,              # "search" | "index" | "broadcast"
    ) -> PolicyDecision:
        cap_map = {
            "search":    Capability.KB_SEARCH,
            "index":     Capability.KB_INDEX,
            "broadcast": Capability.KB_BROADCAST,
        }
        syscall_map = {
            "search":    "kb_search",
            "index":     "kb_index",
            "broadcast": "kb_broadcast",
        }
        cap = cap_map.get(operation)
        if cap is None:
            return _deny("abac", f"未知的 KB 操作: {operation}")

        key = f"kb|{token.instance_id}|{operation}"
        if cached := self._from_cache(key):
            return cached

        d = (
            self._check_token_valid(token)
            or self._check_capability(token, cap, f"kb:{operation}")
            or self._check_intent_whitelist(token, syscall_map[operation])
            or _permit("abac")
        )
        self._cache[key] = (d, time.monotonic())
        return d

    def check_iac(
        self,
        token:   TrustToken,
        syscall: str,           # "ctx_handoff" | "kb_broadcast" | "agent_spawn"
    ) -> PolicyDecision:
        cap_map = {
            "ctx_handoff":   Capability.CTX_HANDOFF,
            "kb_broadcast":  Capability.KB_BROADCAST,
            "agent_spawn":   Capability.AGENT_SPAWN_CHILD,
        }
        cap = cap_map.get(syscall)
        if cap is None:
            return _deny("abac", f"未知的 IAC syscall: {syscall}")

        d = (
            self._check_token_valid(token)
            or self._check_capability(token, cap, syscall)
            or self._check_intent_whitelist(token, syscall)
            or _permit("abac")
        )
        return d

    # ── 行為異常事件記錄 ────────────────────────────────────────────

    def record_syscall(self, token: TrustToken) -> PolicyDecision | None:
        """每次 Syscall 都呼叫；若觸發 syscall_burst 規則回傳非 None。"""
        consequence = self.anomaly.record(token.instance_id, "syscall_burst")
        if consequence:
            return _deny("anomaly", f"syscall_burst 觸發，後果: {consequence}")
        return None

    def record_scope_escalation(self, token: TrustToken) -> PolicyDecision | None:
        consequence = self.anomaly.record(token.instance_id, "scope_escalation")
        if consequence:
            return _deny("anomaly", f"scope_escalation 觸發，後果: {consequence}")
        return None

    def record_forbidden_attempt(self, token: TrustToken) -> PolicyDecision:
        self.anomaly.record(token.instance_id, "forbidden_attempt")
        return _deny("anomaly", "forbidden_actions 嘗試，立即終止")

    def anomaly_counts(self, instance_id: str) -> dict[str, int]:
        return self.anomaly.counts(instance_id)

    # ── 內部防線實作 ─────────────────────────────────────────────────

    def _check_token_valid(self, token: TrustToken) -> PolicyDecision | None:
        if not self.issuer.is_valid(token):
            return _deny("abac", "令牌已被撤銷")
        return None

    def _check_capability(
        self,
        token: TrustToken,
        cap:   Capability,
        action: str,
    ) -> PolicyDecision | None:
        if cap not in token.capabilities:
            return _deny("abac", f"缺少能力 '{cap.value}'，無法執行 '{action}'")
        return None

    def _check_scope(
        self,
        token: TrustToken,
        scope: MemoryScope,
    ) -> PolicyDecision | None:
        if not token.allows_scope(scope):
            self.record_scope_escalation(token)
            return _deny("abac", f"scope '{scope}' 超過 max_scope '{token.max_scope}'")
        return None

    def _check_namespace_read(
        self,
        token:     TrustToken,
        namespace: str,
        scope:     MemoryScope,
    ) -> PolicyDecision | None:
        if scope == MemoryScope.GLOBAL:
            return None  # GLOBAL 的 namespace 驗證由能力控制
        if namespace == token.instance_id:
            return None  # 讀自己的記憶體，永遠允許（前提是有 cap）
        if scope == MemoryScope.WORKSPACE and namespace == token.workspace_id:
            return None  # 讀同工作區的記憶體
        return _deny("abac", f"無權讀取 namespace '{namespace}'")

    def _check_namespace_write(
        self,
        token:     TrustToken,
        namespace: str,
        scope:     MemoryScope,
    ) -> PolicyDecision | None:
        if namespace == token.instance_id:
            return None
        if scope == MemoryScope.WORKSPACE and namespace == token.workspace_id:
            return None
        return _deny("abac", f"無權寫入 namespace '{namespace}'")

    def _check_intent_whitelist(
        self,
        token:       TrustToken,
        syscall_name: str,
    ) -> PolicyDecision | None:
        ok, reason = token.action_permitted(syscall_name)
        if not ok:
            # 如果是明確禁止，記錄為 forbidden_attempt
            if syscall_name in token.forbidden_actions:
                self.record_forbidden_attempt(token)
            return _deny("intent_whitelist", reason)
        return None

    # ── 快取輔助 ─────────────────────────────────────────────────────

    def _from_cache(self, key: str) -> PolicyDecision | None:
        if key in self._cache:
            decision, ts = self._cache[key]
            if time.monotonic() - ts < self.CACHE_TTL:
                return PolicyDecision(
                    permitted=decision.permitted,
                    reason=decision.reason,
                    layer=decision.layer,
                    cached=True,
                )
        return None

    def invalidate_cache(self, instance_id: str) -> None:
        """撤銷令牌時清除其所有快取決策。"""
        drop = [k for k in self._cache if k.split("|")[1] == instance_id]
        for k in drop:
            del self._cache[k]


# ════════════════════════════════════════════════════════════════════
# 工廠函式
# ════════════════════════════════════════════════════════════════════

def _permit(layer: str) -> PolicyDecision:
    return PolicyDecision(permitted=True, reason="所有防線通過", layer=layer)

def _deny(layer: str, reason: str) -> PolicyDecision:
    return PolicyDecision(permitted=False, reason=reason, layer=layer)
