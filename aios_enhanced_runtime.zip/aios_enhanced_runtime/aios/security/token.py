"""
aios.security.token
────────────────────
TokenIssuer：OS 核心唯一的令牌簽發機構。
Phase 1 為 in-process 實作；未來可替換為 HSM 或遠端簽發服務。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from aios.core.models import (
    AgentSpec,
    Capability,
    MemoryScope,
    TrustToken,
)


@dataclass
class TokenIssuer:
    """
    簽發、驗證、撤銷 TrustToken。

    所有 agent_spawn 都必須經過這裡；
    沒有其他方式能取得合法的 TrustToken。
    """
    system_id: str = "aios-kernel-v1"
    _revoked:  set[str] = field(default_factory=set, init=False)

    # ── 簽發 ────────────────────────────────────────────────────────

    def issue(self, spec: AgentSpec) -> TrustToken:
        """根據 AgentSpec 簽發一枚 TrustToken。"""
        return TrustToken(
            instance_id=_new_id(),
            owner=spec.owner,
            workspace_id=spec.workspace_id,
            capabilities=frozenset(spec.capabilities),
            max_scope=spec.max_scope,
            declared_actions=frozenset(spec.declared_actions),
            forbidden_actions=frozenset(spec.forbidden_actions),
            intent_hash=spec.intent_hash(),
        )

    def issue_child(
        self,
        parent_token: TrustToken,
        child_spec:   AgentSpec,
    ) -> TrustToken:
        """
        子代理令牌：能力集合不可超過父代理。
        父代理必須持有 AGENT_SPAWN_CHILD 能力。
        """
        if Capability.AGENT_SPAWN_CHILD not in parent_token.capabilities:
            raise PermissionError("父代理缺少 AGENT_SPAWN_CHILD 能力")

        # 子代理的能力 ⊆ 父代理的能力
        child_caps = frozenset(child_spec.capabilities) & parent_token.capabilities

        # 子代理的 max_scope ≤ 父代理的 max_scope
        scope_order = [MemoryScope.PERSONAL, MemoryScope.WORKSPACE, MemoryScope.GLOBAL]
        child_scope = (
            child_spec.max_scope
            if scope_order.index(child_spec.max_scope) <= scope_order.index(parent_token.max_scope)
            else parent_token.max_scope
        )

        return TrustToken(
            instance_id=_new_id(),
            owner=child_spec.owner,
            workspace_id=child_spec.workspace_id or parent_token.workspace_id,
            capabilities=child_caps,
            max_scope=child_scope,
            declared_actions=frozenset(child_spec.declared_actions),
            forbidden_actions=frozenset(child_spec.forbidden_actions),
            intent_hash=child_spec.intent_hash(),
        )

    # ── 驗證 / 撤銷 ─────────────────────────────────────────────────

    def is_valid(self, token: TrustToken) -> bool:
        return token.instance_id not in self._revoked

    def revoke(self, instance_id: str) -> None:
        self._revoked.add(instance_id)

    def revoke_token(self, token: TrustToken) -> None:
        self._revoked.add(token.instance_id)

    @property
    def revoked_count(self) -> int:
        return len(self._revoked)


def _new_id() -> str:
    import uuid
    return uuid.uuid4().hex
