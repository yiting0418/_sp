"""aios.sandbox.isolate — multi-layer sandbox isolation"""
from __future__ import annotations
import io, os, sys, time, threading, traceback, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable
from aios.observability import SANDBOX_VIOLATIONS, get_bus, SystemEvent, EventSeverity

class SandboxPolicy(str, Enum):
    OPEN="open"; STANDARD="standard"; STRICT="strict"; PARANOID="paranoid"

class ViolationType(str, Enum):
    IMPORT_DENIED="import_denied"; FS_ESCAPE="fs_escape"; NETWORK_DENIED="network_denied"
    CPU_TIMEOUT="cpu_timeout"; OUTPUT_OVERFLOW="output_overflow"; DUNDER_ACCESS="dunder_access"

@dataclass
class SandboxViolation:
    violation_type:ViolationType; instance_id:str; detail:str
    timestamp:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    def __str__(self): return f"[VIOLATION:{self.violation_type.value}] {self.detail}"

@dataclass
class ResourceLimits:
    cpu_time_sec:float=30.0; max_output_bytes:int=256*1024
    allow_imports:bool=True; allow_network:bool=True; allow_dunder:bool=True
    allowed_domains:frozenset=field(default_factory=frozenset)
    fs_jail:str="/tmp/aios_workspace"

_PL={
    SandboxPolicy.OPEN:     ResourceLimits(60,1024*1024,True,True,True),
    SandboxPolicy.STANDARD: ResourceLimits(30,256*1024,True,True,False,frozenset(["api.anthropic.com","pypi.org"])),
    SandboxPolicy.STRICT:   ResourceLimits(10,64*1024,False,False,False),
    SandboxPolicy.PARANOID: ResourceLimits(5,16*1024,False,False,False),
}

_BT_NAMES=["print","len","range","enumerate","zip","map","filter","sorted","reversed","sum",
           "min","max","abs","round","int","float","str","bool","list","dict","tuple","set",
           "type","repr","isinstance","hasattr","any","all","hex","bin","chr","ord","format","hash"]
_SB={}
for _n in _BT_NAMES:
    try: _SB[_n]=eval(_n)
    except: pass

@dataclass
class ExecutionResult:
    success:bool; output:Any; stdout:str=""; duration_ms:float=0.0
    error:str|None=None; violation:SandboxViolation|None=None

class _TO(Exception): pass

class Sandbox:
    def __init__(self,iid:str,policy:SandboxPolicy=SandboxPolicy.STANDARD):
        self.instance_id=iid; self.policy=policy; self.limits=_PL[policy]
        self.violations:list[SandboxViolation]=[]
        self._jail=os.path.join(self.limits.fs_jail,iid)
        os.makedirs(self._jail,exist_ok=True); self._bus=get_bus()
    def execute(self,handler:Callable,args:dict)->ExecutionResult:
        t0=time.perf_counter()
        v=self._inspect(args)
        if v: return self._vr(v,t0)
        try: res=self._timed(handler,args)
        except _TO: return self._vr(self._rec(ViolationType.CPU_TIMEOUT,f">{self.limits.cpu_time_sec}s"),t0)
        except Exception as e: return ExecutionResult(False,None,error=traceback.format_exc(limit=4),duration_ms=(time.perf_counter()-t0)*1000)
        return ExecutionResult(True,res.get("output"),stdout=res.get("stdout",""),duration_ms=(time.perf_counter()-t0)*1000)
    def execute_code(self,code:str)->ExecutionResult:
        t0=time.perf_counter()
        if not self.limits.allow_imports and("import " in code or "__import__" in code):
            return self._vr(self._rec(ViolationType.IMPORT_DENIED,"import blocked"),t0)
        if not self.limits.allow_dunder and "__" in code:
            return self._vr(self._rec(ViolationType.DUNDER_ACCESS,"dunder blocked"),t0)
        buf=io.StringIO(); old,sys.stdout=sys.stdout,buf; lv:dict={}
        try:
            g={"__builtins__":_SB} if not self.limits.allow_imports else {}
            exec(compile(code,"<sandbox>","exec"),g,lv)  # noqa:S102
            out=buf.getvalue()
        except Exception as e:
            sys.stdout=old; return ExecutionResult(False,None,error=str(e),duration_ms=(time.perf_counter()-t0)*1000)
        finally: sys.stdout=old
        return ExecutionResult(True,{"stdout":out,"locals":{k:repr(v) for k,v in lv.items()}},stdout=out,duration_ms=(time.perf_counter()-t0)*1000)
    def jail_path(self,path:str)->str|None:
        real=os.path.realpath(path); jail=os.path.realpath(self._jail)
        if real.startswith(jail): return real
        self._rec(ViolationType.FS_ESCAPE,f"{path} escapes jail"); return None
    def safe_read(self,path:str)->dict:
        j=self.jail_path(path)
        if j is None: return {"error":"access denied"}
        try:
            with open(j) as f: return {"content":f.read()}
        except FileNotFoundError: return {"error":f"not found:{j}"}
    def safe_write(self,path:str,content:str)->dict:
        j=self.jail_path(path)
        if j is None: return {"error":"access denied"}
        os.makedirs(os.path.dirname(j) or ".",exist_ok=True)
        with open(j,"w") as f: f.write(content)
        return {"written":len(content),"path":j}
    @property
    def violation_count(self)->int: return len(self.violations)
    def _inspect(self,args)->SandboxViolation|None:
        for k in("path","filepath","file_path"):
            if k in args:
                real=os.path.realpath(str(args[k])); jail=os.path.realpath(self._jail)
                if not real.startswith(jail): return self._rec(ViolationType.FS_ESCAPE,f"{k} escapes jail")
        if not self.limits.allow_network and "url" in args: return self._rec(ViolationType.NETWORK_DENIED,"network blocked")
        if self.limits.allowed_domains and "url" in args:
            from urllib.parse import urlparse
            host=urlparse(str(args["url"])).hostname or ""
            if not any(host.endswith(d) for d in self.limits.allowed_domains):
                return self._rec(ViolationType.NETWORK_DENIED,f"{host} not allowed")
        return None
    def _timed(self,handler,args)->dict:
        res:dict={}; exc:list=[]
        def _r():
            try: res["output"]=handler(**args)
            except Exception as e: exc.append(e)
        t=threading.Thread(target=_r,daemon=True); t.start()
        t.join(timeout=self.limits.cpu_time_sec)
        if t.is_alive(): raise _TO()
        if exc: raise exc[0]
        return res
    def _rec(self,vt,detail)->SandboxViolation:
        v=SandboxViolation(vt,self.instance_id,detail); self.violations.append(v)
        SANDBOX_VIOLATIONS.inc()
        self._bus.emit(SystemEvent("sandbox.violation","Sandbox",EventSeverity.WARN,{"type":vt.value,"inst":self.instance_id,"detail":detail}))
        return v
    def _vr(self,v,t0)->ExecutionResult:
        return ExecutionResult(False,None,error=str(v),violation=v,duration_ms=(time.perf_counter()-t0)*1000)

class SandboxRegistry:
    def __init__(self,dp:SandboxPolicy=SandboxPolicy.STANDARD):
        self._s:dict[str,Sandbox]={}; self._dp=dp; self._lk=threading.Lock()
    def get(self,iid:str,policy:SandboxPolicy|None=None)->Sandbox:
        with self._lk:
            if iid not in self._s: self._s[iid]=Sandbox(iid,policy or self._dp)
            return self._s[iid]
    def remove(self,iid):
        with self._lk: self._s.pop(iid,None)
    def total_violations(self)->int: return sum(s.violation_count for s in self._s.values())
    def report(self)->list:
        with self._lk: return [{"instance":s.instance_id,"policy":s.policy.value,"violations":s.violation_count,"jail":s._jail} for s in self._s.values()]
