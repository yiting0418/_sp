"""aios.observability — metrics, tracing, event bus, dashboard"""
from __future__ import annotations
import time, threading, uuid
from collections import defaultdict, deque
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

class MetricType(str, Enum):
    COUNTER="counter"; GAUGE="gauge"; HISTOGRAM="histogram"

@dataclass
class Metric:
    name:str; type:MetricType; help:str; labels:dict=field(default_factory=dict)
    _v:float=field(default=0.0,init=False); _bkts:list=field(default_factory=list,init=False)
    _sum:float=field(default=0.0,init=False); _cnt:int=field(default=0,init=False)
    _lk:threading.Lock=field(default_factory=threading.Lock,init=False)
    def inc(self,v=1.0):
        with self._lk: self._v+=v
    def dec(self,v=1.0):
        with self._lk: self._v-=v
    def set(self,v):
        with self._lk: self._v=v
    def observe(self,v):
        with self._lk:
            self._sum+=v; self._cnt+=1
            for i,(le,c) in enumerate(self._bkts):
                if v<=le: self._bkts[i]=(le,c+1)
    def get(self)->float: return self._v
    def summary(self)->dict:
        with self._lk:
            if self.type==MetricType.HISTOGRAM:
                return {"sum":self._sum,"count":self._cnt,"avg":self._sum/self._cnt if self._cnt else 0.0}
            return {"value":self._v}

class MetricRegistry:
    _B=[0.001,0.005,0.01,0.05,0.1,0.5,1.0,5.0,10.0,float("inf")]
    def __init__(self): self._m:dict[str,Metric]={}; self._lk=threading.Lock()
    def _mk(self,n,t,h,lb):
        k=f"{n}_{sorted(lb.items())}"
        with self._lk:
            if k not in self._m:
                m=Metric(n,t,h,lb)
                if t==MetricType.HISTOGRAM: m._bkts=[(le,0) for le in self._B]
                self._m[k]=m
            return self._m[k]
    def counter(self,n,h="",**lb): return self._mk(n,MetricType.COUNTER,h,lb)
    def gauge(self,n,h="",**lb):   return self._mk(n,MetricType.GAUGE,h,lb)
    def histogram(self,n,h="",**lb):return self._mk(n,MetricType.HISTOGRAM,h,lb)
    def snapshot(self)->dict:
        with self._lk: return {k:{"name":m.name,"type":m.type.value,**m.summary()} for k,m in self._m.items()}

@dataclass
class SpanContext:
    trace_id:str=field(default_factory=lambda:uuid.uuid4().hex)
    span_id:str=field(default_factory=lambda:uuid.uuid4().hex[:8])
    parent_id:str|None=None

class Span:
    def __init__(self,name,ctx,tags=None,tracer=None):
        self.name=name;self.ctx=ctx;self.tags=dict(tags or {})
        self.attributes={};self.events=[];self.status="ok";self.error=None
        self._tracer=tracer;self._t0=time.perf_counter();self._end=None
    def set(self,k,v): self.attributes[k]=v; return self
    def add_event(self,n,**a): self.events.append({"name":n,"ms":self.elapsed_ms,**a}); return self
    def set_error(self,e): self.status="error"; self.error=str(e); return self
    @property
    def elapsed_ms(self): return((self._end or time.perf_counter())-self._t0)*1000
    def finish(self):
        self._end=time.perf_counter()
        if self._tracer: self._tracer._record(self)
    def to_dict(self):
        return{"name":self.name,"trace_id":self.ctx.trace_id,"span_id":self.ctx.span_id,
               "parent_id":self.ctx.parent_id,"duration_ms":round(self.elapsed_ms,3),
               "status":self.status,"tags":self.tags,"attributes":self.attributes,"error":self.error}
    def __enter__(self): return self
    def __exit__(self,et,ev,tb):
        if ev: self.set_error(ev)
        self.finish(); return False

class Tracer:
    def __init__(self,mx=10_000):
        self._s:deque[Span]=deque(maxlen=mx); self._lk=threading.Lock()
    def span(self,n,parent=None,tags=None,trace_id=None):
        ctx=SpanContext(trace_id=trace_id or(parent.ctx.trace_id if parent else uuid.uuid4().hex),
                        parent_id=parent.ctx.span_id if parent else None)
        return Span(n,ctx,tags,self)
    @contextmanager
    def start(self,n,parent=None,**tags):
        s=self.span(n,parent,tags)
        try: yield s
        except Exception as e: s.set_error(e); raise
        finally: s.finish()
    def _record(self,s):
        with self._lk: self._s.append(s)
    def recent(self,n=100):
        with self._lk: return [s.to_dict() for s in list(self._s)[-n:]]
    def trace(self,tid):
        with self._lk: return [s.to_dict() for s in self._s if s.ctx.trace_id==tid]
    def stats(self)->dict:
        with self._lk:
            by:dict[str,list]=defaultdict(list)
            for s in self._s: by[s.name].append(s.elapsed_ms)
            return {n:{"count":len(d),"avg_ms":round(sum(d)/len(d),2),"max_ms":round(max(d),2)}
                    for n,d in by.items()}

class EventSeverity(str,Enum):
    DEBUG="debug"; INFO="info"; WARN="warn"; ERROR="error"

@dataclass
class SystemEvent:
    event_type:str; source:str; severity:EventSeverity=EventSeverity.INFO
    payload:dict=field(default_factory=dict)
    timestamp:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    event_id:str=field(default_factory=lambda:uuid.uuid4().hex[:8])

class EventBus:
    def __init__(self,max_events=50_000,mx=None):
        self._ev:deque[SystemEvent]=deque(maxlen=max_events if mx is None else mx)
        self._h:dict[str,list]=defaultdict(list); self._lk=threading.Lock()
    def emit(self,e):
        with self._lk: self._ev.append(e)
        for h in self._h.get(e.event_type,[])+self._h.get("*",[]):
            try: h(e)
            except: pass
    def on(self,t,h):
        with self._lk: self._h[t].append(h)
    def recent(self,n=200,severity=None):
        with self._lk: evs=list(self._ev)[-n:]
        return [e for e in evs if not severity or e.severity==severity]
    def count_by_type(self)->dict:
        with self._lk:
            c:dict[str,int]=defaultdict(int)
            for e in self._ev: c[e.event_type]+=1
            return dict(c)

_registry=MetricRegistry(); _tracer=Tracer(); _bus=EventBus()
SYSCALL_LATENCY=_registry.histogram("aios_syscall_ms","Syscall latency ms")
SYSCALL_TOTAL=_registry.counter("aios_syscall_total","Total syscalls")
AGENT_ACTIVE=_registry.gauge("aios_agents_active","Active agents")
KV_HIT_RATE=_registry.gauge("aios_kv_hit_rate","KV prefix hit rate")
GPU_UTIL=_registry.gauge("aios_gpu_util","GPU utilization")
TOOL_ERRORS=_registry.counter("aios_tool_errors","Tool errors")
CTX_SWITCHES=_registry.counter("aios_ctx_switches","Context switches")
MIGRATIONS=_registry.counter("aios_migrations","Agent migrations")
SANDBOX_VIOLATIONS=_registry.counter("aios_sandbox_violations","Sandbox violations")
INFERENCE_TOKENS=_registry.counter("aios_inference_tokens","Tokens generated")
MEMORY_RECALL_MS=_registry.histogram("aios_mem_recall_ms","Memory recall ms")

def get_registry()->MetricRegistry: return _registry
def get_tracer()->Tracer: return _tracer
def get_bus()->EventBus: return _bus
def record_syscall(n,ms,ok):
    SYSCALL_TOTAL.inc(); SYSCALL_LATENCY.observe(ms)

def render_dashboard(stats:dict)->str:
    sep="─"*60
    now=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    lines=["╔══════════════════════════════════════════════════════════╗",
           "║  AIOS Kernel Dashboard                                   ║",
           f"║  {now:<52}║",
           "╚══════════════════════════════════════════════════════════╝",
           f"\n{sep} AGENTS"]
    for s,c in stats.get("agents",{}).items():
        lines.append(f"  {s:<12} {c:>4}  {'█'*min(c,30)}")
    mem=stats.get("memory",{})
    lines+=[f"\n{sep} MEMORY",
            f"  Working  {mem.get('working_tokens_used',0):>7}/{mem.get('working_token_budget',0)} tokens",
            f"  Episodic {mem.get('episodic_count',0):>7} entries",
            f"  Semantic {mem.get('semantic_count',0):>7} entries"]
    ts=_tracer.stats()
    if ts:
        lines.append(f"\n{sep} SPAN LATENCIES (top 5)")
        for n,s in sorted(ts.items(),key=lambda x:-x[1]["avg_ms"])[:5]:
            lines.append(f"  {n:<30} avg={s['avg_ms']:>7.1f}ms  n={s['count']}")
    errs=_bus.recent(5,EventSeverity.ERROR)
    if errs:
        lines.append(f"\n{sep} RECENT ERRORS")
        for e in errs[-3:]:
            lines.append(f"  [{e.severity.value.upper()}] {e.event_type}: {e.payload.get('msg','')[:50]}")
    lines.append(f"\n{sep}")
    return "\n".join(lines)
