"""
aios.l3a.speculator
────────────────────
Syscall 預測性預取層。

核心元件：
  NGramPredictor    — n-gram 序列預測模型
  SpeculativeCache  — 唯讀 Syscall 結果快取
  SyscallSpeculator — L3a 統一介面

運作流程：
  1. OBSERVE 模式：記錄所有 Syscall 序列，建立 n-gram 模型
  2. PREDICT 模式：在每次 Syscall 後預測下一個 Syscall，預先執行
  3. 若預測命中，直接回傳快取結果（O(1) 延遲）
  4. 若預測失誤，執行真實 Syscall，更新模型

安全限制：
  - 只預取 read-only syscall（mem_recall, kb_search, tool_list）
  - 不預取 mem_store, tool_call, agent_spawn 等有副作用的操作
  - 預取結果設有 TTL，過期後自動失效
"""
from __future__ import annotations

import hashlib
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from aios.core.models_p3 import (
    PrefetchResult,
    SpeculationMode,
    SpeculationPrediction,
    SyscallTrace,
)


# ════════════════════════════════════════════════════════════════════
# n-gram 預測模型
# ════════════════════════════════════════════════════════════════════

class NGramPredictor:
    """
    n-gram 序列預測模型。

    維護一個從「前 n-1 個 syscall 序列」到「下一個 syscall」的
    頻率計數表。預測時選擇歷史中最常出現的後續 syscall。

    不使用 ML 模型——在 Phase 3 的初始版本中，
    輕量級的 n-gram 已足夠捕捉常見的 syscall 模式
    （如 mem_recall → mem_recall → tool_call 的固定序列）。
    """

    def __init__(
        self,
        n: int = 3,
        min_samples: int = 2,    # 至少出現幾次才進行預測
        max_patterns: int = 1000,
    ):
        self._n = n
        self._min_samples = min_samples
        self._max_patterns = max_patterns

        # context_tuple → {next_syscall → count}
        self._ngram: dict[tuple[str, ...], dict[str, int]] = defaultdict(lambda: defaultdict(int))
        # instance_id → deque[SyscallTrace]
        self._traces: dict[str, deque[SyscallTrace]] = defaultdict(
            lambda: deque(maxlen=100),
        )

    def observe(self, trace: SyscallTrace) -> None:
        """記錄一次 syscall 呼叫，更新 n-gram 模型。"""
        self._traces[trace.instance_id].append(trace)

        # 更新 n-gram 計數
        history = self._traces[trace.instance_id]
        if len(history) < self._n:
            return

        # 取前 n-1 個作為 context
        recent = list(history)
        context = tuple(
            recent[-(self._n - 1 + i)].syscall_name
            for i in range(self._n - 1)
        )
        next_syscall = recent[-1].syscall_name
        self._ngram[context][next_syscall] += 1

        # LRU 修剪
        if len(self._ngram) > self._max_patterns:
            oldest_context = next(iter(self._ngram))
            del self._ngram[oldest_context]

    def predict(
        self,
        instance_id: str,
    ) -> SpeculationPrediction:
        """
        預測下一個最可能的 syscall。

        基於最近 n-1 個 syscall 的序列，
        在 n-gram 表中查詢出現頻率最高的下一個。
        """
        history = list(self._traces.get(instance_id, []))
        if len(history) < self._n - 1:
            return SpeculationPrediction(
                predicted_syscall="",
                probability=0.0,
                context_hash=self._context_hash(history),
            )

        recent = history[-(self._n - 1):]
        context = tuple(t.syscall_name for t in recent)

        candidates = self._ngram.get(context, {})
        if not candidates:
            return SpeculationPrediction(
                predicted_syscall="",
                probability=0.0,
                context_hash=self._context_hash(history),
            )

        total = sum(candidates.values())
        best_syscall = max(candidates, key=candidates.get)
        best_count   = candidates[best_syscall]

        if best_count < self._min_samples:
            return SpeculationPrediction(
                predicted_syscall="",
                probability=0.0,
                context_hash=self._context_hash(history),
            )

        return SpeculationPrediction(
            predicted_syscall=best_syscall,
            probability=round(best_count / total, 4),
            context_hash=self._context_hash(history),
            is_read_only=self._is_read_only(best_syscall),
        )

    def clear_instance(self, instance_id: str) -> None:
        self._traces.pop(instance_id, None)

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "ngram_size": len(self._ngram),
            "active_instances": len(self._traces),
            "total_traces": sum(len(q) for q in self._traces.values()),
        }

    @staticmethod
    def _context_hash(history: list[SyscallTrace]) -> str:
        if not history:
            return ""
        last = history[-1]
        return hashlib.sha256(
            f"{last.instance_id}:{last.syscall_name}:{last.context_hash}".encode()
        ).hexdigest()[:12]

    @staticmethod
    def _is_read_only(syscall_name: str) -> bool:
        return syscall_name in (
            "mem_recall",
            "kb_search",
            "tool_list",
            "receive_handoffs",
            "sys_stats",
        )


# ════════════════════════════════════════════════════════════════════
# 唯讀 Syscall 結果快取
# ════════════════════════════════════════════════════════════════════

class SpeculativeCache:
    """
    預先執行的 Syscall 結果快取。

    每個快取條目有 TTL，過期後下次存取自動失效。
    快取 key = syscall_name + args 的 hash。
    """

    def __init__(
        self,
        default_ttl_s: float = 5.0,   # 預取結果預設 5 秒有效
    ):
        self._cache: dict[str, PrefetchResult] = {}
        self._default_ttl = timedelta(seconds=default_ttl_s)
        self._hits  = 0
        self._misses = 0

    def get(self, syscall_name: str, args: dict[str, Any]) -> PrefetchResult | None:
        key = self._make_key(syscall_name, args)
        entry = self._cache.get(key)
        if entry is None or entry.is_expired:
            self._cache.pop(key, None)
            self._misses += 1
            return None
        entry.hit_count += 1
        self._hits += 1
        return entry

    def put(
        self,
        syscall_name: str,
        args:   dict[str, Any],
        result: Any,
        ttl_s: float | None = None,
    ) -> PrefetchResult:
        key = self._make_key(syscall_name, args)
        ttl = ttl_s if ttl_s is not None else self._default_ttl.total_seconds()
        entry = PrefetchResult(
            cache_key=key,
            syscall_name=syscall_name,
            args=args,
            result=result,
            hit_count=0,
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=ttl),
        )
        self._cache[key] = entry
        return entry

    def invalidate(self, syscall_name: str) -> int:
        """使指定 syscall 的所有快取失效。回傳清除的條目數。"""
        before = len(self._cache)
        self._cache = {
            k: v for k, v in self._cache.items()
            if v.syscall_name != syscall_name
        }
        return before - len(self._cache)

    def clear(self) -> None:
        self._cache.clear()
        self._hits = self._misses = 0

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return self._hits / total if total > 0 else 0.0

    @property
    def size(self) -> int:
        return len(self._cache)

    @staticmethod
    def _make_key(syscall_name: str, args: dict[str, Any]) -> str:
        args_str = str(sorted(args.items()))
        return hashlib.sha256(
            f"{syscall_name}:{args_str}".encode()
        ).hexdigest()[:16]


# ════════════════════════════════════════════════════════════════════
# L3a Syscall Speculator
# ════════════════════════════════════════════════════════════════════

class SyscallSpeculator:
    """
    L3a Syscall 預測性預取層。

    三個模式（SpeculationMode）：
      OFF     — 完全穿透，不記錄也不預測
      OBSERVE — 記錄所有 syscall 序列，建立 n-gram 模型，不預取
      PREDICT — 全功能：預測 + 預取 + 快取

    使用方式：
      speculator = SyscallSpeculator()
      speculator.set_mode(SpeculationMode.PREDICT)

      # 每次 syscall 後：
      speculator.observe(trace)
      prediction = speculator.predict(instance_id)
      if prediction.probability > 0.5:
          result = speculator.prefetch(kernel, prediction)
          speculator.cache_result(result)
    """

    def __init__(
        self,
        predictor: NGramPredictor | None = None,
        cache:     SpeculativeCache | None = None,
        mode:      SpeculationMode = SpeculationMode.OBSERVE,
    ):
        self._predictor  = predictor or NGramPredictor()
        self._cache      = cache or SpeculativeCache()
        self._mode       = mode

    # ── 模式控制 ──────────────────────────────────────────────────

    def set_mode(self, mode: SpeculationMode) -> None:
        self._mode = mode

    @property
    def mode(self) -> SpeculationMode:
        return self._mode

    # ── Syscall 觀察與預測 ────────────────────────────────────────

    def observe(self, trace: SyscallTrace) -> None:
        """記錄一次 syscall 呼叫（所有模式皆可記錄）。"""
        if self._mode == SpeculationMode.OFF:
            return
        self._predictor.observe(trace)

    def predict(self, instance_id: str) -> SpeculationPrediction:
        """預測下一個 syscall。"""
        if self._mode != SpeculationMode.PREDICT:
            return SpeculationPrediction()

        return self._predictor.predict(instance_id)

    # ── 預取 ──────────────────────────────────────────────────────

    async def prefetch(
        self,
        kernel:     Any,
        prediction: SpeculationPrediction,
        args_hint:  dict[str, Any] | None = None,
    ) -> PrefetchResult | None:
        """
        執行一次預取。

        只對 read-only syscall 執行。
        若快取中已有相同請求，直接回傳快取。
        """
        if not prediction.predicted_syscall:
            return None
        if not prediction.is_read_only:
            return None

        args = args_hint or prediction.args_hint

        # 檢查快取
        cached = self._cache.get(prediction.predicted_syscall, args)
        if cached:
            return cached

        # 執行唯讀 syscall
        result = await self._execute_readonly(kernel, prediction.predicted_syscall, args)
        if result is not None:
            return self._cache.put(prediction.predicted_syscall, args, result)

        return None

    def cache_result(
        self,
        syscall_name: str,
        args:   dict[str, Any],
        result: Any,
    ) -> PrefetchResult:
        """手動將真實 syscall 結果放入快取（供後續命中）。"""
        return self._cache.put(syscall_name, args, result)

    def check_cache(
        self,
        syscall_name: str,
        args:         dict[str, Any],
    ) -> Any | None:
        """
        檢查快取中是否有對應的預取結果。

        由實際的 syscall handler 在執行前呼叫：
          cached = speculator.check_cache("mem_recall", {"query": "..."})
          if cached:
              return cached
        """
        entry = self._cache.get(syscall_name, args)
        return entry.result if entry else None

    def invalidate(self, syscall_name: str) -> int:
        """使特定 syscall 的快取失效（用於資料變更後）。"""
        return self._cache.invalidate(syscall_name)

    # ── 工具方法 ──────────────────────────────────────────────────

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "mode":           self._mode.value,
            "predictor":      self._predictor.stats,
            "cache_hit_rate": self._cache.hit_rate,
            "cache_size":     self._cache.size,
        }

    @staticmethod
    async def _execute_readonly(
        kernel: Any,
        syscall_name: str,
        args: dict[str, Any],
    ) -> Any:
        """
        執行一個唯讀 syscall 用於預取。

        需要一個 mock token 來執行——在實際整合時，
        kernel 應提供一個唯讀 token 或用於預取的專用權限。
        """
        # 此為模擬實作；真實整合時需與實際 kernel 連接
        try:
            match syscall_name:
                case "mem_recall":
                    from aios.core.models import MemRecallRequest, MemoryScope
                    req = MemRecallRequest(query=args.get("query", ""), scope=MemoryScope.PERSONAL)
                    return {"entries": []}  # placeholder
                case "kb_search":
                    from aios.core.models import KBSearchRequest
                    req = KBSearchRequest(query=args.get("query", ""), top_k=args.get("top_k", 5))
                    return {"entries": []}  # placeholder
                case "tool_list":
                    return []
                case _:
                    return None
        except Exception:
            return None
