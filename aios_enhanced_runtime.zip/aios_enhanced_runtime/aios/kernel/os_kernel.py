"""aios.kernel.os_kernel — AI OS Kernel: context-switching + syscall dispatch + observability"""
from __future__ import annotations
import threading, time, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from aios.core.models import (AgentSpec,AgentState,MemRecallRequest,MemStoreRequest,
    KBIndexRequest,KBSearchRequest,ToolCallRequest,CtxHandoffRequest,PolicyDecision,ToolResult,TrustToken)
from aios.kernel.aios import AIOS
from aios.observability import (get_tracer,get_bus,record_syscall,AGENT_ACTIVE,CTX_SWITCHES,
    SYSCALL_TOTAL,SystemEvent,EventSeverity)

@dataclass
class ContextFrame:
    instance_id:str; messages:list=field(default_factory=list); step:int=0
    memory_cursor:int=0; working_context:str=""; last_syscall:str=""
    last_switch_at:datetime=field(default_factory=lambda:datetime.now(timezone.utc))
    cpu_time_ms:float=0.0; switch_count:int=0

class ContextSwitchReason(str,Enum):
    VOLUNTARY="voluntary"; PREEMPTED="preempted"; MIGRATED="migrated"; SUSPENDED="suspended"

@dataclass
class SyscallResult:
    syscall:str; success:bool; payload:Any; error:str|None=None; duration_ms:float=0.0
    trace_id:str=field(default_factory=lambda:uuid.uuid4().hex[:8])

class AIKernel:
    def __init__(self,aios:AIOS):
        self._aios=aios; self._tracer=get_tracer(); self._bus=get_bus()
        self._frames:dict[str,ContextFrame]={}; self._current:str|None=None
        self._lk=threading.RLock(); self._boot_at=datetime.now(timezone.utc)

    def spawn(self,spec:AgentSpec)->AgentState:
        with self._tracer.start("kernel.spawn",goal=spec.goal[:40]) as span:
            state=self._aios.agent_spawn(spec)
            with self._lk: self._frames[state.instance_id]=ContextFrame(state.instance_id)
            AGENT_ACTIVE.inc()
            self._bus.emit(SystemEvent("agent.spawned","AIKernel",payload={"iid":state.instance_id,"goal":spec.goal[:80]}))
            span.set("iid",state.instance_id); return state

    def kill(self,iid:str)->bool:
        with self._tracer.start("kernel.kill",iid=iid[:8]):
            ok=self._aios.agent_kill(iid)
            if ok:
                with self._lk:
                    self._frames.pop(iid,None)
                    if self._current==iid: self._current=None
                AGENT_ACTIVE.dec()
                self._bus.emit(SystemEvent("agent.killed","AIKernel",payload={"iid":iid}))
            return ok

    def context_switch(self,from_id:str|None,to_id:str,reason:ContextSwitchReason=ContextSwitchReason.VOLUNTARY)->bool:
        with self._tracer.start("kernel.ctx_switch",reason=reason.value) as span:
            with self._lk:
                if from_id and from_id in self._frames:
                    fr=self._frames[from_id]; s=self._aios.agent_get(from_id)
                    if s: fr.messages=list(s.messages); fr.step=s.steps
                    fr.last_switch_at=datetime.now(timezone.utc); fr.switch_count+=1
                if to_id not in self._frames: return False
                tf=self._frames[to_id]; ts=self._aios.agent_get(to_id)
                if ts: ts.messages=list(tf.messages); ts.steps=tf.step
                self._current=to_id
            CTX_SWITCHES.inc()
            span.set("from",from_id or "none").set("to",to_id)
            self._bus.emit(SystemEvent("kernel.ctx_switch","AIKernel",payload={"from":from_id,"to":to_id,"reason":reason.value}))
            return True

    def current_agent(self)->str|None: return self._current
    def get_frame(self,iid:str)->ContextFrame|None: return self._frames.get(iid)
    def update_frame(self,iid:str,**kw):
        with self._lk:
            f=self._frames.get(iid)
            if f:
                for k,v in kw.items():
                    if hasattr(f,k): setattr(f,k,v)

    def syscall(self,syscall_name:str,token:TrustToken,**params)->SyscallResult:
        t0=time.perf_counter(); SYSCALL_TOTAL.inc()
        with self._tracer.start(f"syscall.{syscall_name}",iid=token.instance_id[:8]) as span:
            self.update_frame(token.instance_id,last_syscall=syscall_name)
            try:
                payload=self._dispatch(syscall_name,token,params)
                success=not isinstance(payload,PolicyDecision) or payload.permitted
                if isinstance(payload,ToolResult) and not payload.success: success=False
            except Exception as e:
                ms=(time.perf_counter()-t0)*1000; record_syscall(syscall_name,ms,False); span.set_error(e)
                return SyscallResult(syscall_name,False,None,str(e),ms)
            ms=(time.perf_counter()-t0)*1000; record_syscall(syscall_name,ms,success)
            span.set("ok",success).set("ms",round(ms,2))
            return SyscallResult(syscall_name,success,payload,duration_ms=ms)

    def _dispatch(self,name:str,token:TrustToken,p:dict)->Any:
        match name:
            case "mem_store":    return self._aios.mem_store(token,MemStoreRequest(**p))
            case "mem_recall":   return self._aios.mem_recall(token,MemRecallRequest(**p))
            case "tool_call":    return self._aios.tool_call(token,ToolCallRequest(**p))
            case "kb_search":    return self._aios.kb_search(token,KBSearchRequest(**p))
            case "kb_index":     return self._aios.kb_index(token,KBIndexRequest(**p))
            case "ctx_handoff":  return self._aios.ctx_handoff(token,CtxHandoffRequest(**p))
            case "tool_list":    return self._aios.tool_list(token)
            case "sys_stats":    return self._aios.sys_stats()
            case _:              raise ValueError(f"Unknown syscall: {name}")

    def health_snapshot(self)->dict:
        snap=self._aios.sys_stats()
        uptime=(datetime.now(timezone.utc)-self._boot_at).total_seconds()
        with self._lk: fc=len(self._frames); cur=self._current
        return {"kernel":{"uptime_sec":round(uptime,1),"current_agent":cur,
                           "context_frames":fc,"ctx_switches":CTX_SWITCHES.get()},
                "agents":snap.agents,"memory":snap.memory,"tools":snap.tools,"kb":snap.kb_entries,
                "syscalls":{"total":SYSCALL_TOTAL.get()},
                "events_by_type":self._bus.count_by_type()}

    def dashboard(self)->str:
        from aios.observability import render_dashboard
        snap=self.health_snapshot()
        return render_dashboard({"agents":snap["agents"],"memory":snap["memory"]})
