"""
aios.kernel.aios
─────────────────
AIOS 核心物件：L5 AI Syscall Interface 的實作。

這是 AI 模型唯一合法的入口點。
類比 POSIX 系統呼叫，但使用者是 AI 模型，不是 C 程式。

設計原則：
  1. 每個 Syscall 強制攜帶 intent 欄位
  2. 所有請求都通過 L4 PolicyEngine（三道防線）
  3. 工具結果經沙箱過濾後才注入代理上下文
  4. 異常以 PolicyDecision(permitted=False) 回傳，不拋出例外
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models import (
    AgentSpec,
    AgentState,
    AgentStatus,
    Capability,
    ContextHandoff,
    KBBroadcastRequest,
    KBEntry,
    KBIndexRequest,
    KBSearchRequest,
    KBSearchResult,
    KnowledgeBroadcast,
    MemoryScope,
    MemoryTier,
    CtxHandoffRequest,
    MemRecallRequest,
    MemRecallResult,
    MemStoreRequest,
    MemoryEntry,
    PolicyDecision,
    SystemSnapshot,
    ToolCallRequest,
    ToolResult,
    TrustToken,
)
from aios.fs.aiofs import AIOFS
from aios.iac.handoff import IACBus
from aios.memory import MemorySubsystem
from aios.security.policy import PolicyEngine, _deny
from aios.security.token import TokenIssuer
from aios.tools import ToolRegistry, ToolRouter


@dataclass
class AIOS:
    """
    AIOS 核心。
    一個 OS 實例；所有代理共用同一個核心物件。
    """

    # ── 可注入的子系統（方便測試替換）──────────────────────────────
    memory:   MemorySubsystem = field(default_factory=MemorySubsystem)
    aiofs:    AIOFS            = field(default_factory=AIOFS)
    registry: ToolRegistry     = field(default_factory=ToolRegistry)
    issuer:   TokenIssuer      = field(default_factory=TokenIssuer)
    iac_bus:  IACBus           = field(default_factory=IACBus)

    def __post_init__(self) -> None:
        self._policy  = PolicyEngine(issuer=self.issuer)
        self._router  = ToolRouter(registry=self.registry)
        self._agents: dict[str, AgentState] = {}

    # ════════════════════════════════════════════════════════════════
    # Syscall：Agent 生命週期
    # ════════════════════════════════════════════════════════════════

    def agent_spawn(
        self,
        request:      AgentSpec,
        parent_token: TrustToken | None = None,
    ) -> AgentState:
        """
        建立並登記一個新的推論實例。
        類比 fork()/exec()，但建立的是 AI 推論實例而非行程。
        """
        if parent_token is not None:
            d = self._policy.check_iac(parent_token, "agent_spawn")
            if not d.permitted:
                state = AgentState(spec=request, status=AgentStatus.FAILED)
                state.error = f"agent_spawn 被拒絕：{d.reason}"
                return state
            token = self.issuer.issue_child(parent_token, request)
        else:
            token = self.issuer.issue(request)

        # state.instance_id 必須與 token.instance_id 相同，agent_kill 才能正確撤銷
        state = AgentState(instance_id=token.instance_id, spec=request, token=token, status=AgentStatus.PENDING)
        self._agents[state.instance_id] = state

        # 若有工作區，自動加入 IAC 廣播群
        if token.workspace_id:
            self.iac_bus.join_workspace(state.instance_id, token.workspace_id)

        return state

    def agent_kill(self, instance_id: str) -> bool:
        """終止代理，撤銷其 TrustToken，釋放相關資源。"""
        state = self._agents.get(instance_id)
        if state is None:
            return False

        self.issuer.revoke(instance_id)
        self._policy.invalidate_cache(instance_id)

        if state.token and state.token.workspace_id:
            self.iac_bus.leave_workspace(instance_id, state.token.workspace_id)

        state.status     = AgentStatus.DONE
        state.finished_at = datetime.now(timezone.utc)
        return True

    def agent_list(self) -> list[AgentState]:
        return list(self._agents.values())

    def agent_get(self, instance_id: str) -> AgentState | None:
        return self._agents.get(instance_id)

    # ════════════════════════════════════════════════════════════════
    # Syscall：記憶體
    # ════════════════════════════════════════════════════════════════

    def mem_store(
        self,
        token:   TrustToken,
        request: MemStoreRequest,
    ) -> MemoryEntry | PolicyDecision:
        """
        將內容寫入記憶體子系統。
        intent 欄位必填；L4 以此進行意圖白名單比對。
        """
        # 第三道防線：syscall 頻率檢查
        if burst := self._policy.record_syscall(token):
            return burst

        namespace = self._resolve_namespace(token, request.scope)
        d = self._policy.check_memory_write(token, namespace, request.scope)
        if not d.permitted:
            return d

        return self.memory.store(
            content=request.content,
            namespace=namespace,
            scope=request.scope,
            tier=request.tier,
            metadata={**request.metadata, "intent": request.intent},
        )

    def mem_recall(
        self,
        token:   TrustToken,
        request: MemRecallRequest,
    ) -> MemRecallResult | PolicyDecision:
        """
        複合查詢三層記憶體。
        回傳機器可消費的結構化結果（AI 可直接放入下一輪推論）。
        """
        if burst := self._policy.record_syscall(token):
            return burst

        namespace = self._resolve_namespace(token, request.scope)
        d = self._policy.check_memory_read(token, namespace, request.scope)
        if not d.permitted:
            return d

        entries = self.memory.recall(
            query=request.query,
            namespace=namespace,
            scope=request.scope,
            top_k=request.top_k,
            tiers=request.tiers,
        )
        return MemRecallResult(query=request.query, entries=entries)

    # ════════════════════════════════════════════════════════════════
    # Syscall：知識庫（AIOFS）
    # ════════════════════════════════════════════════════════════════

    def kb_search(
        self,
        token:   TrustToken,
        request: KBSearchRequest,
    ) -> KBSearchResult | PolicyDecision:
        if burst := self._policy.record_syscall(token):
            return burst

        d = self._policy.check_kb_operation(token, "search")
        if not d.permitted:
            return d

        hits = self.aiofs.search(request.query, top_k=request.top_k)
        return KBSearchResult(query=request.query, entries=[e for e, _ in hits])

    def kb_index(
        self,
        token:   TrustToken,
        request: KBIndexRequest,
    ) -> KBEntry | PolicyDecision:
        if burst := self._policy.record_syscall(token):
            return burst

        d = self._policy.check_kb_operation(token, "index")
        if not d.permitted:
            return d

        return self.aiofs.index(
            content=request.content,
            metadata={**request.metadata, "indexed_by": token.instance_id, "intent": request.intent},
        )

    # ════════════════════════════════════════════════════════════════
    # Syscall：工具
    # ════════════════════════════════════════════════════════════════

    def tool_call(
        self,
        token:   TrustToken,
        request: ToolCallRequest,
    ) -> ToolResult | PolicyDecision:
        """
        呼叫已注冊的工具。
        流程：能力驗證 → 意圖白名單 → 沙箱執行 → 過濾結果
        """
        if burst := self._policy.record_syscall(token):
            return burst

        spec = self.registry.get_spec(request.name)
        if spec is None:
            return ToolResult(
                tool_name=request.name,
                success=False,
                output=None,
                error=f"未知的工具: '{request.name}'",
            )

        d = self._policy.check_tool_call(token, request.name, spec.required_capability)
        if not d.permitted:
            return ToolResult(
                tool_name=request.name,
                success=False,
                output=None,
                error=f"工具呼叫被拒絕：{d.reason}",
            )

        return self._router.execute(request.name, request.args)

    def tool_list(self, token: TrustToken) -> list[str]:
        """回傳此代理可存取的工具名稱列表。"""
        return [
            spec.name
            for spec in self._router.accessible_tools(token.capabilities)
        ]

    # ════════════════════════════════════════════════════════════════
    # Syscall：IAC — 代理間通訊
    # ════════════════════════════════════════════════════════════════

    def ctx_handoff(
        self,
        token:   TrustToken,
        request: CtxHandoffRequest,
    ) -> ContextHandoff | PolicyDecision:
        """
        語意摘要交接：將當前代理的任務摘要送給另一個代理。
        不傳遞 KV-Cache（數學上不可行），傳遞語意蒸餾後的摘要物件。
        """
        if burst := self._policy.record_syscall(token):
            return burst

        d = self._policy.check_iac(token, "ctx_handoff")
        if not d.permitted:
            return d

        handoff = ContextHandoff(
            source_agent=token.instance_id,
            target_agent=request.target_agent,
            completed_goal=request.completed_goal,
            key_findings=request.key_findings,
            relevant_mem_refs=request.relevant_mem_refs,
            confidence=request.confidence,
            next_steps=request.next_steps,
        )
        self.iac_bus.send_handoff(handoff)
        return handoff

    def receive_handoffs(self, instance_id: str) -> list[ContextHandoff]:
        """取出此代理的所有待讀交接物件。"""
        return self.iac_bus.receive_handoffs(instance_id)

    def kb_broadcast(
        self,
        token:   TrustToken,
        request: KBBroadcastRequest,
    ) -> list[str] | PolicyDecision:
        """
        廣播新知識至工作區。
        回傳收到廣播的代理 instance_id 列表。
        """
        if burst := self._policy.record_syscall(token):
            return burst

        d = self._policy.check_iac(token, "kb_broadcast")
        if not d.permitted:
            return d

        broadcast = KnowledgeBroadcast(
            source_agent=token.instance_id,
            workspace_id=request.workspace_id,
            entry=request.entry,
            intent=request.intent,
        )
        recipients = self.iac_bus.broadcast(broadcast)
        return recipients

    # ════════════════════════════════════════════════════════════════
    # Syscall：系統
    # ════════════════════════════════════════════════════════════════

    def sys_stats(self) -> SystemSnapshot:
        """系統快照：代理狀態、記憶體用量、工具數、KB 條目數。"""
        by_status: dict[str, int] = {}
        for state in self._agents.values():
            key = state.status.value
            by_status[key] = by_status.get(key, 0) + 1

        return SystemSnapshot(
            agents=by_status,
            memory=self.memory.stats(),
            tools=len(self.registry.all_specs()),
            kb_entries=self.aiofs.count(),
        )

    def sys_anomaly_counts(self, instance_id: str) -> dict[str, int]:
        """回傳指定代理的異常事件計數（用於除錯與監控）。"""
        return self._policy.anomaly_counts(instance_id)

    # ════════════════════════════════════════════════════════════════
    # 內部輔助
    # ════════════════════════════════════════════════════════════════

    def _resolve_namespace(self, token: TrustToken, scope: MemoryScope) -> str:
        """根據 scope 決定 namespace：WORKSPACE scope 使用 workspace_id。"""
        if scope == MemoryScope.WORKSPACE and token.workspace_id:
            return token.workspace_id
        if scope == MemoryScope.GLOBAL:
            return "global"
        return token.instance_id
