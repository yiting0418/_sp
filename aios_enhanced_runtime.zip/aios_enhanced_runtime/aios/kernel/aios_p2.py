"""
aios.kernel.aios_p2
────────────────────
Phase 2/3 AIOS 核心擴充。

Phase 2 整合：
  - L1 KVCacheManager + TensorScheduler
  - L2 ModelManager + SnapshotManager
  - L4 BehaviorGuard（動態防護，補充 ABAC）
  - AgentRunner（完整推論迴圈）

Phase 3 整合（分散式規模化）：
  - L1 RDMA KVTransferManager（跨節點 KV 遷移）
  - L1 DisaggregatedOrchestrator（分離式 Prefill/Decode）
  - L1 GlobalScheduler + KVAwareScheduler（跨節點排程）
  - L1 KVRouter + PrefixCacheMap（KV-Cache 感知路由）
  - L3a SyscallSpeculator（預測性預取）
  - AIOFS DistributedAIOFS + ConsistentHashRing（一致性雜湊儲存）

使用方式：
  aios = AIOS_P2.build()
  state = aios.agent_spawn(spec)
  result = aios.run_agent(state)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from aios.core.models import AgentSpec, AgentState
from aios.core.models_p2 import InferResult, ModelTier
from aios.core.models_p3 import NodeType, ScheduleType, SpeculationMode
from aios.kernel.aios import AIOS
from aios.l1.kvcache import KVCacheManager
from aios.l1.scheduler import TensorScheduler
from aios.l2.model_manager import ModelManager
from aios.l2.snapshot import SnapshotManager
from aios.runtime.runner import AgentRunner, RunnerConfig
from aios.security.behavior_guard import BehaviorGuard

# Phase 3 imports
from aios.l1.rdma import LocalRDMATransport, KVTransferManager
from aios.l1.disaggregated import DisaggregatedOrchestrator, NodeRegistry
from aios.l1.global_scheduler import GlobalScheduler, KVAwareScheduler
from aios.l1.kv_router import KVRouter, PrefixCacheMap, ConsistentHashRouter
from aios.l3a.speculator import SyscallSpeculator, NGramPredictor, SpeculativeCache
from aios.fs.aiofs import DistributedAIOFS


@dataclass
class AIOS_P2:
    """
    Phase 2/3 統一核心。
    組合 Phase 1 的 L5 Syscall 介面、Phase 2 的計算基礎設施、
    與 Phase 3 的分散式規模化元件。
    """
    kernel:           AIOS
    kvcache:          KVCacheManager
    scheduler:        TensorScheduler
    model_manager:    ModelManager
    snapshot_manager: SnapshotManager
    behavior_guard:   BehaviorGuard
    runner_config:    RunnerConfig = field(default_factory=RunnerConfig)

    # Phase 3：分散式元件
    node_registry:       NodeRegistry | None       = None
    rdma_transport:      LocalRDMATransport | None = None
    kv_transfer_mgr:     KVTransferManager | None  = None
    disaggregated:       DisaggregatedOrchestrator | None = None
    global_scheduler:    GlobalScheduler | None    = None
    kv_router:           KVRouter | None           = None
    syscall_speculator:  SyscallSpeculator | None  = None
    distributed_aiofs:   DistributedAIOFS | None   = None

    # ── 工廠 ─────────────────────────────────────────────────────────

    @classmethod
    def build(
        cls,
        total_kv_blocks:    int   = 256,
        vram_capacity_mb:   float = 16_000.0,
        max_prefill_batch:  int   = 8,
        max_decode_batch:   int   = 32,
        verbose:            bool  = False,
        enable_distributed: bool  = False,
        num_nodes:          int   = 3,
    ) -> "AIOS_P2":
        kvcache  = KVCacheManager(total_blocks=total_kv_blocks)
        sched    = TensorScheduler(kvcache, max_prefill_batch, max_decode_batch)
        mm       = ModelManager(vram_capacity_mb=vram_capacity_mb)
        snap     = SnapshotManager(kvcache)
        guard    = BehaviorGuard()
        kernel   = AIOS()
        cfg      = RunnerConfig(verbose=verbose)

        p2 = cls(
            kernel=kernel,
            kvcache=kvcache,
            scheduler=sched,
            model_manager=mm,
            snapshot_manager=snap,
            behavior_guard=guard,
            runner_config=cfg,
        )

        if enable_distributed:
            p2._init_distributed(num_nodes)

        return p2

    def _init_distributed(self, num_nodes: int = 3) -> None:
        """初始化 Phase 3 分散式元件。"""
        # 節點註冊表
        self.node_registry = NodeRegistry()

        # 建立節點
        for i in range(num_nodes):
            ntype = (
                NodeType.PREFILL_ONLY if i == 0
                else NodeType.DECODE_ONLY if i == 1
                else NodeType.HYBRID
            )
            self.node_registry.register(
                node_id=f"node-{i}",
                node_type=ntype,
                address=f"10.0.0.{i + 1}:9000",
                vram_mb=80_000.0,
                kv_blocks=256,
            )

        # 為每個節點建立獨立的 KVCacheManager
        kvcache_nodes: dict[str, KVCacheManager] = {}
        for i in range(num_nodes):
            nid = f"node-{i}"
            kvcache_nodes[nid] = KVCacheManager(total_blocks=256)

        # RDMA 傳輸
        self.rdma_transport = LocalRDMATransport()
        for i in range(num_nodes):
            self.rdma_transport.register_node(f"node-{i}")

        # KV 遷移管理
        self.kv_transfer_mgr = KVTransferManager(
            transport=self.rdma_transport,
            kvcache_nodes=kvcache_nodes,
        )

        # 分離式 Prefill/Decode
        self.disaggregated = DisaggregatedOrchestrator(
            registry=self.node_registry,
            transfer_mgr=self.kv_transfer_mgr,
            kvcache_nodes=kvcache_nodes,
        )

        # Global Scheduler
        kv_aware = KVAwareScheduler(self.node_registry)
        self.global_scheduler = GlobalScheduler(
            node_registry=self.node_registry,
            plugins=[kv_aware],
        )

        # KV-Cache 感知路由
        prefix_cache = PrefixCacheMap()
        ch_router    = ConsistentHashRouter()
        self.kv_router = KVRouter(
            node_registry=self.node_registry,
            prefix_cache=prefix_cache,
            router=ch_router,
        )
        for i in range(num_nodes):
            self.kv_router.add_node(f"node-{i}")

        # L3a Syscall Speculator
        self.syscall_speculator = SyscallSpeculator(
            predictor=NGramPredictor(n=3),
            cache=SpeculativeCache(),
            mode=SpeculationMode.OBSERVE,
        )

        # 分散式 AIOFS
        self.distributed_aiofs = DistributedAIOFS()
        for i in range(num_nodes):
            self.distributed_aiofs.add_node(
                f"node-{i}",
                address=f"10.0.0.{i + 1}:9000",
            )
        self.distributed_aiofs.set_local_node("node-0")

    # ── 代理生命週期 ─────────────────────────────────────────────────

    def agent_spawn(self, spec: AgentSpec) -> AgentState:
        return self.kernel.agent_spawn(spec)

    def run_agent(self, state: AgentState) -> InferResult:
        runner = AgentRunner(
            kernel=self.kernel,
            scheduler=self.scheduler,
            model_manager=self.model_manager,
            snapshot_manager=self.snapshot_manager,
            behavior_guard=self.behavior_guard,
            config=self.runner_config,
        )
        return runner.run(state)

    # ── 模型管理便利方法 ─────────────────────────────────────────────

    def register_model(
        self,
        model_id: str,
        size_mb:  float,
        tier:     ModelTier = ModelTier.NVME,
    ) -> None:
        self.model_manager.register(model_id, size_mb, tier)

    def register_lora(
        self,
        base_model_id: str,
        adapter_id:    str,
        task_type:     str,
        delta_mb:      float = 50.0,
    ) -> None:
        self.model_manager.register_lora(
            base_model_id, adapter_id, task_type, delta_mb
        )

    # ── 系統報告 ─────────────────────────────────────────────────────

    def full_report(self) -> dict[str, Any]:
        kv_stats   = self.kvcache.stats
        sched_qs   = self.scheduler.queue_lengths()
        sched_stat = self.scheduler.stats
        mm_stat    = self.model_manager.stats
        snap_stat  = self.snapshot_manager.stats
        sys_snap   = self.kernel.sys_stats()

        report: dict[str, Any] = {
            "l1_kvcache": {
                "total_blocks":         kv_stats.total_blocks,
                "free_blocks":          kv_stats.free_blocks,
                "utilization":          round(kv_stats.utilization, 3),
                "prefix_cache_hits":    kv_stats.prefix_cache_hits,
                "prefix_cache_misses":  kv_stats.prefix_cache_misses,
                "prefix_hit_rate":      round(kv_stats.prefix_hit_rate, 3),
                "evictions":            kv_stats.evictions,
            },
            "l1_scheduler": {
                "queue_lengths":     sched_qs,
                "total_scheduled":   sched_stat.total_scheduled,
                "preemptions":       sched_stat.preemptions,
                "avg_prefill_tokens": round(sched_stat.avg_prefill_tokens, 1),
            },
            "l2_model_manager": {
                "total_models":   mm_stat.total_models,
                "vram_models":    mm_stat.vram_models,
                "dram_models":    mm_stat.dram_models,
                "nvme_models":    mm_stat.nvme_models,
                "hot_swaps":      mm_stat.hot_swaps,
                "cache_hit_rate": round(
                    mm_stat.cache_hits / max(1, mm_stat.cache_hits + mm_stat.cache_misses), 3
                ),
            },
            "l2_snapshots": {
                "total":            snap_stat.total_snapshots,
                "restores":         snap_stat.total_restores,
                "total_bytes":      snap_stat.total_bytes,
                "invalid_attempts": snap_stat.invalid_attempts,
            },
            "l5_kernel": sys_snap.model_dump(),
        }

        # Phase 3 分散式報告
        if self.node_registry:
            report["p3_node_registry"] = self.node_registry.stats
        if self.kv_transfer_mgr:
            ts = self.kv_transfer_mgr.stats
            report["p3_rdma_transfers"] = {
                "total":             ts.total_transfers,
                "successful":        ts.successful,
                "failed":            ts.failed,
                "total_bytes":       ts.total_bytes,
                "avg_latency_us":    round(ts.avg_latency_us, 1),
                "success_rate":      round(ts.success_rate, 3),
            }
        if self.disaggregated:
            report["p3_disaggregated"] = self.disaggregated.stats
        if self.global_scheduler:
            gs = self.global_scheduler.stats
            report["p3_global_scheduler"] = {
                "total_decisions":      gs.total_decisions,
                "prefill_assignments":  gs.prefill_assignments,
                "decode_assignments":   gs.decode_assignments,
                "avg_score":            round(gs.avg_score, 2),
            }
        if self.kv_router:
            report["p3_kv_router"] = self.kv_router.prefix_stats
        if self.syscall_speculator:
            report["p3_speculator"] = self.syscall_speculator.stats
        if self.distributed_aiofs:
            report["p3_distributed_aiofs"] = self.distributed_aiofs.stats()

        return report
