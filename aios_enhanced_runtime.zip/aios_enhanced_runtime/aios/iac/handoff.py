"""
aios.iac.handoff
─────────────────
代理間通訊（Inter-Agent Communication，IAC）。

核心設計決策：
  代理間傳遞的不是 KV-Cache 切片，而是語意摘要物件。

  原因：Transformer Self-Attention 是全域的：
    每個 token 的 KV 值 = f(它自己 + 之前所有 token 的上下文)
  因此，KV-Cache 切片 [token_500:token_800] 隱含了對
  [token_0:token_499] 的注意力結果。若接收代理缺少前置上下文，
  這些 KV 值在數學上無效。

  正確做法：生成語意摘要物件（幾百 token）→ 接收代理重新 Prefill。
  代價：接收代理需要重新 Prefill 摘要（可接受）。
  收益：正確性保證 + 體積比 KV-Cache 小 100–1000 倍。
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models import (
    ContextHandoff,
    KBEntry,
    KnowledgeBroadcast,
    MemoryEntry,
    MemoryScope,
    MemoryTier,
)


@dataclass
class IACBus:
    """
    代理間通訊匯流排。

    職責：
      1. 語意摘要交接（Context Handoff）
         - 來源代理 → 生成 ContextHandoff 物件
         - IACBus 放入目標代理的收件佇列
         - 目標代理在下次推論時從佇列取出，作為新的 Prefill 輸入

      2. 知識廣播（Knowledge Broadcast）
         - 代理廣播新知識至工作區
         - 工作區內所有訂閱代理的語意記憶都收到更新

      3. 協同推論（Collaborative Inference）— Phase 2 實作
    """

    # instance_id → deque[ContextHandoff]（未讀的交接物件）
    _mailboxes: dict[str, list[ContextHandoff]] = field(
        default_factory=lambda: defaultdict(list),
        init=False,
    )

    # workspace_id → [instance_id]（訂閱廣播的代理）
    _workspace_members: dict[str, set[str]] = field(
        default_factory=lambda: defaultdict(set),
        init=False,
    )

    # workspace_id → [KnowledgeBroadcast]（廣播紀錄，可用於後來加入的代理補上）
    _broadcast_log: dict[str, list[KnowledgeBroadcast]] = field(
        default_factory=lambda: defaultdict(list),
        init=False,
    )

    # ── 成員管理 ────────────────────────────────────────────────────

    def join_workspace(self, instance_id: str, workspace_id: str) -> None:
        """代理加入工作區，開始接收廣播。"""
        self._workspace_members[workspace_id].add(instance_id)

    def leave_workspace(self, instance_id: str, workspace_id: str) -> None:
        self._workspace_members[workspace_id].discard(instance_id)

    # ── 語意摘要交接 ─────────────────────────────────────────────────

    def send_handoff(self, handoff: ContextHandoff) -> None:
        """
        將語意摘要物件送入目標代理的收件匣。
        目標代理在下次推論時以此作為 Prefill 輸入重建 KV-Cache。
        """
        self._mailboxes[handoff.target_agent].append(handoff)

    def receive_handoffs(self, instance_id: str) -> list[ContextHandoff]:
        """取出並清空此代理的所有待讀交接物件。"""
        items = list(self._mailboxes[instance_id])
        self._mailboxes[instance_id].clear()
        return items

    def peek_handoffs(self, instance_id: str) -> list[ContextHandoff]:
        """查看但不取出（用於測試/診斷）。"""
        return list(self._mailboxes[instance_id])

    # ── 知識廣播 ─────────────────────────────────────────────────────

    def broadcast(self, broadcast: KnowledgeBroadcast) -> list[str]:
        """
        將知識廣播至工作區。
        回傳收到廣播的代理 instance_id 列表。
        """
        workspace_id = broadcast.workspace_id
        self._broadcast_log[workspace_id].append(broadcast)

        recipients = list(self._workspace_members[workspace_id])
        # 廣播者自己也在列表中，但通常不需要重複接收
        return [r for r in recipients if r != broadcast.source_agent]

    def get_broadcast_history(
        self,
        workspace_id: str,
        since: datetime | None = None,
    ) -> list[KnowledgeBroadcast]:
        """取得工作區的廣播紀錄（供新加入的代理補讀）。"""
        logs = self._broadcast_log.get(workspace_id, [])
        if since is None:
            return list(logs)
        return [b for b in logs if b.created_at >= since]

    # ── 輔助：將交接物件轉換為 MemoryEntry，供記憶子系統儲存 ──────

    @staticmethod
    def handoff_to_memory_entries(
        handoff:      ContextHandoff,
        receiver_id:  str,
    ) -> list[MemoryEntry]:
        """
        把 ContextHandoff 展開為一組 MemoryEntry，
        注入接收代理的情節記憶，作為下次推論的上下文。
        """
        now = datetime.now(timezone.utc)
        entries: list[MemoryEntry] = []

        # 任務摘要
        entries.append(MemoryEntry(
            content=f"[交接] 來源：{handoff.source_agent[:8]}\n目標：{handoff.completed_goal}",
            metadata={"type": "handoff_summary", "source": handoff.source_agent},
            tier=MemoryTier.EPISODIC,
            scope=MemoryScope.PERSONAL,
            namespace=receiver_id,
        ))

        # 關鍵發現（每條獨立儲存，方便語意索引）
        for i, finding in enumerate(handoff.key_findings):
            entries.append(MemoryEntry(
                content=finding,
                metadata={
                    "type":       "handoff_finding",
                    "source":     handoff.source_agent,
                    "confidence": handoff.confidence,
                    "index":      i,
                },
                tier=MemoryTier.EPISODIC,
                scope=MemoryScope.PERSONAL,
                namespace=receiver_id,
            ))

        # 下一步行動
        if handoff.next_steps:
            entries.append(MemoryEntry(
                content="下一步：" + "；".join(handoff.next_steps),
                metadata={"type": "handoff_next_steps", "source": handoff.source_agent},
                tier=MemoryTier.EPISODIC,
                scope=MemoryScope.PERSONAL,
                namespace=receiver_id,
            ))

        return entries

    # ── 統計 ────────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        return {
            "pending_handoffs":   sum(len(q) for q in self._mailboxes.values()),
            "workspace_members":  {ws: len(m) for ws, m in self._workspace_members.items()},
            "broadcast_log_size": {ws: len(b) for ws, b in self._broadcast_log.items()},
        }
