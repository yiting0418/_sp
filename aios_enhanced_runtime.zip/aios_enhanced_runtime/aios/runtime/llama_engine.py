"""
aios.runtime.llama_engine
──────────────────────────
LlamaCppEngine：以 llama-cpp-python 為後端的推論引擎。

特性：
  1. Metal 支援    — n_gpu_layers=-1 將所有層卸載至 Apple GPU（macOS）
                     CUDA 環境同樣有效；CPU only 時設 n_gpu_layers=0
  2. Async Stream  — llama-cpp-python 本身是同步 API；
                     以 asyncio.get_event_loop().run_in_executor + Queue 橋接
  3. KV-Cache 快照 — llm.save_state() / llm.load_state() 完整序列化
                     對應設計文件的「自然邊界快照」原則

Metal 啟用方式（安裝時）：
  CMAKE_ARGS="-DLLAMA_METAL=on" pip install llama-cpp-python --force-reinstall

或使用預編譯 wheel：
  pip install llama-cpp-python \
    --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/metal

本模組在 is_loaded=False 時自動退化為 stub（允許測試不依賴真實 GGUF 檔案）。
"""

from __future__ import annotations

import asyncio
import json
import queue
import threading
import time
from typing import Any, AsyncGenerator

from aios.runtime.engine import (
    EngineState,
    GenerationChunk,
    GenerationResult,
    InferenceEngine,
    StopReason,
    TOOL_STOP_WORDS,
)


class LlamaCppEngine(InferenceEngine):
    """
    llama-cpp-python 推論引擎。

    載入流程：
      engine = LlamaCppEngine()
      engine.load(
          "path/to/model.gguf",
          n_gpu_layers=-1,   # Metal / CUDA 全卸載；CPU only 請用 0
          n_ctx=4096,
          verbose=False,
      )

    Async 串流：
      async for chunk in engine.generate_stream(prompt):
          print(chunk.text, end="", flush=True)
          if chunk.is_last:
              break
    """

    def __init__(self) -> None:
        self._llm: Any = None            # llama_cpp.Llama 實例
        self._lock = threading.Lock()    # 保護 _llm 的並發存取
        self._model_path: str = ""
        self._n_ctx: int = 4096
        # 最後一次 save_state 的原始 LlamaState 物件
        self._last_state: Any = None

    # ── 載入 ─────────────────────────────────────────────────────────

    def load(
        self,
        model_path: str,
        n_gpu_layers: int = -1,    # -1 = 全卸載（Metal / CUDA）
        n_ctx: int = 4096,
        n_threads: int | None = None,
        verbose: bool = False,
        **kwargs: Any,
    ) -> None:
        """
        載入 GGUF 模型。

        n_gpu_layers=-1  → 所有層卸載至 GPU（Metal on macOS / CUDA on Linux）
        n_gpu_layers=0   → 純 CPU 推論
        n_gpu_layers=N   → 前 N 層卸載至 GPU（混合模式）
        """
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise RuntimeError(
                "llama-cpp-python 未安裝。請執行：\n"
                "  pip install llama-cpp-python\n"
                "Metal 版本：\n"
                "  CMAKE_ARGS='-DLLAMA_METAL=on' pip install llama-cpp-python --force-reinstall"
            ) from exc

        self._model_path = model_path
        self._n_ctx      = n_ctx

        load_kwargs: dict[str, Any] = {
            "model_path":    model_path,
            "n_gpu_layers":  n_gpu_layers,
            "n_ctx":         n_ctx,
            "verbose":       verbose,
            **kwargs,
        }
        if n_threads is not None:
            load_kwargs["n_threads"] = n_threads

        with self._lock:
            self._llm = Llama(**load_kwargs)

    # ── Async 串流生成 ────────────────────────────────────────────────

    async def generate_stream(
        self,
        prompt:      str,
        max_tokens:  int = 512,
        temperature: float = 0.7,
        stop_words:  list[str] | None = None,
    ) -> AsyncGenerator[GenerationChunk, None]:
        """
        非同步 token 串流生成器。

        實作機制：
          llama-cpp-python 的生成 API 是同步阻塞的。
          我們在 ThreadPoolExecutor 中執行同步生成，
          透過 asyncio.Queue 將 token 橋接至 async 消費端。

          ┌─────────────────────────┐    Queue     ┌──────────────────┐
          │ Thread: llm.generate()  │ ──→ tokens → │ async for chunk  │
          │ (blocking, sync)        │              │ (non-blocking)   │
          └─────────────────────────┘              └──────────────────┘
        """
        if not self.is_loaded:
            # Stub 模式：引擎未載入時回傳佔位輸出
            async for chunk in self._stub_stream(prompt):
                yield chunk
            return

        token_queue: asyncio.Queue[GenerationChunk | None] = asyncio.Queue()
        stop_flag = threading.Event()
        loop = asyncio.get_event_loop()

        effective_stop = list(stop_words or TOOL_STOP_WORDS)

        def _sync_generate() -> None:
            """在子執行緒中執行同步生成，將每個 token 放入佇列。"""
            try:
                with self._lock:
                    stream = self._llm.create_completion(
                        prompt=prompt,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        stop=effective_stop,
                        stream=True,
                        echo=False,
                    )
                    for output in stream:
                        if stop_flag.is_set():
                            break
                        choice = output["choices"][0]
                        text   = choice.get("text", "")
                        if not text:
                            continue
                        chunk = GenerationChunk(
                            text=text,
                            token_id=None,
                            is_last=choice.get("finish_reason") is not None,
                        )
                        # 執行緒安全地把 chunk 放進 async queue
                        asyncio.run_coroutine_threadsafe(
                            token_queue.put(chunk), loop
                        ).result(timeout=5.0)

            except Exception as exc:
                err_chunk = GenerationChunk(
                    text=f"\n[ENGINE ERROR: {exc}]",
                    is_last=True,
                )
                asyncio.run_coroutine_threadsafe(
                    token_queue.put(err_chunk), loop
                ).result(timeout=5.0)
            finally:
                # 放入 sentinel 告知 async 端生成結束
                asyncio.run_coroutine_threadsafe(
                    token_queue.put(None), loop
                ).result(timeout=5.0)

        # 在 executor 中啟動同步生成
        executor_future = loop.run_in_executor(None, _sync_generate)

        try:
            while True:
                chunk = await token_queue.get()
                if chunk is None:
                    break
                yield chunk
                if chunk.is_last:
                    break
        except asyncio.CancelledError:
            stop_flag.set()
            raise
        finally:
            stop_flag.set()
            # 等待 executor 執行緒清理
            try:
                await asyncio.wait_for(executor_future, timeout=2.0)
            except asyncio.TimeoutError:
                pass

    # ── KV-Cache 快照 ─────────────────────────────────────────────────

    def save_state(self) -> EngineState | None:
        """
        序列化當前 KV-Cache 狀態。

        llm.save_state() 回傳一個 LlamaState 物件，
        包含完整的 KV-Cache tensor 和模型執行狀態。
        這正是「自然邊界快照」所需的全部資訊。
        """
        if not self.is_loaded:
            return None
        with self._lock:
            try:
                raw_state = self._llm.save_state()
            except Exception:
                return None

        self._last_state = raw_state
        return EngineState(
            payload=raw_state,
            token_count=self._llm.n_tokens if hasattr(self._llm, "n_tokens") else 0,
        )

    def load_state(self, state: EngineState) -> bool:
        """
        從 EngineState 恢復 KV-Cache。

        恢復後可直接繼續 generate_stream()，
        不需要重新 prefill 整個 context（省去 O(n²) 計算）。
        """
        if not self.is_loaded or state.payload is None:
            return False
        with self._lock:
            try:
                self._llm.load_state(state.payload)
                return True
            except Exception:
                return False

    def reset_state(self) -> None:
        """清除 KV-Cache，重置至初始狀態。"""
        if self.is_loaded:
            with self._lock:
                self._llm.reset()

    # ── 便利方法 ─────────────────────────────────────────────────────

    async def generate_complete(
        self,
        prompt:      str,
        max_tokens:  int = 512,
        temperature: float = 0.7,
        stop_words:  list[str] | None = None,
    ) -> GenerationResult:
        """
        非串流版本：等待生成完畢後一次回傳。
        適合短回應；長回應請使用 generate_stream()。
        """
        t0 = time.perf_counter()
        parts: list[str] = []

        async for chunk in self.generate_stream(
            prompt, max_tokens, temperature, stop_words
        ):
            parts.append(chunk.text)
            if chunk.is_last:
                break

        full_text  = "".join(parts)
        stop_reason = self._infer_stop_reason(full_text, stop_words or TOOL_STOP_WORDS)

        return GenerationResult(
            full_text=full_text,
            stop_reason=stop_reason,
            tokens_used=len(full_text.split()),   # 粗估；Phase 3 用 tokenizer
            duration_ms=(time.perf_counter() - t0) * 1000,
        )

    # ── 屬性 ─────────────────────────────────────────────────────────

    @property
    def is_loaded(self) -> bool:
        return self._llm is not None

    @property
    def n_ctx(self) -> int:
        return self._n_ctx

    @property
    def model_path(self) -> str:
        return self._model_path

    # ── 內部輔助 ─────────────────────────────────────────────────────

    @staticmethod
    def _infer_stop_reason(text: str, stop_words: list[str]) -> StopReason:
        from aios.runtime.engine import TOOL_END
        if TOOL_END in stop_words and TOOL_END in text:
            return StopReason.TOOL_CALL
        if any(sw in text for sw in stop_words):
            return StopReason.EOS
        return StopReason.EOS

    @staticmethod
    async def _stub_stream(prompt: str) -> AsyncGenerator[GenerationChunk, None]:
        """引擎未載入時的 stub 輸出（方便離線測試）。"""
        stub_text = (
            f"[LlamaCppEngine stub — 模型未載入]\n"
            f"收到 prompt（前 80 字元）：{prompt[:80]}"
        )
        for i, char in enumerate(stub_text):
            await asyncio.sleep(0)   # 讓出事件迴圈
            yield GenerationChunk(
                text=char,
                is_last=(i == len(stub_text) - 1),
            )
