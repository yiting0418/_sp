"""
aios.runtime.runner
────────────────────
Phase 2 AgentRunner：完整代理執行迴圈。

流程：
  1. 從 L2 取得模型（必要時載入）
  2. 建立推論任務，提交至 L1 排程器
  3. 從記憶子系統組建上下文
  4. Anthropic API tool-use 迴圈（自然邊界）
  5. 每次工具呼叫後持久化至 episodic 記憶
  6. 完成後將結果存入 semantic 記憶
  7. 若需要暫停，在自然邊界建立 KV-Cache 快照

Syscall 成本緩解（來自設計文件）：
  - 每輪保留 prefix KV-Cache（由 L1 KVCacheManager 管理）
  - 工具呼叫結果注入後只需 prefill 增量部分
  - 多個 Syscall 可批次合併（batch_syscalls 方法）
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from aios.core.models import (
    AgentState,
    AgentStatus,
    Capability,
    MemoryScope,
    MemoryTier,
    TrustToken,
)
from aios.core.models_p2 import (
    InferencePhase,
    InferenceTask,
    InferResult,
    RunnerStatus,
    TaskPriority,
    BehaviorEvent,
    BehaviorEventType,
)
from aios.kernel.aios import AIOS
from aios.l1.kvcache import KVCacheManager
from aios.l1.scheduler import TensorScheduler
from aios.l2.model_manager import ModelManager
from aios.l2.snapshot import SnapshotManager
from aios.security.behavior_guard import BehaviorGuard
from aios.core.models import (
    MemRecallRequest,
    MemStoreRequest,
    ToolCallRequest,
)


_SYSTEM_PROMPT = """\
你是運行在 AIOS 上的 AI 代理。
你有存取已注冊工具的能力。
完成目標後，以純文字回覆你的成果摘要。
不要要求澄清，直接判斷並執行。
"""


@dataclass
class RunnerConfig:
    max_steps:          int   = 20
    verbose:            bool  = False
    enable_snapshots:   bool  = True       # 工具呼叫後建立快照
    enable_behavior_guard: bool = True     # 啟用動態行為防護
    syscall_batch_size: int   = 3          # 最多批次合併幾個 Syscall


class AgentRunner:
    """
    Phase 2 代理執行器。
    整合 L1 排程器、L2 模型管理器、L2 快照管理器、L4 動態防護。
    """

    def __init__(
        self,
        kernel:           AIOS,
        scheduler:        TensorScheduler,
        model_manager:    ModelManager,
        snapshot_manager: SnapshotManager,
        behavior_guard:   BehaviorGuard,
        config:           RunnerConfig | None = None,
    ):
        self._kernel           = kernel
        self._scheduler        = scheduler
        self._model_manager    = model_manager
        self._snapshot_manager = snapshot_manager
        self._behavior_guard   = behavior_guard
        self._cfg              = config or RunnerConfig()

        api_key = os.environ.get("ANTHROPIC_API_KEY")
        self._client = None
        if api_key:
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=api_key)
            except ImportError:
                pass

    # ── 主入口 ────────────────────────────────────────────────────────

    def run(self, state: AgentState) -> InferResult:
        t0 = time.perf_counter()
        token = state.token
        if token is None:
            return InferResult(
                instance_id=state.instance_id,
                task_id="",
                status=RunnerStatus.FAILED,
                error="AgentState 缺少 TrustToken",
            )

        # 建立推論任務並提交至 L1 排程器
        task = InferenceTask(
            instance_id=state.instance_id,
            model_id=state.spec.model,
            priority=TaskPriority.NORMAL,
            prompt_tokens=len(state.spec.goal) // 4,  # 粗估
            max_tokens=2048,
        )
        self._scheduler.submit(task)
        state.status = AgentStatus.RUNNING

        # 取得模型（必要時從 L2 載入）
        try:
            model_entry, load_latency = self._model_manager.get_model(state.spec.model)
            self._log(f"[{state.instance_id[:8]}] 模型 {state.spec.model} "
                      f"載入延遲 {load_latency:.0f}ms tier={model_entry.tier.value}")
        except KeyError:
            self._log(f"[{state.instance_id[:8]}] 模型未注冊，使用 stub 繼續")

        # 行為防護：初始事件
        self._emit_event(token, BehaviorEventType.SYSCALL, "agent_start", True)

        # 執行推論迴圈
        if self._client is not None:
            result = self._live_run(state, task)
        else:
            result = self._stub_run(state, task)

        result.duration_ms = (time.perf_counter() - t0) * 1000
        self._scheduler.complete_task(task.task_id)
        return result

    # ── 真實 API 迴圈 ─────────────────────────────────────────────────

    def _live_run(self, state: AgentState, task: InferenceTask) -> InferResult:
        token  = state.token
        spec   = state.spec

        # 組建系統提示 + 記憶體上下文
        mem_ctx = self._build_memory_context(token, spec.goal)
        system  = _SYSTEM_PROMPT + mem_ctx

        # Anthropic tool 定義
        tools = self._build_tool_defs(token)
        state.messages = [{"role": "user", "content": spec.goal}]

        for step in range(self._cfg.max_steps):
            state.steps = step + 1

            # 行為防護補充檢查（不覆蓋 ABAC）
            if self._cfg.enable_behavior_guard:
                verdict = self._behavior_guard.analyze(token.instance_id)
                if not verdict.verdict:
                    self._log(f"[{state.instance_id[:8]}] 行為防護攔截：{verdict.reason}")
                    state.status = AgentStatus.FAILED
                    return InferResult(
                        instance_id=state.instance_id,
                        task_id=task.task_id,
                        status=RunnerStatus.FAILED,
                        error=f"BehaviorGuard: {verdict.reason}",
                        steps=state.steps,
                    )

            try:
                response = self._client.messages.create(
                    model=spec.model,
                    max_tokens=2048,
                    system=system,
                    tools=tools or [],
                    messages=state.messages,
                )
            except Exception as exc:
                state.status = AgentStatus.FAILED
                return InferResult(
                    instance_id=state.instance_id,
                    task_id=task.task_id,
                    status=RunnerStatus.FAILED,
                    error=str(exc),
                    steps=state.steps,
                )

            content      = response.content
            tool_calls   = [b for b in content if b.type == "tool_use"]
            text_blocks  = [b for b in content if b.type == "text"]

            state.messages.append({"role": "assistant", "content": content})

            # 自然邊界：模型完成一個完整的生成單元
            if response.stop_reason == "end_turn" or not tool_calls:
                final = text_blocks[-1].text if text_blocks else "(無輸出)"
                state.result = final
                state.status = AgentStatus.DONE
                self._persist_result(token, spec.goal, final)
                return InferResult(
                    instance_id=state.instance_id,
                    task_id=task.task_id,
                    status=RunnerStatus.DONE,
                    result=final,
                    steps=state.steps,
                    total_tokens=task.prompt_tokens + task.generated_tokens,
                )

            # 工具呼叫處理（自然邊界：stop_reason = "tool_use"）
            tool_results_content = []
            for tc in tool_calls:
                self._emit_event(token, BehaviorEventType.TOOL_CALL, tc.name, True)
                result = self._kernel.tool_call(
                    token,
                    ToolCallRequest(name=tc.name, args=tc.input, intent=spec.goal[:100]),
                )
                output = result.output if result.success else {"error": result.error}
                tool_results_content.append({
                    "type":        "tool_result",
                    "tool_use_id": tc.id,
                    "content":     json.dumps(output, ensure_ascii=False),
                })

                # 持久化工具結果至 episodic 記憶
                self._kernel.mem_store(
                    token,
                    MemStoreRequest(
                        content=f"[工具:{tc.name}] {str(output)[:300]}",
                        tier=MemoryTier.EPISODIC,
                        intent=f"記錄工具呼叫結果 step={step}",
                    ),
                )

            state.messages.append({"role": "user", "content": tool_results_content})

            # 在工具結果注入後建立快照（自然邊界）
            if self._cfg.enable_snapshots:
                task.prompt_tokens += sum(
                    len(json.dumps(r, ensure_ascii=False)) // 4
                    for r in tool_results_content
                )
                snap = self._snapshot_manager.create(task, is_natural_boundary=True)
                if snap:
                    self._log(f"[{state.instance_id[:8]}] 快照 {snap.snapshot_id} "
                              f"{snap.payload_bytes}B")

        state.status = AgentStatus.FAILED
        return InferResult(
            instance_id=state.instance_id,
            task_id=task.task_id,
            status=RunnerStatus.FAILED,
            error=f"超過最大步數 ({self._cfg.max_steps})",
            steps=state.steps,
        )

    # ── Stub 迴圈（無 API Key）────────────────────────────────────────

    def _stub_run(self, state: AgentState, task: InferenceTask) -> InferResult:
        self._log(f"[stub] goal: {state.spec.goal}")
        token   = state.token
        outputs: list[str] = [f"目標：{state.spec.goal}"]

        # 展示排程器週期
        decision = self._scheduler.schedule()
        self._log(f"[L1] 排程週期 #{decision.cycle_id}: "
                  f"prefill={len(decision.prefill_batch)} "
                  f"decode={len(decision.decode_batch)}")
        outputs.append(f"L1 排程週期：prefill={len(decision.prefill_batch)} "
                       f"decode={len(decision.decode_batch)}")

        # 記憶體預取：顯示對話歷史
        mem_result = self._kernel.mem_recall(
            token,
            MemRecallRequest(query=state.spec.goal, intent="預取相關記憶", top_k=5),
        )
        if hasattr(mem_result, "entries") and mem_result.entries:
            outputs.append(f"--- 對話歷史 ({len(mem_result.entries)} 筆) ---")
            for e in mem_result.entries:
                line = e.content[:120]
                outputs.append(f"  {line}")
            outputs.append("---")

        # 從目標中擷取 Python 程式碼並執行
        accessible = [
            t for t in self._kernel.tool_list(token)
            if f"tool:{t}" in state.token.declared_actions
        ]
        goal = state.spec.goal
        code = _extract_python_code(goal)
        if code and "code_exec" in accessible:
            self._emit_event(token, BehaviorEventType.TOOL_CALL, "code_exec", True)
            r = self._kernel.tool_call(
                token,
                ToolCallRequest(name="code_exec", args={"code": code}, intent="stub 執行"),
            )
            if r.success:
                output = r.output.get("output", "") if isinstance(r.output, dict) else str(r.output)
                local_vars = r.output.get("locals", {}) if isinstance(r.output, dict) else {}
                outputs.append(f"=== 執行結果 ===")
                if output:
                    outputs.append(output.rstrip())
                if local_vars:
                    for k, v in local_vars.items():
                        if not k.startswith("_"):
                            outputs.append(f"{k} = {v}")
            else:
                outputs.append(f"code_exec 錯誤: {r.error}")
        else:
            # 無程式碼可執行時，選擇第一個能推論出參數的工具執行
            # 優先順序：web > file
            _PRIORITY = {"web_search": 0, "web_fetch": 1, "code_exec": 2,
                         "file_read": 3, "file_write": 4}
            accessible.sort(key=lambda t: _PRIORITY.get(t, 99))
            tool_used = False
            for tool_name in accessible:
                tool_args = _infer_args(tool_name, goal)
                if tool_args is None:
                    continue
                tool_used = True
                self._emit_event(token, BehaviorEventType.TOOL_CALL, tool_name, True)
                r = self._kernel.tool_call(
                    token,
                    ToolCallRequest(name=tool_name, args=tool_args, intent="stub 執行"),
                )
                if r.success:
                    outputs.append(f"=== {tool_name} 結果 ===")
                    out = r.output
                    if isinstance(out, dict):
                        for k, v in out.items():
                            if v is not None and v != "":
                                outputs.append(f"  {k}: {v}")
                    else:
                        outputs.append(f"  {out}")
                else:
                    outputs.append(f"工具 '{tool_name}' 錯誤: {r.error}")
                break
            if not tool_used:
                pass  # 無工具匹配，略過

        # 快照演示
        if self._cfg.enable_snapshots:
            snap = self._snapshot_manager.create(task, is_natural_boundary=True)
            if snap:
                outputs.append(f"KV 快照 {snap.snapshot_id}：{snap.payload_bytes}B")

        # 行為防護演示
        if self._cfg.enable_behavior_guard:
            verdict = self._behavior_guard.analyze(token.instance_id)
            outputs.append(f"行為防護：{'通過' if verdict.verdict else '攔截'} "
                           f"(信心 {verdict.confidence:.2f})")

        result_text = "\n".join(outputs)
        state.result = result_text
        state.status = AgentStatus.DONE
        self._persist_result(token, state.spec.goal, result_text)

        return InferResult(
            instance_id=state.instance_id,
            task_id=task.task_id,
            status=RunnerStatus.DONE,
            result=result_text,
            steps=1,
            total_tokens=task.prompt_tokens,
        )

    # ── 輔助 ─────────────────────────────────────────────────────────

    def _build_memory_context(self, token: TrustToken, goal: str) -> str:
        result = self._kernel.mem_recall(
            token,
            MemRecallRequest(query=goal, intent="組建推論上下文", top_k=5),
        )
        if not hasattr(result, "entries") or not result.entries:
            return ""
        lines = ["\n\n## 相關記憶\n"]
        for e in result.entries:
            lines.append(f"- {e.content[:200]}")
        return "\n".join(lines)

    def _build_tool_defs(self, token: TrustToken) -> list[dict]:
        specs = [
            s for s in self._kernel.registry.all_specs()
            if s.name in self._kernel.tool_list(token)
        ]
        return [
            {
                "name":         s.name,
                "description":  s.description,
                "input_schema": {"type": "object", "properties": s.parameters,
                                 "required": list(s.parameters.keys())},
            }
            for s in specs
        ]

    def _persist_result(self, token: TrustToken, goal: str, result: str) -> None:
        self._kernel.mem_store(
            token,
            MemStoreRequest(
                content=f"目標：{goal}\n結果：{result[:500]}",
                tier=MemoryTier.SEMANTIC,
                intent="持久化代理執行結果",
            ),
        )

    def _emit_event(
        self,
        token:      TrustToken,
        event_type: BehaviorEventType,
        syscall:    str,
        success:    bool,
    ) -> None:
        event = BehaviorEvent(
            instance_id=token.instance_id,
            event_type=event_type,
            syscall_name=syscall,
            success=success,
        )
        self._behavior_guard.publish(event)

    def _log(self, msg: str) -> None:
        if self._cfg.verbose:
            print(msg)


def _extract_python_code(goal: str) -> str | None:
    m = re.search(r"```(?:python)?\s*\n?(.*?)```", goal, re.DOTALL)
    if m:
        code = m.group(1).strip()
        if code:
            return code
    m = re.search(r"(?:python|計算|執行)[：:]\s*(.+)", goal)
    if m:
        expr = m.group(1).strip()
        if re.search(r"[a-zA-Z0-9_)\]]\s*[=+\-*/%()\[\]{}]", expr):
            return expr
    m = re.search(r"(\d+\s*\*\*\s*\d+)", goal)
    if m:
        return "result = " + m.group(1) + "\nprint(result)"
    # 直接尋找數學表達式：數字搭配運算子（2 項或以上）
    m = re.search(r"(\d+(?:\.\d+)?\s*[\+\-\*/%]\s*\d+(?:\s*[\+\-\*/%]\s*\d+(?:\.\d+)?)*)", goal)
    if m:
        return "result = " + m.group(1) + "\nprint(result)"
    m = re.search(r"(\w+\s*=\s*.+)", goal)
    if m:
        return m.group(1).strip()
    m = re.search(r"(print\(.*\))", goal)
    if m:
        return m.group(1).strip()
    return None


def _infer_args(tool_name: str, goal: str) -> dict | None:
    min_len = 2 if re.search(r'[\u4e00-\u9fff]', goal) else 5

    if tool_name == "web_search":
        if re.search(r"https?://[^\s]+", goal):
            return None
        if len(goal.strip()) < min_len:
            return None
        return {"query": goal, "top_k": 5}
    if tool_name == "web_fetch":
        m = re.search(r"https?://[^\s]+", goal)
        if m:
            return {"url": m.group(0)}
        if len(goal.strip()) < min_len:
            return None
        import urllib.parse
        search_url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(goal)
        return {"url": search_url}
    if tool_name == "code_exec":
        code = _extract_python_code(goal)
        if code:
            return {"code": code}
        return None
    if tool_name == "file_write":
        if len(goal.strip()) < min_len:
            return None
        return {"path": "/tmp/aios_workspace/aios_output.txt",
                "content": f"目標: {goal}\n"}
    if tool_name == "file_read":
        if len(goal.strip()) < min_len:
            return None
        return {"path": "/tmp/aios_workspace/aios_output.txt"}
    return None
