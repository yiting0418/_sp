"""
aios.runtime.engine
────────────────────
推論引擎抽象介面與相關資料型別。

所有具體推論引擎（LlamaCppEngine、stub、未來的 vLLM adapter）
都必須繼承 InferenceEngine。

設計約束：
  - generate_stream() 是 async generator——呼叫方可以 `async for token` 逐 token 消費
  - 引擎不直接感知工具呼叫；工具標籤偵測由 ProcessManager 負責
  - save_state() / load_state() 對應 llama.cpp 的 KV-Cache 快照 API
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncGenerator

from pydantic import BaseModel, ConfigDict, Field


# ════════════════════════════════════════════════════════════════════
# 工具呼叫標籤格式（模型輸出中的標記）
# ════════════════════════════════════════════════════════════════════

TOOL_START = "<tool_call>"
TOOL_END   = "</tool_call>"

# 傳給 llama 的 stop words：生成到 TOOL_END 時立即停止
# 這正是「自然邊界」——模型完成完整的工具呼叫宣告才停止
TOOL_STOP_WORDS = [TOOL_END, "</s>", "<|eot_id|>", "<|end|>"]

# 系統提示的工具使用說明（注入至每次推論的 system prompt）
TOOL_USE_INSTRUCTIONS = """
你可以呼叫工具。工具呼叫格式如下：

<tool_call>
{"name": "tool_name", "arguments": {"arg1": "value1"}}
</tool_call>

工具執行結果會以以下格式注入：

<tool_result name="tool_name">
{"output": ...}
</tool_result>

完成所有工具呼叫後，直接輸出最終答案。
""".strip()


# ════════════════════════════════════════════════════════════════════
# 生成結果型別
# ════════════════════════════════════════════════════════════════════

class StopReason(str, Enum):
    EOS        = "eos"          # 正常結束（EOS token）
    TOOL_CALL  = "tool_call"    # 偵測到工具呼叫標籤（自然邊界）
    MAX_TOKENS = "max_tokens"   # 達到 max_tokens 上限
    SUSPENDED  = "suspended"    # 外部中斷（SIGINT / timeout）
    ERROR      = "error"        # 推論錯誤


@dataclass
class GenerationChunk:
    """stream 中的一個 token chunk。"""
    text:        str
    token_id:    int | None = None
    logprob:     float | None = None
    is_last:     bool = False


@dataclass
class GenerationResult:
    """整輪生成結束後的完整結果。"""
    full_text:     str
    stop_reason:   StopReason
    tokens_used:   int
    tool_call_raw: str | None = None   # 若 stop_reason == TOOL_CALL，這裡是原始 JSON
    error:         str | None = None
    duration_ms:   float = 0.0


@dataclass
class EngineState:
    """
    引擎的可序列化狀態快照。
    對 LlamaCppEngine 而言，payload 是 llm.save_state() 的回傳值。
    """
    engine_id:   str     = field(default_factory=lambda: uuid.uuid4().hex[:8])
    instance_id: str     = ""
    context:     str     = ""        # 截至快照時點的完整 context string
    token_count: int     = 0
    payload:     Any     = None      # LlamaState 物件（或 bytes）
    created_at:  datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# 抽象基礎類別
# ════════════════════════════════════════════════════════════════════

class InferenceEngine(ABC):
    """
    所有推論引擎的共同介面。

    子類別必須實作：
      load()           — 載入模型（接受引擎特定的 kwargs）
      generate_stream() — async token generator
      save_state()     — 序列化當前 KV-Cache 狀態
      load_state()     — 從快照恢復 KV-Cache 狀態
      is_loaded        — 模型是否已載入
    """

    @abstractmethod
    def load(self, model_path: str, **kwargs: Any) -> None:
        """載入模型。model_path 可以是本地路徑或模型識別符。"""

    @abstractmethod
    async def generate_stream(
        self,
        prompt:     str,
        max_tokens: int = 512,
        temperature: float = 0.7,
        stop_words: list[str] | None = None,
    ) -> AsyncGenerator[GenerationChunk, None]:
        """
        非同步 token 串流生成器。
        呼叫方透過 `async for chunk in engine.generate_stream(...)` 消費。
        """

    @abstractmethod
    def save_state(self) -> EngineState | None:
        """序列化當前 KV-Cache 狀態。若尚未有生成歷史則回傳 None。"""

    @abstractmethod
    def load_state(self, state: EngineState) -> bool:
        """從 EngineState 恢復 KV-Cache。回傳是否成功。"""

    @property
    @abstractmethod
    def is_loaded(self) -> bool:
        """引擎是否已完成模型載入。"""

    @property
    def engine_name(self) -> str:
        return self.__class__.__name__
