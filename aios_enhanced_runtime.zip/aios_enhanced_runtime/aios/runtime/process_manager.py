"""
aios.runtime.process_manager
──────────────────────────────
ProcessManager：推論行程的生命週期管理器。

核心職責：
  1. 監聽 generate_stream() 的 token 串流
  2. 偵測工具呼叫標籤（TOOL_START / TOOL_END）
  3. 在自然邊界觸發 SUSPENDED 狀態並建立 EngineState 快照
  4. 執行工具、組裝結果並注入 context
  5. 從快照恢復，讓模型繼續生成

狀態機：
                submit()
  IDLE ──────────────────────→ PREFILL
                                  │
                           （Prefill 完成）
                                  ▼
                               DECODE ◄─────────────────────┐
                                  │                         │
              偵測到 TOOL_START/END     resume_from_snapshot()
                                  ▼                         │
                            SUSPENDED ──→ 執行工具 ──→ 注入結果 ──┘
                                  │
                             EOS / error
                                  ▼
                          DONE / FAILED

工具標籤偵測（Token Buffer 滑動視窗）：
  ┌─────────────────────────────────────────────────────┐
  │ token 逐個進入 _buffer                              │
  │ 若 _buffer 尾端包含 TOOL_START → 開始累積工具呼叫  │
  │ 若 _buffer 包含 TOOL_END   → 停止生成，進入 SUSPEND │
  └─────────────────────────────────────────────────────┘

suspend 原則：
  TOOL_END 是「自然邊界」——模型已完整輸出工具呼叫宣告。
  llama-cpp 的 stop word 機制確保生成在 TOOL_END 後停止，
  KV-Cache 在此刻是完整且一致的狀態，可以安全快照。
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from aios.core.models import AgentState, AgentStatus, TrustToken
from aios.core.models_p2 import (
    BehaviorEvent,
    BehaviorEventType,
    InferencePhase,
    InferenceTask,
    RunnerStatus,
)
from aios.kernel.aios import AIOS
from aios.l2.snapshot import SnapshotManager
from aios.runtime.engine import (
    EngineState,
    GenerationChunk,
    GenerationResult,
    InferenceEngine,
    StopReason,
    TOOL_END,
    TOOL_START,
    TOOL_STOP_WORDS,
    TOOL_USE_INSTRUCTIONS,
)
from aios.core.models import MemStoreRequest, MemoryTier, ToolCallRequest


# ════════════════════════════════════════════════════════════════════
# 行程狀態
# ════════════════════════════════════════════════════════════════════

class ProcessState(str, Enum):
    IDLE      = "idle"
    PREFILL   = "prefill"
    DECODE    = "decode"
    SUSPENDED = "suspended"   # 等待工具執行
    DONE      = "done"
    FAILED    = "failed"


# ════════════════════════════════════════════════════════════════════
# 掛起點快照（Suspend Checkpoint）
# ════════════════════════════════════════════════════════════════════

@dataclass
class SuspendCheckpoint:
    """
    推論行程在 SUSPENDED 時保存的完整狀態。

    恢復時需要：
      engine_state  — KV-Cache 快照（llm.save_state()）
      context       — 截至暫停點的完整 context string
      tool_call     — 待執行的工具呼叫（parsed JSON）
      resume_prefix — 工具結果注入後要 prepend 的 context 前綴
    """
    checkpoint_id: str
    instance_id:   str
    process_state: ProcessState
    engine_state:  EngineState | None
    context:       str                     # 暫停前的完整 context
    text_before_tool: str                  # TOOL_START 之前的生成文字
    tool_call_raw: str                     # TOOL_START..TOOL_END 之間的原始文字
    tool_call:     dict[str, Any] | None   # 解析後的工具呼叫 JSON
    step:          int = 0
    created_at:    datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ════════════════════════════════════════════════════════════════════
# 工具呼叫解析器
# ════════════════════════════════════════════════════════════════════

def parse_tool_call(raw: str) -> dict[str, Any] | None:
    """
    從工具呼叫原始文字解析出 {name, arguments}。

    支援格式：
      {"name": "tool", "arguments": {...}}
      {"name": "tool", "args": {...}}         # 別名
    """
    # 提取 TOOL_START 和 TOOL_END 之間的 JSON
    text = raw
    start = text.find(TOOL_START)
    end   = text.find(TOOL_END)
    if start != -1:
        text = text[start + len(TOOL_START):]
    if end != -1:
        end2 = raw.find(TOOL_END)
        text = raw[raw.find(TOOL_START) + len(TOOL_START):end2] if start != -1 else text[:end]
    text = text.strip()

    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        # 嘗試找到第一個合法 JSON 物件
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if not match:
            return None
        try:
            obj = json.loads(match.group())
        except json.JSONDecodeError:
            return None

    name = obj.get("name") or obj.get("tool") or obj.get("function")
    args = obj.get("arguments") or obj.get("args") or obj.get("parameters") or {}
    if not name:
        return None
    return {"name": str(name), "arguments": args}


def format_tool_result(tool_name: str, result: Any) -> str:
    """將工具執行結果格式化為注入 context 的字串。"""
    result_json = json.dumps(result, ensure_ascii=False, default=str)
    return f'\n<tool_result name="{tool_name}">\n{result_json}\n</tool_result>\n'


# ════════════════════════════════════════════════════════════════════
# ProcessManager
# ════════════════════════════════════════════════════════════════════

class ProcessManager:
    """
    推論行程管理器。

    一個 ProcessManager 對應一個推論任務（InferenceTask）。
    它監聽引擎的 token 串流，在偵測到工具標籤時中斷，
    執行工具後注入結果並恢復生成。
    """

    def __init__(
        self,
        engine:           InferenceEngine,
        kernel:           AIOS,
        snapshot_manager: SnapshotManager,
        max_steps:        int = 20,
        max_tokens:       int = 1024,
        temperature:      float = 0.7,
        verbose:          bool = False,
    ) -> None:
        self._engine    = engine
        self._kernel    = kernel
        self._snapshots = snapshot_manager
        self._max_steps = max_steps
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._verbose   = verbose

        self._state          = ProcessState.IDLE
        self._checkpoints:   list[SuspendCheckpoint] = []
        self._total_tokens   = 0

    # ── 主執行入口 ────────────────────────────────────────────────────

    async def run(
        self,
        agent_state: AgentState,
        task:        InferenceTask,
    ) -> GenerationResult:
        """
        執行推論任務的完整生命週期。
        回傳最終的 GenerationResult（包含完整生成文字和停止原因）。
        """
        token  = agent_state.token
        spec   = agent_state.spec

        # 組建初始 prompt
        system_prompt  = self._build_system_prompt(token)
        initial_prompt = f"{system_prompt}\n\nUser: {spec.goal}\nAssistant:"

        self._state = ProcessState.PREFILL
        task.phase  = InferencePhase.PREFILL
        self._log(f"[{agent_state.instance_id[:8]}] PREFILL start")

        context       = initial_prompt
        full_output   = ""
        current_step  = 0

        while current_step < self._max_steps:
            current_step += 1
            task.phase    = InferencePhase.DECODE
            self._state   = ProcessState.DECODE
            self._log(f"[{agent_state.instance_id[:8]}] step {current_step} DECODE")

            # ── 監聽 token 串流 ────────────────────────────────────────
            stream_result = await self._monitored_stream(
                context=context,
                instance_id=agent_state.instance_id,
                task=task,
                step=current_step,
            )

            full_output += stream_result.text_before_tool

            if stream_result.stop_reason == StopReason.TOOL_CALL:
                # ── 偵測到工具呼叫 → SUSPENDED ────────────────────────
                task.phase  = InferencePhase.SUSPENDED
                self._state = ProcessState.SUSPENDED
                self._log(f"[{agent_state.instance_id[:8]}] SUSPENDED — tool: "
                          f"{stream_result.tool_call.get('name') if stream_result.tool_call else '?'}")

                # 執行工具
                tool_result_text = await self._execute_tool(
                    token, stream_result.tool_call or {}
                )

                # 注入工具結果，恢復 context
                context = (
                    context
                    + stream_result.text_before_tool
                    + TOOL_START + "\n"
                    + stream_result.tool_call_raw + "\n"
                    + TOOL_END + "\n"
                    + tool_result_text
                    + "Assistant:"
                )

                # 若引擎支援 KV-Cache 恢復，從快照恢復（避免重新 prefill）
                if stream_result.engine_state:
                    restored = self._engine.load_state(stream_result.engine_state)
                    self._log(f"[{agent_state.instance_id[:8]}] KV-Cache 恢復：{restored}")

                task.phase  = InferencePhase.DECODE
                self._state = ProcessState.DECODE
                continue

            else:
                # ── EOS / MAX_TOKENS → 生成完畢 ───────────────────────
                self._state = ProcessState.DONE
                task.phase  = InferencePhase.IDLE
                agent_state.status  = AgentStatus.DONE
                agent_state.result  = full_output.strip()

                return GenerationResult(
                    full_text=full_output.strip(),
                    stop_reason=stream_result.stop_reason,
                    tokens_used=self._total_tokens,
                    duration_ms=stream_result.duration_ms,
                )

        # 超過最大步數
        self._state        = ProcessState.FAILED
        agent_state.status = AgentStatus.FAILED
        return GenerationResult(
            full_text=full_output.strip(),
            stop_reason=StopReason.MAX_TOKENS,
            tokens_used=self._total_tokens,
            error=f"超過最大步數 ({self._max_steps})",
        )

    # ── 帶監聽的串流 ──────────────────────────────────────────────────

    @dataclass
    class _StreamResult:
        """單輪串流的結果，傳回給主迴圈。"""
        text_before_tool: str
        stop_reason:      StopReason
        tool_call_raw:    str = ""
        tool_call:        dict[str, Any] | None = None
        engine_state:     EngineState | None = None
        duration_ms:      float = 0.0

    async def _monitored_stream(
        self,
        context:     str,
        instance_id: str,
        task:        InferenceTask,
        step:        int,
    ) -> "_StreamResult":
        """
        監聽 token 串流，偵測工具標籤。

        偵測機制（Token Buffer 滑動視窗）：
          每個 token 加入 _buffer 後，檢查 buffer 尾端是否包含 TOOL_START。
          若是：記錄工具呼叫開始位置，繼續監聽直到 TOOL_END（由 stop word 保證）。

        自然邊界保證：
          TOOL_END 作為 stop word 傳給 llama；
          llama 在生成 TOOL_END 後停止，此時 KV-Cache 完整且一致。
        """
        t0     = time.perf_counter()
        buffer = ""
        in_tool_call = False

        async for chunk in self._engine.generate_stream(
            prompt=context,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
            stop_words=TOOL_STOP_WORDS,
        ):
            buffer += chunk.text
            self._total_tokens += 1
            task.generated_tokens += 1

            # 偵測工具呼叫開始
            if TOOL_START in buffer and not in_tool_call:
                in_tool_call = True
                self._log(f"[{instance_id[:8]}] 偵測到 {TOOL_START}")

            # llama 的 stop word 確保生成在 TOOL_END 後停止
            # 但 stop word 本身不會出現在輸出中，所以我們手動補上
            if chunk.is_last:
                break

        elapsed = (time.perf_counter() - t0) * 1000

        # 判斷停止原因
        if in_tool_call or TOOL_START in buffer:
            # 分離工具呼叫前的文字和工具呼叫本身
            tool_start_idx = buffer.find(TOOL_START)
            text_before    = buffer[:tool_start_idx]
            tool_raw       = buffer[tool_start_idx:]  # 包含 TOOL_START 但不含 TOOL_END

            # 解析工具呼叫
            parsed = parse_tool_call(buffer)

            # 在自然邊界建立 KV-Cache 快照
            engine_state = self._engine.save_state()
            if engine_state:
                engine_state.instance_id = instance_id
                engine_state.context     = context
                engine_state.token_count = self._total_tokens

            # 持久化 checkpoint
            ckpt = SuspendCheckpoint(
                checkpoint_id=f"ckpt:{instance_id[:8]}:s{step}",
                instance_id=instance_id,
                process_state=ProcessState.SUSPENDED,
                engine_state=engine_state,
                context=context,
                text_before_tool=text_before,
                tool_call_raw=tool_raw,
                tool_call=parsed,
                step=step,
            )
            self._checkpoints.append(ckpt)

            return self._StreamResult(
                text_before_tool=text_before,
                stop_reason=StopReason.TOOL_CALL,
                tool_call_raw=tool_raw,
                tool_call=parsed,
                engine_state=engine_state,
                duration_ms=elapsed,
            )

        return self._StreamResult(
            text_before_tool=buffer,
            stop_reason=StopReason.EOS,
            duration_ms=elapsed,
        )

    # ── 工具執行 ─────────────────────────────────────────────────────

    async def _execute_tool(
        self,
        token:     TrustToken,
        tool_call: dict[str, Any],
    ) -> str:
        """
        通過 AIOS kernel 執行工具呼叫（仍走三道安全防線）。
        回傳格式化後的工具結果字串，直接可注入 context。
        """
        name = tool_call.get("name", "")
        args = tool_call.get("arguments", {})

        if not name:
            return format_tool_result("unknown", {"error": "工具名稱為空"})

        result = self._kernel.tool_call(
            token,
            ToolCallRequest(
                name=name,
                args=args,
                intent=f"ProcessManager step — {name}",
            ),
        )

        # 持久化工具結果至記憶體
        summary = f"[工具:{name}] {str(result.output)[:300]}"
        self._kernel.mem_store(
            token,
            MemStoreRequest(
                content=summary,
                tier=MemoryTier.EPISODIC,
                intent=f"ProcessManager 記錄工具呼叫 {name}",
            ),
        )

        output = result.output if result.success else {"error": result.error}
        self._log(f"  ↳ {name}：{'OK' if result.success else 'FAIL'} "
                  f"({result.duration_ms:.0f}ms)")
        return format_tool_result(name, output)

    # ── 系統提示 ─────────────────────────────────────────────────────

    def _build_system_prompt(self, token: TrustToken) -> str:
        accessible = self._kernel.tool_list(token)
        tools_json = json.dumps(
            [
                {
                    "name": spec.name,
                    "description": spec.description,
                    "parameters": spec.parameters,
                }
                for spec in self._kernel.registry.all_specs()
                if spec.name in accessible
            ],
            ensure_ascii=False,
            indent=2,
        )
        return (
            "System: 你是一個運行在 AIOS 上的 AI 代理。\n"
            f"{TOOL_USE_INSTRUCTIONS}\n\n"
            f"可用工具：\n{tools_json}"
        )

    # ── 查詢 ─────────────────────────────────────────────────────────

    @property
    def state(self) -> ProcessState:
        return self._state

    @property
    def checkpoints(self) -> list[SuspendCheckpoint]:
        return list(self._checkpoints)

    def latest_checkpoint(self) -> SuspendCheckpoint | None:
        return self._checkpoints[-1] if self._checkpoints else None

    # ── 日誌 ─────────────────────────────────────────────────────────

    def _log(self, msg: str) -> None:
        if self._verbose:
            print(msg)
